-- Veyra Supabase schema — run once in Supabase Dashboard → SQL Editor → New query.
-- Safe to re-run (IF NOT EXISTS / OR REPLACE / DROP POLICY IF EXISTS).

-- 1) Profiles: one row per auth user. profile/company mirror the
--    existing localStorage JSON shape in store.js so the frontend
--    needs no data migration.
create table if not exists public.profiles (
  id uuid primary key references auth.users (id) on delete cascade,
  email text,
  first_name text default '',
  last_name text default '',
  account_type text default 'job-seeker' check (account_type in ('job-seeker', 'company')),
  profile jsonb not null default '{}'::jsonb,
  company jsonb,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

-- 2) Connections: user -> target profile/org id (demo ids are text).
create table if not exists public.connections (
  user_id uuid not null references auth.users (id) on delete cascade,
  target_id text not null,
  created_at timestamptz not null default now(),
  primary key (user_id, target_id)
);

-- 3) Agent history: last-N chat turns per user.
create table if not exists public.agent_history (
  id bigint generated always as identity primary key,
  user_id uuid not null references auth.users (id) on delete cascade,
  role text not null check (role in ('user', 'assistant', 'system')),
  content text not null,
  created_at timestamptz not null default now()
);
create index if not exists agent_history_user_idx on public.agent_history (user_id, created_at desc);

alter table public.profiles enable row level security;
alter table public.connections enable row level security;
alter table public.agent_history enable row level security;

-- Profiles: public directory readable (needed for People page),
-- writable only by the owner. Email/name columns stay readable too;
-- keep PII out of the profile JSON if that matters to you.
drop policy if exists "profiles public read" on public.profiles;
create policy "profiles public read" on public.profiles for select using (true);

drop policy if exists "profiles owner insert" on public.profiles;
create policy "profiles owner insert" on public.profiles for insert with check (auth.uid() = id);

drop policy if exists "profiles owner update" on public.profiles;
create policy "profiles owner update" on public.profiles for update using (auth.uid() = id);

drop policy if exists "profiles owner delete" on public.profiles;
create policy "profiles owner delete" on public.profiles for delete using (auth.uid() = id);

-- Connections: owner only.
drop policy if exists "connections owner all" on public.connections;
create policy "connections owner all" on public.connections for all using (auth.uid() = user_id) with check (auth.uid() = user_id);

-- Agent history: owner read/insert, owner delete for pruning.
drop policy if exists "agent_history owner read" on public.agent_history;
create policy "agent_history owner read" on public.agent_history for select using (auth.uid() = user_id);

drop policy if exists "agent_history owner insert" on public.agent_history;
create policy "agent_history owner insert" on public.agent_history for insert with check (auth.uid() = user_id);

drop policy if exists "agent_history owner delete" on public.agent_history;
create policy "agent_history owner delete" on public.agent_history for delete using (auth.uid() = user_id);

-- Keep updated_at fresh.
create or replace function public.touch_updated_at()
returns trigger language plpgsql as $$
begin new.updated_at = now(); return new; end $$;

drop trigger if exists profiles_touch on public.profiles;
create trigger profiles_touch before update on public.profiles
for each row execute function public.touch_updated_at();
