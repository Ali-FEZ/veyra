# نقشه معماری — Veyra / Final Audit

## هدف

Final Audit تمام قابلیت‌های Agent، Profile، Matching و Company را در یک تجربه منسجم محصول جمع می‌کند:

`Homepage → Agent → Identity/Need → Discovery → Match → Detail → Explanation → Next action`

## KEEP

- Static Frontend با `HTML/CSS/Vanilla JS`
- hash-based routing
- GitHub Pages compatibility
- Browser/Demo persistence boundary
- Deterministic matching
- Controlled Agent actions
- Synthetic demo dataset

## ADAPT

### Homepage

Homepage از یک landing ساده به entry point اصلی محصول تبدیل شده است و Agent را قبل از discoveryهای passive قرار می‌دهد.

### Discovery

Job / Candidate / Company / Profile cards با اطلاعات حداقلی و actionهای واقعی به detail/context-aware Agent متصل‌اند.

### Company

Company dashboard و Company Agent مسیر مجزایی از Job Seeker دارند: ابتدا hiring need و criteria، سپس candidate discovery و fit analysis.

### Organizations

Organization detail به‌عنوان public discovery context اضافه شده و اعضا و فرصت‌های مرتبط را در یک صفحه جمع می‌کند.

## ADD

### Final Audit UI composition

- Professional / Company audience entry cards
- Relevant opportunity section در homepage
- Professional profile discovery section
- Company discovery section
- How Veyra works section
- Homepage CTA به Agent
- Modern About story + creators

### Similar opportunity action

`find_similar_jobs` با داده ساختاریافته و deterministic similarity برای opportunity فعلی کار می‌کند و نتیجه را در Chat Cards نمایش می‌دهد.

### Organization detail

`#organizations/:id` همان synthetic organization، اعضا و فرصت‌های مرتبط را نمایش می‌دهد و context را به Agent می‌دهد.

## CONTROLLED AGENT PATH

`User message → AI/local intent → allowlist → application action → VeyraStore / Matching → rerender`

LLM مستقیماً state را mutate نمی‌کند. Provider response صرفاً interpretation / action suggestion است؛ application خود mutation را انجام می‌دهد.

## DATA SOURCES

### Browser/Demo state

`VeyraStore` برای account، session، profile، company profile، preferences، Agent history و connections استفاده می‌شود.

### Synthetic discovery data

`data/network.json` شامل ۸ profile، ۴ organization و ۸ opportunity است و تمام رکوردهای static با `source: "synthetic"` مشخص شده‌اند.

## TRUTH BOUNDARIES

- user-provided facts ≠ AI inference
- application data ≠ external market truth
- deterministic relevance ≠ hiring probability
- AI failure ≠ successful answer

## QA

```bash
node scripts/stage5_final_test.mjs
```

همچنین syntax check برای تمام JS moduleها در CI اجرا می‌شود. Browser automation در این execution environment قابل اتکا نبود؛ در نتیجه QA نهایی با deterministic state tests، AI contract tests، static validation و HTTP smoke test انجام شد.

## LIMITATIONS

- Authentication و persistence هنوز browser/demo هستند و shared production identity/database نیستند.
- Live Gemini به external endpoint نیاز دارد و secret فقط باید در server environment باشد.
- Discovery data synthetic است و نباید به‌عنوان داده واقعی بازار ارائه شود.
