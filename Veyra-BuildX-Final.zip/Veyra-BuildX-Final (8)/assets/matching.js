(() => {
  "use strict";

  const normalizeDigits = (value) => String(value || "").replace(/[۰-۹]/g, (c) => String("۰۱۲۳۴۵۶۷۸۹".indexOf(c))).replace(/[٠-٩]/g, (c) => String("٠١٢٣٤٥٦٧٨٩".indexOf(c)));

  const STOP = new Set([
    "and","the","for","with","from","into","work","role","lead","senior","junior","engineer","developer",
    "طراحی","مهندسی","مهندس","توسعه","ارشد","جونیور","برای","با","و","در","کار"
  ]);

  const normalize = (value) => String(value || "")
    .normalize("NFKC")
    .toLocaleLowerCase()
    .replace(/[–—−]/g, "-")
    .replace(/[^\p{L}\p{N}+#.\- ]/gu, " ")
    .replace(/\s+/g, " ")
    .trim();

  const tokens = (value) => normalize(value)
    .split(/\s+/)
    .filter((token) => token.length > 1 && !STOP.has(token));

  const same = (a, b) => normalize(a) === normalize(b);

  function overlap(left = [], right = []) {
    const source = new Map(left.map((skill) => [normalize(skill), skill]));
    return right.filter((skill) => source.has(normalize(skill))).map((skill) => source.get(normalize(skill)));
  }

  function tokenSimilarity(left, right) {
    const a = new Set(tokens(left));
    const b = new Set(tokens(right));
    if (!a.size || !b.size) return 0;
    let hit = 0;
    a.forEach((token) => { if (b.has(token)) hit += 1; });
    return hit / Math.max(a.size, b.size);
  }

  function yearsFromExperience(profile) {
    const values = Array.isArray(profile?.experience) ? profile.experience : [];
    let months = 0;
    for (const item of values) {
      const duration = String(item?.duration || "").toLocaleLowerCase();
      const yearMatch = duration.match(/(\d+(?:\.\d+)?)\s*year/);
      const monthMatch = duration.match(/(\d+(?:\.\d+)?)\s*month/);
      if (yearMatch) months += Number(yearMatch[1]) * 12;
      else if (monthMatch) months += Number(monthMatch[1]);
      else {
        const period = normalizeDigits(String(item?.period || ""));
        const years = period.match(/(20\d{2})\s*[-—]\s*(20\d{2}|present|now|اکنون|الان)/i);
        if (years) {
          const start = Number(years[1]);
          const end = /present|now|اکنون|الان/i.test(years[2]) ? new Date().getFullYear() : Number(years[2]);
          if (end >= start) months += (end - start) * 12;
        }
      }
    }
    return months / 12;
  }

  function experienceLevelFromYears(years) {
    if (years < 1) return "entry";
    if (years < 3) return "junior";
    if (years < 6) return "mid";
    return "senior";
  }

  function levelScore(candidateLevel, requiredLevel) {
    if (!requiredLevel) return 1;
    const rank = {entry: 1, junior: 2, mid: 3, senior: 4, lead: 5};
    const have = rank[candidateLevel] || 0;
    const need = rank[requiredLevel] || 0;
    if (!have || !need) return 0.5;
    if (have >= need) return 1;
    return Math.max(0, 1 - (need - have) * 0.25);
  }

  function listValues(value) {
    return Array.isArray(value) ? value.filter(Boolean).map(String) : [];
  }

  function getPreferences(profile) {
    return profile?.preferences && typeof profile.preferences === "object" ? profile.preferences : {};
  }

  function scoreJob(profile, job) {
    const skills = overlap(listValues(profile?.skills), listValues(job?.skills));
    const required = listValues(job?.skills);
    const skillRatio = required.length ? skills.length / required.length : 0;
    const targetRoles = listValues(profile?.targetRoles);
    const titleSimilarity = targetRoles.length
      ? Math.max(...targetRoles.map((role) => tokenSimilarity(role, textOf(job?.title))))
      : tokenSimilarity(textOf(profile?.headline), textOf(job?.title));
    const interests = overlap(listValues(profile?.interests), [textOf(job?.title), textOf(job?.summary), ...(listValues(job?.skills))]);
    const years = yearsFromExperience(profile);
    const level = experienceLevelFromYears(years);
    const experienceFit = levelScore(level, job?.experienceLevel);
    const preferences = getPreferences(profile);

    let preferenceBonus = 0;
    const concerns = [];
    const workMode = normalize(job?.workMode || "");
    const preferredSkillMatches = overlap(listValues(preferences.preferredSkills), required);
    if (preferredSkillMatches.length) preferenceBonus += Math.min(preferredSkillMatches.length, 2) * 0.06;
    if (Array.isArray(preferences.preferredWorkModes) && preferences.preferredWorkModes.length) {
      if (preferences.preferredWorkModes.some((value) => normalize(value) === workMode)) preferenceBonus += 0.08;
    }
    if (Array.isArray(preferences.excludedWorkModes) && preferences.excludedWorkModes.some((value) => normalize(value) === workMode)) {
      preferenceBonus -= 0.45;
      concerns.push(`work mode excluded: ${job?.workMode || "unknown"}`);
    }
    if (Array.isArray(preferences.preferredCompanyTypes) && preferences.preferredCompanyTypes.length) {
      if (preferences.preferredCompanyTypes.some((value) => normalize(value) === normalize(job?.companyType))) preferenceBonus += 0.07;
    }
    if (Array.isArray(preferences.excludedRoles) && preferences.excludedRoles.some((role) => tokenSimilarity(role, job?.title) > 0.45)) {
      preferenceBonus -= 0.40;
      concerns.push(`role excluded: ${job?.title || "unknown"}`);
    }
    if (preferences.preferredExperienceLevel && preferences.preferredExperienceLevel !== job?.experienceLevel) {
      preferenceBonus -= 0.08;
    }

    const weighted = (
      skillRatio * 0.48 +
      titleSimilarity * 0.18 +
      Math.min(interests.length / 3, 1) * 0.12 +
      experienceFit * 0.16 +
      Math.max(preferenceBonus, -0.5) * 0.20
    );
    const score = Math.round(Math.max(0, Math.min(100, weighted * 100)));
    const missing = required.filter((skill) => !skills.some((mine) => same(mine, skill)));
    const targetRoleMatches = targetRoles.filter((role) => tokenSimilarity(role, textOf(job?.title)) >= 0.45);
    return {
      score,
      relevance: relevanceLabel(score),
      strongMatches: skills,
      partialMatches: interests,
      preferredSkillMatches,
      targetRoleMatches,
      missingSkills: missing,
      relevantExperience: `${Number(years.toFixed(1))} years estimated from explicit profile experience`,
      concerns,
      reasoning: buildReasoning({score, skills, missing, titleSimilarity, experienceFit, preferences, job, preferredSkillMatches, targetRoleMatches})
    };
  }

  function scoreCandidate(candidate, company) {
    const requiredSkills = listValues(company?.requiredSkills);
    const candidateSkills = listValues(candidate?.skills);
    const matched = overlap(candidateSkills, requiredSkills);
    const missing = requiredSkills.filter((skill) => !matched.some((mine) => same(mine, skill)));
    const desiredRoles = listValues(company?.desiredRoles);
    const title = textOf(candidate?.headline);
    const roleSimilarity = desiredRoles.length ? Math.max(...desiredRoles.map((role) => tokenSimilarity(role, title))) : 0;
    const years = yearsFromExperience(candidate);
    const level = experienceLevelFromYears(years);
    const candidatePreference = company?.preferredExperienceLevel ? levelScore(level, company.preferredExperienceLevel) : 0.7;
    const preferenceKeywords = listValues(company?.preferredCharacteristics);
    const preferenceHits = preferenceKeywords.filter((keyword) => normalize([title, textOf(candidate?.about), ...(candidate?.interests || [])].join(" ")).includes(normalize(keyword)));
    const skillRatio = requiredSkills.length ? matched.length / requiredSkills.length : 0;
    const score = Math.round(Math.max(0, Math.min(100, (skillRatio * 58 + roleSimilarity * 20 + candidatePreference * 12 + Math.min(preferenceHits.length / 2, 1) * 10) * 100 / 100)));
    return {
      score,
      relevance: relevanceLabel(score),
      strongMatches: matched,
      partialMatches: preferenceHits,
      missingSkills: missing,
      relevantExperience: `${Number(years.toFixed(1))} years estimated from explicit profile experience`,
      concerns: missing.length ? [`missing ${missing.length} required skill(s)`] : [],
      reasoning: `Skill overlap ${matched.length}/${requiredSkills.length || 0}; role similarity ${(roleSimilarity * 100).toFixed(0)}%; experience basis ${level}.`
    };
  }

  function rankJobs(profile, jobs = []) {
    return jobs.map((job) => ({job, fit: scoreJob(profile, job)})).sort((a, b) => b.fit.score - a.fit.score);
  }

  function rankCandidates(company, candidates = []) {
    return candidates.map((candidate) => ({candidate, fit: scoreCandidate(candidate, company)})).sort((a, b) => b.fit.score - a.fit.score);
  }

  function relevanceLabel(score) {
    if (score >= 75) return "high";
    if (score >= 50) return "medium";
    if (score >= 30) return "partial";
    return "low";
  }

  function textOf(value) {
    if (value && typeof value === "object") return String(value.en || value.fa || "");
    return String(value || "");
  }

  function buildReasoning({skills, missing, titleSimilarity, experienceFit, preferences, job, targetRoleMatches = []}) {
    const pieces = [];
    if (skills.length) pieces.push(`${skills.length} required skill(s) match`);
    if (missing.length) pieces.push(`${missing.length} required skill(s) are not yet visible`);
    if (targetRoleMatches.length) pieces.push("target role language matches the opportunity title");
    else if (titleSimilarity >= 0.4) pieces.push("title language is related to the current profile headline");
    if (experienceFit >= 0.9) pieces.push("explicit experience level is compatible");
    if (Array.isArray(preferences.excludedWorkModes) && preferences.excludedWorkModes.some((v) => normalize(v) === normalize(job?.workMode))) pieces.push("the stated work-mode preference conflicts");
    return pieces.join("; ") || "limited structured evidence in the current profile";
  }

  window.VeyraMatching = Object.freeze({
    overlap,
    tokenSimilarity,
    yearsFromExperience,
    experienceLevelFromYears,
    scoreJob,
    scoreCandidate,
    rankJobs,
    rankCandidates,
    relevanceLabel,
  });
})();
