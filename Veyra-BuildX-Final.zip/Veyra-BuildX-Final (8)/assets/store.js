(() => {
  "use strict";

  const KEYS = Object.freeze({
    accounts: "veyra:stage3:accounts",
    session: "veyra:stage3:session",
    connections: "veyra:connections",
    agent: "veyra:stage3:agent-history",
    feedback: "veyra:stage3:feedback",
    lang: "veyra:lang",
    theme: "veyra:theme",
  });

  const parse = (raw, fallback) => {
    try { return raw ? JSON.parse(raw) : fallback; } catch { return fallback; }
  };
  const read = (key, fallback) => parse(localStorage.getItem(key), fallback);
  const write = (key, value) => localStorage.setItem(key, JSON.stringify(value));
  const makeId = () => globalThis.crypto?.randomUUID ? `local-${globalThis.crypto.randomUUID()}` : `local-${Date.now()}-${Math.random().toString(16).slice(2)}`;

  function normalizeIdentifier(value) { return String(value || "").trim().toLocaleLowerCase(); }

  function createBlankProfile({id, firstName, lastName, identifier, identifierType}) {
    const fullName = `${firstName} ${lastName}`.trim();
    return {
      id,
      name: {fa: fullName, en: fullName},
      headline: {fa: "", en: ""},
      location: {fa: "", en: ""},
      about: {fa: "", en: ""},
      skills: [], interests: [], targetRoles: [], goals: {fa: "", en: ""}, experience: [], education: [], projects: [], resume: "",
      preferences: {
        preferredWorkModes: [], excludedWorkModes: [], preferredCompanyTypes: [], excludedRoles: [],
        preferredSkills: [], preferredExperienceLevel: "", feedbackNotes: []
      },
      aiRecommendations: [], source: "user-entered", identifier, identifierType,
      createdAt: new Date().toISOString(), updatedAt: new Date().toISOString(),
    };
  }

  function createBlankCompany({id, identifier, identifierType}) {
    return {
      id, name: "", focus: "", location: "", description: "", type: "",
      hiringInterests: [], desiredRoles: [], requiredSkills: [], preferredCharacteristics: [],
      preferredExperienceLevel: "", openPositions: [], source: "user-entered", identifier, identifierType,
      createdAt: new Date().toISOString(), updatedAt: new Date().toISOString(),
    };
  }

  function listAccounts() { const value = read(KEYS.accounts, []); return Array.isArray(value) ? value : []; }
  function saveAccounts(accounts) { write(KEYS.accounts, accounts); }
  function findAccount(identifier) { const needle = normalizeIdentifier(identifier); return listAccounts().find((a) => normalizeIdentifier(a.identifier) === needle) || null; }

  function sanitizeCompany(company) {
    const clean = (value, max) => String(value || "").trim().slice(0, max);
    const arr = (value, maxItems, maxLen) => Array.isArray(value) ? value.map((item) => clean(item, maxLen)).filter(Boolean).slice(0, maxItems) : [];
    return {
      ...company,
      id: clean(company?.id, 80),
      name: clean(company?.name, 100), focus: clean(company?.focus, 160), location: clean(company?.location, 100),
      description: clean(company?.description, 700), type: clean(company?.type, 80),
      hiringInterests: arr(company?.hiringInterests, 10, 100),
      desiredRoles: arr(company?.desiredRoles, 8, 100),
      requiredSkills: arr(company?.requiredSkills, 16, 60),
      preferredCharacteristics: arr(company?.preferredCharacteristics, 8, 160),
      preferredExperienceLevel: clean(company?.preferredExperienceLevel, 30),
      openPositions: Array.isArray(company?.openPositions) ? company.openPositions.slice(0, 8).map((item) => ({
        title: clean(item?.title, 120), skills: arr(item?.skills, 16, 60), location: clean(item?.location, 100), workMode: clean(item?.workMode, 40), level: clean(item?.level, 30)
      })).filter((item) => item.title || item.skills.length) : [],
      source: "user-entered",
      updatedAt: new Date().toISOString(),
    };
  }

  function createAccount({identifier, identifierType, firstName, lastName, accountType = "job-seeker"}) {
    const normalized = normalizeIdentifier(identifier);
    if (!normalized || !firstName?.trim() || !lastName?.trim()) throw new Error("invalid_account");
    if (findAccount(normalized)) throw new Error("account_exists");
    const id = makeId();
    const safeType = accountType === "company" ? "company" : "job-seeker";
    const account = {
      id, identifier: normalized, identifierType: identifierType === "phone" ? "phone" : "email",
      firstName: firstName.trim().slice(0, 50), lastName: lastName.trim().slice(0, 50), accountType: safeType,
      profile: createBlankProfile({id, firstName, lastName, identifier: normalized, identifierType}),
      company: safeType === "company" ? createBlankCompany({id, identifier: normalized, identifierType}) : null,
      createdAt: new Date().toISOString(), persistence: "browser-demo"
    };
    saveAccounts([...listAccounts(), account]);
    localStorage.setItem(KEYS.session, id);
    return account;
  }

  function getCurrentAccount() {
    const id = String(localStorage.getItem(KEYS.session) || "");
    if (!id) return null;
    return listAccounts().find((account) => String(account.id) === id) || null;
  }

  function signIn(identifier) {
    const account = findAccount(identifier);
    if (!account) throw new Error("account_not_found");
    localStorage.setItem(KEYS.session, account.id);
    return account;
  }

  function signOut() { localStorage.removeItem(KEYS.session); }

  function updateCurrentIdentity({firstName, lastName}) {
    return updateCurrentProfileAndIdentity({firstName, lastName, profilePatch: {}});
  }

  function updateCurrentProfile(patch) {
    const current = getCurrentAccount(); if (!current) throw new Error("not_authenticated");
    const accounts = listAccounts();
    const nextProfile = sanitizeProfile({...current.profile, ...patch, id: current.id, identifier: current.identifier, identifierType: current.identifierType});
    const next = {...current, profile: nextProfile}; const index = accounts.findIndex((item) => item.id === current.id);
    if (index < 0) throw new Error("session_account_missing");
    accounts[index] = next; saveAccounts(accounts); return next;
  }

  function updateCurrentProfileAndIdentity({firstName, lastName, profilePatch = {}}) {
    const current = getCurrentAccount(); if (!current) throw new Error("not_authenticated");
    const cleanFirst = String(firstName || "").trim().slice(0, 50), cleanLast = String(lastName || "").trim().slice(0, 50);
    if (!cleanFirst || !cleanLast) throw new Error("invalid_identity");
    const accounts = listAccounts();
    const nextProfile = sanitizeProfile({...current.profile, ...profilePatch, name: `${cleanFirst} ${cleanLast}`, id: current.id, identifier: current.identifier, identifierType: current.identifierType});
    const next = {...current, firstName: cleanFirst, lastName: cleanLast, profile: nextProfile};
    const index = accounts.findIndex((item) => item.id === current.id);
    if (index < 0) throw new Error("session_account_missing");
    accounts[index] = next; saveAccounts(accounts); return next;
  }

  function updateCurrentCompany(patch) {
    const current = getCurrentAccount(); if (!current) throw new Error("not_authenticated");
    const accounts = listAccounts(); const nextCompany = sanitizeCompany({...current.company, ...patch, id: current.id, identifier: current.identifier, identifierType: current.identifierType});
    const next = {...current, company: nextCompany}; const index = accounts.findIndex((item) => item.id === current.id);
    if (index < 0) throw new Error("session_account_missing");
    accounts[index] = next; saveAccounts(accounts); return next;
  }

  function sanitizeProfile(profile) {
    const cleanText = (value, max) => String(value || "").trim().slice(0, max);
    const localized = (value, max = 500) => {
      if (typeof value === "string") return {fa: cleanText(value, max), en: cleanText(value, max)};
      if (!value || typeof value !== "object") return {fa: "", en: ""};
      return {fa: cleanText(value.fa, max), en: cleanText(value.en, max)};
    };
    const skills = Array.isArray(profile.skills) ? profile.skills.map((item) => cleanText(item, 60)).filter(Boolean).slice(0, 16) : [];
    const interests = Array.isArray(profile.interests) ? profile.interests.map((item) => cleanText(item, 90)).filter(Boolean).slice(0, 12) : [];
    const targetRoles = Array.isArray(profile.targetRoles) ? profile.targetRoles.map((item) => cleanText(item, 100)).filter(Boolean).slice(0, 8) : [];
    const experience = Array.isArray(profile.experience) ? profile.experience.map((item) => ({
      role: cleanText(item?.role, 100), company: cleanText(item?.company, 100), period: cleanText(item?.period, 60), duration: cleanText(item?.duration, 40), summary: cleanText(item?.summary, 300)
    })).filter((item) => Object.values(item).some(Boolean)).slice(0, 8) : [];
    const education = Array.isArray(profile.education) ? profile.education.map((item) => ({degree: cleanText(item?.degree, 100), school: cleanText(item?.school, 120), period: cleanText(item?.period, 60)})).filter((item) => Object.values(item).some(Boolean)).slice(0, 6) : [];
    const projects = Array.isArray(profile.projects) ? profile.projects.map((item) => ({name: cleanText(item?.name, 100), summary: cleanText(item?.summary, 280), link: cleanText(item?.link, 240)})).filter((item) => Object.values(item).some(Boolean)).slice(0, 8) : [];
    const pref = profile.preferences && typeof profile.preferences === "object" ? profile.preferences : {};
    const list = (value, maxItems, maxLen) => Array.isArray(value) ? value.map((item) => cleanText(item, maxLen)).filter(Boolean).slice(0, maxItems) : [];
    return {
      ...profile,
      name: localized(profile.name, 80), headline: localized(profile.headline, 140), location: localized(profile.location, 80), about: localized(profile.about, 700),
      skills, interests, targetRoles, goals: localized(profile.goals, 500), experience, education, projects, resume: cleanText(profile.resume, 300),
      preferences: {
        preferredWorkModes: list(pref.preferredWorkModes, 6, 40), excludedWorkModes: list(pref.excludedWorkModes, 6, 40),
        preferredCompanyTypes: list(pref.preferredCompanyTypes, 6, 60), excludedRoles: list(pref.excludedRoles, 8, 100),
        preferredSkills: list(pref.preferredSkills, 10, 60), preferredExperienceLevel: cleanText(pref.preferredExperienceLevel, 30),
        feedbackNotes: list(pref.feedbackNotes, 12, 180),
      },
      aiRecommendations: list(profile.aiRecommendations, 8, 180),
      source: "user-entered", updatedAt: new Date().toISOString(),
    };
  }

  function getCandidateAccounts() {
    return listAccounts().filter((account) => account.accountType === "job-seeker").map((account) => sanitizeProfile(account.profile));
  }

  function scopedKey(key, accountId = null) {
    const id = String(accountId || getCurrentAccount()?.id || "guest").trim() || "guest";
    return `${key}:${id}`;
  }
  function setConnections(values, accountId = null) { write(scopedKey(KEYS.connections, accountId), Array.from(new Set((values || []).map(String)))); }
  function getConnections(accountId = null) { const value = read(scopedKey(KEYS.connections, accountId), []); return Array.isArray(value) ? new Set(value.map(String)) : new Set(); }
  function saveAgentHistory(value, accountId = null) { write(scopedKey(KEYS.agent, accountId), Array.isArray(value) ? value.slice(-40) : []); }
  function getAgentHistory(accountId = null) { const value = read(scopedKey(KEYS.agent, accountId), []); return Array.isArray(value) ? value.slice(-40) : []; }
  function saveFeedback(value, accountId = null) { write(scopedKey(KEYS.feedback, accountId), Array.isArray(value) ? value.slice(-24) : []); }
  function getFeedback(accountId = null) { const value = read(scopedKey(KEYS.feedback, accountId), []); return Array.isArray(value) ? value.slice(-24) : []; }

  window.VeyraStore = Object.freeze({
    keys: KEYS, listAccounts, findAccount, createAccount, getCurrentAccount, signIn, signOut, updateCurrentIdentity, updateCurrentProfile, updateCurrentProfileAndIdentity, updateCurrentCompany,
    sanitizeProfile, sanitizeCompany, getCandidateAccounts, getConnections, setConnections, getAgentHistory, saveAgentHistory, getFeedback, saveFeedback, scopedKey,
    normalizeIdentifier, persistenceMode: "browser-demo"
  });
})();
