/* Veyra Supabase bridge — static-site friendly (no build step).
 * - Uses the global `supabase` client from the CDN (loaded before this file).
 * - Supabase Auth is the source of truth for login; the existing
 *   localStorage store (window.VeyraStore) stays as an offline cache so the
 *   rest of app.js keeps working synchronously.
 * - Only the publishable (anon) key is ever used. NEVER put the secret key
 *   in config.js — it would be visible in DevTools. The secret key is for
 *   server-side use only.
 */
(() => {
  "use strict";

  const cfg = (window.BUILDX_CONFIG && window.BUILDX_CONFIG.supabase) || {};
  const SUPABASE_URL = String(cfg.url || "").trim().replace(/\/$/, "");
  const SUPABASE_ANON_KEY = String(cfg.anonKey || "").trim();
  const enabled = Boolean(SUPABASE_URL && SUPABASE_ANON_KEY && window.supabase);

  let client = null;
  let user = null;
  let dbStatus = { ok: false, checked: false, missingTables: false, message: "not checked" };

  function store() { return window.VeyraStore; }

  function initClient() {
    if (!enabled) return null;
    if (!client) client = window.supabase.createClient(SUPABASE_URL, SUPABASE_ANON_KEY);
    return client;
  }

  // Ensure a local demo account mirrors the Supabase user so all existing
  // synchronous Store/app.js code paths (viewer, connections, history)
  // keep working unchanged.
  function ensureLocalMirror(sbUser, extra = {}) {
    const S = store();
    const email = String(sbUser.email || extra.identifier || "").toLowerCase().trim();
    let account = email ? S.findAccount(email) : null;
    if (!account) {
      let created = null;
      try {
        created = S.createAccount({
          identifier: email || ("supabase-" + sbUser.id),
          identifierType: "email",
          firstName: String(extra.firstName || "Veyra").slice(0, 50),
          lastName: String(extra.lastName || "User").slice(0, 50),
          accountType: extra.accountType === "company" ? "company" : "job-seeker",
        });
      } catch (err) {
        // Account race (e.g. created between find + create): re-read it.
        if (String(err && err.message) === "account_exists" && email) {
          created = S.findAccount(email);
          if (created) localStorage.setItem(S.keys.session, created.id);
        } else { throw err; }
      }
      account = S.getCurrentAccount() || created;
    } else {
      // Make this the active session.
      localStorage.setItem(S.keys.session, account.id);
    }
    return S.getCurrentAccount() || account;
  }

  async function pullProfile() {
    if (!client || !user) return null;
    const { data, error } = await client.from("profiles").select("*").eq("id", user.id).maybeSingle();
    if (error) { console.warn("Supabase pull failed", error); return null; }
    return data || null;
  }

  async function pushProfile() {
    if (!client || !user) return { error: "no_session" };
    try {
      const S = store();
      const account = S.getCurrentAccount();
      if (!account) return { error: "no_account" };
      const row = {
        id: user.id,
        email: user.email || account.identifier,
        first_name: account.firstName || "",
        last_name: account.lastName || "",
        account_type: account.accountType || "job-seeker",
        profile: account.profile || {},
        company: account.company || null,
      };
      const { error } = await client.from("profiles").upsert(row, { onConflict: "id" });
      if (error) {
        console.warn("Supabase push failed", error);
        markDbError(error);
        return { error };
      }
      dbStatus = { ok: true, checked: true, missingTables: false, message: "connected" };
      return { ok: true };
    } catch (err) { console.warn("Supabase push failed", err); return { error: err }; }
  }

  function markDbError(error) {
    const msg = String((error && (error.message || error.code || error)) || "").toLowerCase();
    const details = String(JSON.stringify(error || "")).toLowerCase();
    const missing = msg.includes("not found") || msg.includes("does not exist") || msg.includes("pgrst205")
      || details.includes("pgrst205") || msg.includes("404") || details.includes("404")
      || String(error && error.code || "") === "42P01";
    dbStatus = {
      ok: false, checked: true, missingTables: missing,
      message: missing ? "tables_missing" : String((error && error.message) || "db_error").slice(0, 200),
    };
  }

  // Explicit health check: tells "tables missing — run supabase.sql" apart
  // from generic network/RLS errors. Safe to call any time (anon, no login).
  async function checkDatabase() {
    if (!enabled) return { ok: false, checked: true, missingTables: false, message: "disabled" };
    initClient();
    try {
      const { error } = await client.from("profiles").select("id").limit(1);
      if (error) { markDbError(error); return { ...dbStatus }; }
      dbStatus = { ok: true, checked: true, missingTables: false, message: "connected" };
      return { ...dbStatus };
    } catch (err) { markDbError(err); return { ...dbStatus }; }
  }

  function getDbStatus() { return { ...dbStatus }; }

  function applyRemoteToLocal(remote) {
    if (!remote) return;
    try {
      const S = store();
      const current = S.getCurrentAccount();
      if (!current) return;
      const accounts = S.listAccounts();
      const i = accounts.findIndex((a) => String(a.id) === String(current.id));
      if (i < 0) return;
      if (remote.first_name || remote.last_name) {
        accounts[i].firstName = String(remote.first_name || accounts[i].firstName).slice(0, 50);
        accounts[i].lastName = String(remote.last_name || accounts[i].lastName).slice(0, 50);
      }
      if (remote.account_type === "company" || remote.account_type === "job-seeker") {
        accounts[i].accountType = remote.account_type;
      }
      if (remote.profile && typeof remote.profile === "object" && Object.keys(remote.profile).length) {
        accounts[i].profile = remote.profile;
      }
      if (remote.company !== undefined) accounts[i].company = remote.company;
      localStorage.setItem(S.keys.accounts, JSON.stringify(accounts));
    } catch (err) { console.warn("Supabase merge failed", err); }
  }

  async function pullConnectionsIntoCache() {
    if (!client || !user) return;
    try {
      const S = store();
      const { data, error } = await client.from("connections").select("target_id").eq("user_id", user.id);
      if (error) throw error;
      if (Array.isArray(data)) S.setConnections(data.map((r) => r.target_id));
    } catch { /* keep local cache */ }
  }

  async function init() {
    if (!enabled) { console.info("Supabase disabled — missing config or CDN."); return { enabled: false }; }
    initClient();
    try {
      const { data } = await client.auth.getSession();
      user = (data && data.session && data.session.user) || null;
      if (user) {
        const remote = await pullProfile();
        ensureLocalMirror(user);
        // Remote wins on first cloud login so devices stay in sync.
        if (remote && (remote.profile || remote.company)) applyRemoteToLocal(remote);
        else await pushProfile();
        await pullConnectionsIntoCache();
      }
      client.auth.onAuthStateChange(async (event, session) => {
        user = (session && session.user) || null;
        if (event === "SIGNED_IN" && user) { ensureLocalMirror(user); await pushProfile(); }
        if (event === "SIGNED_OUT") { try { store().signOut(); } catch { /* noop */ } }
      });
    } catch (err) { console.warn("Supabase init failed", err); }
    return { enabled: true, user };
  }

  async function signUp({ email, password, firstName, lastName, accountType }) {
    initClient();
    if (!client) throw new Error("supabase_disabled");
    const redirectTo = (typeof location !== "undefined" && location.origin) ? (location.origin + location.pathname) : undefined;
    const { data, error } = await client.auth.signUp({ email, password, options: redirectTo ? { emailRedirectTo: redirectTo } : undefined });
    if (error) throw error;
    const sessionUser = (data && data.session && data.session.user) || null;
    if (!sessionUser) {
      // Email confirmation is ON in Supabase: the Auth user now exists, but
      // there is NO session yet, so RLS would reject every write and the user
      // is effectively still a guest. Do NOT fake a login here.
      user = null;
      return { needsConfirmation: true, pendingEmail: email, user: (data && data.user) || null };
    }
    user = sessionUser;
    ensureLocalMirror(user, { identifier: email, firstName, lastName, accountType });
    await pushProfile();
    return { needsConfirmation: false, user };
  }

  async function signIn({ email, password }) {
    initClient();
    if (!client) throw new Error("supabase_disabled");
    const { data, error } = await client.auth.signInWithPassword({ email, password });
    if (error) throw error;
    user = (data && data.user) || null;
    if (user) {
      ensureLocalMirror(user, { identifier: email });
      const remote = await pullProfile();
      if (remote && (remote.profile || remote.company)) applyRemoteToLocal(remote);
      else await pushProfile();
      await pullConnectionsIntoCache();
    }
    return data;
  }

  async function signOut() {
    try { await (client && client.auth.signOut()); } catch { /* noop */ }
    user = null;
    try { store().signOut(); } catch { /* noop */ }
  }

  function currentUser() { return user; }
  function isEnabled() { return enabled; }

  // Fire-and-forget sync helpers for app.js to call after local mutations.
  function syncProfile() { pushProfile(); }
  async function syncConnections(ids) {
    if (!client || !user) return;
    try {
      const targets = Array.from(new Set((ids || []).map(String))).filter(Boolean).slice(0, 500);
      const { error: delError } = await client.from("connections").delete().eq("user_id", user.id);
      if (delError) throw delError;
      if (targets.length) {
        const { error: insError } = await client
          .from("connections")
          .insert(targets.map((t) => ({ user_id: user.id, target_id: t })));
        if (insError) throw insError;
      }
    } catch (err) { console.warn("Supabase connections sync failed", err); }
  }
  async function logAgent(role, content) {
    if (!client || !user) return;
    try { await client.from("agent_history").insert({ user_id: user.id, role, content: String(content || "").slice(0, 4000) }); }
    catch (err) { console.warn("Supabase agent log failed", err); }
  }

  // Map a public.profiles row to the profile shape the UI renders.
  // `profile` jsonb already mirrors store.js sanitizeProfile() output.
  function rowToProfile(row) {
    const base = (row && row.profile && typeof row.profile === "object") ? row.profile : {};
    const fullName = `${String(row.first_name || "").trim()} ${String(row.last_name || "").trim()}`.trim();
    const name = (base.name && (base.name.fa || base.name.en)) ? base.name : { fa: fullName, en: fullName };
    const email = String(row.email || "").trim().toLowerCase();
    const loc = (v) => (v && typeof v === "object") ? v : { fa: String(v || ""), en: String(v || "") };
    return {
      ...base,
      id: row.id,
      email,
      identifier: email,
      source: "supabase",
      name,
      headline: loc(base.headline),
      location: loc(base.location),
      about: loc(base.about),
      goals: loc(base.goals),
      skills: Array.isArray(base.skills) ? base.skills : [],
      interests: Array.isArray(base.interests) ? base.interests : [],
      targetRoles: Array.isArray(base.targetRoles) ? base.targetRoles : [],
      experience: Array.isArray(base.experience) ? base.experience : [],
      education: Array.isArray(base.education) ? base.education : [],
      projects: Array.isArray(base.projects) ? base.projects : [],
      preferences: (base.preferences && typeof base.preferences === "object") ? base.preferences : {},
      aiRecommendations: Array.isArray(base.aiRecommendations) ? base.aiRecommendations : [],
    };
  }

  // Public directory: every job-seeker profile in Supabase, newest first.
  // Readable by anon thanks to the "profiles public read" RLS policy, so the
  // People page works even before login.
  async function fetchDirectory() {
    if (!enabled) return [];
    initClient();
    if (!client) return [];
    try {
      const { data, error } = await client
        .from("profiles")
        .select("id,email,first_name,last_name,account_type,profile")
        .neq("account_type", "company")
        .order("updated_at", { ascending: false })
        .limit(300);
      if (error) { markDbError(error); return []; }
      return (data || []).map(rowToProfile);
    } catch (err) { console.warn("Supabase directory fetch failed", err); return []; }
  }

  window.VeyraCloud = Object.freeze({ isEnabled, init, signUp, signIn, signOut, currentUser, pullProfile, syncProfile, syncConnections, logAgent, checkDatabase, getDbStatus, fetchDirectory });
})();
