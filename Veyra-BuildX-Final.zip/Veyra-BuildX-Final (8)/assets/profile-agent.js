(() => {
  "use strict";

  const SKILL_ALIASES = [
    ["react", "React"], ["typescript", "TypeScript"], ["javascript", "JavaScript"], ["python", "Python"],
    ["next.js", "Next.js"], ["node.js", "Node.js"], ["node", "Node.js"], ["sql", "SQL"], ["html", "HTML"], ["css", "CSS"],
    ["figma", "Figma"], ["product design", "Product Design"], ["ux research", "UX Research"], ["prototyping", "Prototyping"],
    ["ai research", "AI Research"], ["human–ai interaction", "Human–AI Interaction"], ["hci", "HCI"], ["evaluation", "Evaluation"],
    ["backend", "Backend"], ["apis", "APIs"], ["llm", "LLM Systems"], ["developer tools", "Developer Tools"],
    ["product strategy", "Product Strategy"], ["growth", "Growth"], ["git", "Git"], ["github", "GitHub"], ["vue", "Vue"],
    ["django", "Django"], ["fastapi", "FastAPI"], ["docker", "Docker"], ["kubernetes", "Kubernetes"],
  ];

  const PERSIAN_NUMBERS = { صفر: 0, یک: 1, دو: 2, سه: 3, چهار: 4, پنج: 5, شش: 6, هفت: 7, هشت: 8, نه: 9, ده: 10 };
  const ENGLISH_NUMBERS = {one: 1, two: 2, three: 3, four: 4, five: 5, six: 6, seven: 7, eight: 8, nine: 9, ten: 10};
  const normalized = (value) => String(value || "").replace(/[۰-۹]/g, (char) => String("۰۱۲۳۴۵۶۷۸۹".indexOf(char))).replace(/\s+/g, " ").trim();
  const sentence = (value) => String(value || "").trim().replace(/[\s\n]+/g, " ").slice(0, 700);
  const lower = (value) => normalized(value).toLocaleLowerCase();

  function extractDuration(message) {
    const text = normalized(message);
    const english = text.match(/\bfor\s+(\d+|one|two|three|four|five|six|seven|eight|nine|ten)\s+(year|years|month|months)\b/i);
    if (english) { const amount = /^\d+$/.test(english[1]) ? Number(english[1]) : ENGLISH_NUMBERS[english[1].toLowerCase()]; return `${amount} ${english[2].toLowerCase().startsWith("year") ? "years" : "months"}`; }
    const persian = text.match(/به مدت\s+(\d+|یک|دو|سه|چهار|پنج|شش|هفت|هشت|نه|ده)\s*(سال|ماه)/i);
    if (persian) {
      const numeric = /^\d+$/.test(persian[1]) ? Number(persian[1]) : PERSIAN_NUMBERS[persian[1]];
      return `${numeric} ${persian[2] === "سال" ? "years" : "months"}`;
    }
    return "";
  }

  function extractPeriod(message) {
    const text = normalized(message);
    const english = text.match(/\b(?:from|between)\s+(\d{4})\s+(?:to|and)\s+(\d{4}|now|present)\b/i);
    if (english) return `${english[1]} — ${english[2]}`;
    const persian = text.match(/از\s+(\d{4})\s+تا\s+(\d{4}|الان|اکنون)/i);
    if (persian) return `${persian[1]} — ${persian[2]}`;
    return "";
  }

  function extractCompany(message) {
    const text = sentence(message);
    const patterns = [
      /\bat\s+([A-Z][^,.!?\n]+?)(?=\s+(?:for|from|between|and|using)\b|[,.!?]|$)/,
      /در\s+شرکت\s+([^،,.!?\n]+?)(?=\s+(?:به مدت|از|تا|و)\b|[،,.!?]|$)/i,
    ];
    for (const pattern of patterns) {
      const match = text.match(pattern);
      if (match?.[1]) return match[1].trim().slice(0, 100);
    }
    return "";
  }

  function extractRole(message) {
    const text = sentence(message);
    const patterns = [
      /\bworked\s+as\s+(?:a|an)\s+(.+?)(?=\s+(?:for|at|from|between|and|mainly|using)\b|[,.!?]|$)/i,
      /\bI(?:'m| am)\s+(?:a|an)\s+(.+?)(?=\s+(?:with|using|at|and)\b|[,.!?]|$)/i,
      /به\s+عنوان\s+(.+?)(?=\s+(?:به مدت|در|با|و)\b|[،,.!?]|$)/i,
      /من\s+(.+?)\s+هستم(?=\s|[،,.!?]|$)/i,
    ];
    for (const pattern of patterns) {
      const match = text.match(pattern);
      if (match?.[1]) return match[1].trim().replace(/^یک\s+/i, "").replace(/^a\s+/i, "").replace(/^an\s+/i, "").slice(0, 100);
    }
    return "";
  }

  function extractSkills(message, allowedSkills = []) {
    const source = lower(message);
    const aliases = new Map([...SKILL_ALIASES, ...(allowedSkills || []).map((skill) => [String(skill).toLocaleLowerCase(), String(skill)])]);
    const result = [];
    for (const [alias, canonical] of aliases) {
      const escaped = alias.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
      const matched = alias.includes(" ") || /[.+#-]/.test(alias)
        ? source.includes(alias)
        : new RegExp(`(?:^|[^\\p{L}\\p{N}])${escaped}(?:$|[^\\p{L}\\p{N}])`, "u").test(source);
      if (matched && !result.includes(canonical)) result.push(canonical);
    }
    return result.slice(0, 12);
  }
  function extractEducation(message) {
    const text = sentence(message);
    const patterns = [
      /(?:studied|graduated|degree in)\s+(.+?)\s+at\s+(.+?)(?=[,.!?]|$)/i,
      /رشته(?:‌|\s)ی?\s+(.+?)\s+را\s+در\s+(.+?)\s+خواندم/i,
      /فارغ‌التحصیل\s+(?:رشته\s+)?(.+?)\s+از\s+(.+?)(?=[،,.!?]|$)/i,
    ];
    for (const pattern of patterns) {
      const match = text.match(pattern);
      if (match?.[1]) return { degree: match[1].trim().slice(0, 100), school: match[2]?.trim().slice(0, 120) || "", period: "" };
    }
    return null;
  }

  function splitList(value) {
    return String(value || "").split(/,|;|\band\b|\bor\b| و | یا /i).map((item) => item.trim()).filter(Boolean).slice(0, 8);
  }

  function extractTargetRoles(message) {
    const text = sentence(message);
    const patterns = [
      /(?:looking for|want to work as|want to be|want to become|target roles?|roles? i(?:'m| am) interested in)\s+(.+?)(?:[.!?]|$)/i,
      /(?:می\s*خواهم|می\s*خوام|دنبال)\s+(?:نقش|نقش‌های|نقش ها|سمت)\s+(.+?)(?:[.!?]|$)/i,
      /(?:هدفم|نقش‌های هدفم|نقش هدف)\s*[:：]\s*(.+?)(?:[.!?]|$)/i,
    ];
    for (const pattern of patterns) {
      const match = text.match(pattern);
      if (match?.[1]) return splitList(match[1].replace(/^(?:a|an)\s+/i, "").replace(/^به عنوان\s+/i, ""));
    }
    if (text.split(/,|;|\band\b|\bیا\b| و | یا /i).length > 1) return splitList(text);
    return text ? [text.slice(0, 100)] : [];
  }

  function extractGoal(message) {
    const text = sentence(message);
    const patterns = [
      /(?:my goal is|career goal|i want to)\s+(.+?)(?:[.!?]|$)/i,
      /(?:هدفم|هدف شغلی|هدف حرفه‌ای|می\s*خواهم به)\s*[:：]?\s*(.+?)(?:[.!?]|$)/i,
    ];
    for (const pattern of patterns) {
      const match = text.match(pattern);
      if (match?.[1]) return match[1].trim().slice(0, 500);
    }
    return text ? text.slice(0, 500) : "";
  }

  function extractInterest(message) {
    const text = sentence(message);
    const patterns = [/\binterested\s+in\s+(.+?)(?:[.!?]|$)/i, /علاقه‌مند\s+به\s+(.+?)(?:[.!?]|$)/i, /به\s+(.+?)\s+علاقه\s+دارم(?:[.!?]|$)/i];
    for (const pattern of patterns) {
      const match = text.match(pattern);
      if (match?.[1]) return match[1].trim().replace(/\s+(?:هستم|ام)$/i, "").slice(0, 100);
    }
    return "";
  }

  function extractAbout(message) {
    const text = sentence(message);
    if (/(^|\s)(about me|درباره من|توضیح کوتاه درباره خودم)[:：]/i.test(text)) return text.split(/[:：]/).slice(1).join(":").trim().slice(0, 700);
    return "";
  }

  function isSkip(message) {
    return /^(رد|رد می‌کنم|ندارم|فعلاً ندارم|skip|pass|none|not now|prefer not to say|i am not sure|i'm not sure|i am unsure|i'm unsure|فعلاً نه)$/i.test(String(sentence(message)).replace(/[.!?]+$/, "").trim());
  }

  function nextQuestion(profile, skipped = {}) {
    const experience = Array.isArray(profile?.experience) ? profile.experience : [];
    const current = experience[0] || null;
    if (!experience.length && !skipped.experience) return { key: "experience", textFa: "از تجربه کاری شروع کنیم: نقش، مدت تجربه، شرکت (اگر می‌خواهی) و بازه زمانی را با هر مقدار جزئیاتی که واقعاً داری بگو. مثال: «دو سال به‌عنوان Frontend Developer کار کردم و با React و TypeScript کار می‌کردم.»", textEn: "Let's start with experience: tell me your role, duration, company (if you want), and timeframe using only what you know. Example: “I worked as a frontend developer for two years and used React and TypeScript.”" };
    if (current && (!current.company || !current.period) && !skipped.experienceDetail) return { key: "experienceDetail", textFa: `برای سابقه «${current.role || "این نقش"}»، نام شرکت/تیم و بازه زمانی را می‌دانی؟ اگر نمی‌خواهی وارد کنی، «رد می‌کنم» بگو.`, textEn: `For “${current.role || "this role"}”, do you know the company/team and timeframe? Say “skip” if you do not want to add them.` };
    if (!(profile?.skills || []).length && !skipped.skills) return { key: "skills", textFa: "مهارت‌های اصلی‌ات را فهرست کن؛ فقط مواردی را ثبت می‌کنم که خودت صریحاً می‌گویی.", textEn: "List your core skills; I will only record skills you explicitly mention." };
    if (!(profile?.education || []).length && !skipped.education) return { key: "education", textFa: "تحصیلات مرتبطی داری؟ رشته و مؤسسه را بگو؛ نداشتن یا واردنکردنش هم کاملاً قابل قبول است.", textEn: "Do you have relevant education? Tell me the field and institution; skipping is completely fine." };
    if (!(profile?.targetRoles || []).length && !skipped.targetRoles) return { key: "targetRoles", textFa: "چه نقش‌هایی را برای قدم بعدی شغلی‌ات مدنظر داری؟ می‌توانی یک یا چند نقش مشخص بگویی.", textEn: "Which roles are you considering for your next career step? You can name one or several specific roles." };
    if (!(profile?.interests || []).length && !skipped.interests) return { key: "interests", textFa: "الان بیشتر به چه مسیرها یا حوزه‌های حرفه‌ای علاقه داری؟", textEn: "Which professional directions or areas interest you most right now?" };
    if (!String(profile?.about?.fa || profile?.about?.en || "").trim() && !skipped.about) return { key: "about", textFa: "در یک یا دو جمله بگو روی چه نوع مسئله‌ای کار می‌کنی یا دوست داری چه ارزشی بسازی.", textEn: "In one or two sentences, describe the problems you work on or the value you want to create." };
    if (!String(profile?.goals?.fa || profile?.goals?.en || "").trim() && !skipped.goals) return { key: "goals", textFa: "هدف حرفه‌ای نزدیکت چیست؟ یک جمله درباره قدمی که می‌خواهی در مسیرت برداری کافی است.", textEn: "What is your near-term professional goal? One sentence about the next step you want to take is enough." };
    return { key: "done", textFa: "اطلاعاتی که گفتی در پروفایل ساختاریافته شد. حالا می‌توانی آن را ویرایش کنی یا از Agent برای تحلیل و بهبودش کمک بگیری.", textEn: "The information you provided has been structured into your profile. You can now edit it or ask the Agent to analyze and improve it." };
  }

  function extract(message, questionKey, profile, allowedSkills) {
    const text = sentence(message);
    if (!text) return { patch: {}, facts: [], questionKey, skipped: false };
    if (isSkip(text)) return { patch: {}, facts: [`skipped:${questionKey}`], questionKey, skipped: true };

    const patch = {};
    const facts = [];
    const role = extractRole(text);
    const duration = extractDuration(text);
    const period = extractPeriod(text);
    const company = extractCompany(text);
    const skills = extractSkills(text, allowedSkills);
    const education = extractEducation(text);
    const interest = extractInterest(text);
    const targetRoles = extractTargetRoles(text);
    const goal = extractGoal(text);
    const about = extractAbout(text);

    if (["experience", "experienceDetail"].includes(questionKey) && (role || duration || period || company)) {
      const current = Array.isArray(profile?.experience) && profile.experience[0] ? {...profile.experience[0]} : {};
      const nextExperience = [{...current, role: role || current.role || "", company: company || current.company || "", period: period || current.period || "", duration: duration || current.duration || "", summary: current.summary || ""}];
      patch.experience = nextExperience;
      if (role) facts.push(`role:${role}`);
      if (duration) facts.push(`duration:${duration}`);
      if (company) facts.push(`company:${company}`);
      if (period) facts.push(`period:${period}`);
      if (role && !String(profile?.headline?.fa || profile?.headline?.en || "").trim()) patch.headline = role;
    }
    if (questionKey === "skills" || skills.length) {
      const merged = [...new Set([...(profile?.skills || []), ...skills])].slice(0, 16);
      if (merged.length > (profile?.skills || []).length) patch.skills = merged;
      skills.forEach((skill) => facts.push(`skill:${skill}`));
    }
    if (questionKey === "education" && education) { patch.education = [...(profile?.education || []), education].slice(0, 6); facts.push(`education:${education.degree}${education.school ? ` @ ${education.school}` : ""}`); }
    if (questionKey === "targetRoles") {
      if (targetRoles.length) { patch.targetRoles = [...new Set([...(profile?.targetRoles || []), ...targetRoles])].slice(0, 8); facts.push(`target-role:${targetRoles.join(", ")}`); }
    }
    if (questionKey === "interests") {
      const value = interest;
      if (value) { patch.interests = [...new Set([...(profile?.interests || []), value])].slice(0, 12); facts.push(`interest:${value}`); }
    }
    if (questionKey === "about") { patch.about = about || text; facts.push("about:explicit"); }
    if (questionKey === "goals") { patch.goals = {fa: goal, en: goal}; facts.push("goal:explicit"); }

    return { patch, facts, questionKey, skipped: false };
  }

  function summarizePatch(patch) {
    const facts = [];
    if (patch.headline) facts.push(`عنوان حرفه‌ای: ${patch.headline}`);
    if (Array.isArray(patch.skills) && patch.skills.length) facts.push(`مهارت‌ها: ${patch.skills.join(", ")}`);
    const exp = Array.isArray(patch.experience) && patch.experience[0];
    if (exp && (exp.role || exp.duration || exp.company || exp.period)) facts.push(`سابقه: ${[exp.role, exp.duration, exp.company, exp.period].filter(Boolean).join(" · ")}`);
    if (Array.isArray(patch.education) && patch.education.length) facts.push(`تحصیلات: ${patch.education.map((item) => [item.degree, item.school].filter(Boolean).join(" · ")).join(" | ")}`);
    if (Array.isArray(patch.interests) && patch.interests.length) facts.push(`علایق: ${patch.interests.join(", ")}`);
    if (Array.isArray(patch.targetRoles) && patch.targetRoles.length) facts.push(`نقش‌های هدف: ${patch.targetRoles.join(", ")}`);
    if (patch.about) facts.push("بخش About تکمیل شد");
    if (patch.goals) facts.push("هدف حرفه‌ای ثبت شد");
    return facts;
  }

  window.VeyraProfileAgent = Object.freeze({
    extract,
    nextQuestion,
    summarizePatch,
    isSkip,
    skillVocabulary: SKILL_ALIASES.map(([, canonical]) => canonical),
  });
})();
