(() => {
  "use strict";

  const normalize = (value) => String(value || "").replace(/\s+/g, " ").trim();
  const lower = (value) => normalize(value).toLocaleLowerCase();

  function extractCompanyName(message) {
    const text = normalize(message);
    const patterns = [
      /(?:company|organization|team)\s+(?:name\s+)?(?:is|called)\s+([^,.!?\n]+)/i,
      /(?:شرکت|سازمان|تیم)\s+(?:من|ما)?\s*(?:نامش|اسمش)?\s*(?:است|به نام)\s+([^،,.!?\n]+)/i,
    ];
    for (const pattern of patterns) {
      const match = text.match(pattern);
      if (match?.[1]) return match[1].trim().slice(0, 100);
    }
    return "";
  }

  function extractDesiredRole(message) {
    const text = normalize(message);
    const patterns = [
      /(?:hiring|looking for|need)\s+(?:a|an)?\s*([^,.!?\n]+?)(?=\s+(?:with|who|for)\b|[,.!?]|$)/i,
      /(?:استخدام|دنبال|نیاز)\s+(?:یک|یه)?\s*([^،,.!?\n]+?)(?=\s+(?:با|که|برای)\b|[،,.!?]|$)/i,
    ];
    for (const pattern of patterns) {
      const match = text.match(pattern);
      if (match?.[1]) return match[1].trim().replace(/^(?:a|an|یک|یه)\s+/i, "").slice(0, 100);
    }
    return "";
  }

  function extractSkills(message, vocabulary = []) {
    const source = lower(message);
    const found = [];
    for (const skill of vocabulary) {
      const key = lower(skill); if (!key) continue;
      const escaped = key.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
      const matched = key.includes(" ") || /[.+#-]/.test(key)
        ? source.includes(key)
        : new RegExp(`(?:^|[^\\p{L}\\p{N}])${escaped}(?:$|[^\\p{L}\\p{N}])`, "u").test(source);
      if (matched && !found.includes(skill)) found.push(skill);
    }
    return found.slice(0, 16);
  }
  function extractFocus(message) {
    const text = normalize(message);
    const patterns = [
      /(?:we build|we work on|our focus is|focus(?:es)? on)\s+(.+?)(?:[.!?]|$)/i,
      /(?:تمرکز ما|روی)\s+(.+?)(?:[.!?]|$)/i,
    ];
    for (const pattern of patterns) {
      const match = text.match(pattern);
      if (match?.[1]) return match[1].trim().slice(0, 160);
    }
    return "";
  }

  function extractLocation(message) {
    const text = normalize(message);
    const match = text.match(/(?:based in|located in|location is|in)\s+([^,.!?\n]+)/i) || text.match(/(?:مستقر در|موقعیت(?: ما)?|واقع در)\s+([^،,.!?\n]+)/i);
    return match?.[1] ? match[1].trim().slice(0, 100) : (text ? text.slice(0, 100) : "");
  }

  function extractType(message) {
    const text = normalize(message);
    const match = text.match(/(?:we are|we're|type is|company type is)\s+(?:a|an)?\s*(startup|scaleup|enterprise|community|research|studio|nonprofit)/i);
    return match?.[1] ? match[1].trim() : "";
  }

  function extractExperienceLevel(message) {
    const text = normalize(message).toLocaleLowerCase();
    for (const level of ["lead", "senior", "mid", "junior", "entry"]) if (new RegExp(`(^|\\s)${level}(?=\\s|$)`, "i").test(text)) return level;
    if (/ارشد/.test(text)) return "senior";
    if (/میانی/.test(text)) return "mid";
    if (/جونیور|junior/.test(text)) return "junior";
    return "";
  }

  function extractPreferences(message) {
    const text = normalize(message);
    const match = text.match(/(?:we want|looking for someone who|کسی که|فردی که)\s+(.+?)(?:[.!?]|$)/i);
    return match?.[1] ? [match[1].trim().slice(0, 160)] : [];
  }

  function nextQuestion(company, skipped = {}) {
    if (!String(company?.name || "").trim() && !skipped.name) return {key: "name", fa: "نام شرکت یا تیم را بگو. فقط همان چیزی را ثبت می‌کنم که خودت تأیید می‌کنی.", en: "What is the company or team name? I will only record what you explicitly confirm."};
    if (!String(company?.focus || "").trim() && !skipped.focus) return {key: "focus", fa: "شرکت روی چه محصول، حوزه یا مسئله‌ای کار می‌کند؟", en: "What product, domain, or problem does the company work on?"};
    if (!(company?.location || "").trim() && !skipped.location) return {key: "location", fa: "تیم در کجا مستقر است یا موقعیت جغرافیایی آن چیست؟", en: "Where is the team based, or what location context should candidates know?"};
    if (!(company?.type || "").trim() && !skipped.type) return {key: "type", fa: "نوع شرکت یا تیم چیست؟ مثلاً startup، research یا studio.", en: "What type of company or team is this? For example: startup, research, or studio."};
    if (!(company?.desiredRoles || []).length && !skipped.roles) return {key: "roles", fa: "برای چه نقش‌هایی استخدام می‌کنید یا قصد استخدام دارید؟", en: "Which roles are you hiring for or planning to hire for?"};
    if (!(company?.requiredSkills || []).length && !skipped.skills) return {key: "skills", fa: "چه مهارت‌هایی برای این نقش‌ها ضروری هستند؟", en: "Which skills are required for those roles?"};
    if (!(company?.preferredExperienceLevel || "").trim() && !skipped.experienceLevel) return {key: "experienceLevel", fa: "سطح تجربه مطلوب برای این استخدام چیست؟", en: "What experience level do you prefer for this hiring need?"};
    if (!(company?.preferredCharacteristics || []).length && !skipped.characteristics) return {key: "characteristics", fa: "چه ویژگی یا سابقه‌ای در کاندیدا برای شما مهم است؟", en: "What candidate characteristics or background matter to you?"};
    return {key: "done", fa: "اطلاعات سازمان و نیازهای استخدامی ساختاریافته شد. حالا می‌توانی کاندیداهای مرتبط را پیدا و fit آن‌ها را بررسی کنی.", en: "The company and hiring needs are now structured. You can find relevant candidates and analyze fit."};
  }

  function extract(message, questionKey, company, vocabulary = []) {
    const text = normalize(message);
    const patch = {};
    const facts = [];
    if (!text) return {patch, facts, skipped: false};
    if (/^(skip|pass|none|not sure|i do not know|i don't know|i am not sure|i'm not sure|i am unsure|i'm unsure|فعلاً نه|رد می‌کنم|نمی‌دانم|مطمئن نیستم|نداریم|ندارم)$/i.test(text.replace(/[.!?]+$/, "").trim())) return {patch, facts: [`skipped:${questionKey}`], skipped: true};
    if (questionKey === "name") {
      const name = extractCompanyName(text) || text.slice(0, 100);
      patch.name = name; facts.push(`company:${name}`);
    }
    if (questionKey === "focus") {
      const focus = extractFocus(text) || text.slice(0, 160); patch.focus = focus; facts.push(`focus:${focus}`);
    }
    if (questionKey === "location") {
      const location = extractLocation(text); if (location) { patch.location = location; facts.push(`location:${location}`); }
    }
    if (questionKey === "type") {
      const type = extractType(text) || text.slice(0, 80); if (type) { patch.type = type; facts.push(`type:${type}`); }
    }
    if (questionKey === "roles") {
      const role = extractDesiredRole(text) || text.slice(0, 100);
      patch.desiredRoles = [...new Set([...(company?.desiredRoles || []), role])].slice(0, 8);
      patch.openPositions = [...(company?.openPositions || []), {title: role, skills: company?.requiredSkills || [], location: company?.location || "", workMode: "", level: company?.preferredExperienceLevel || ""}].slice(0, 8);
      facts.push(`role:${role}`);
    }
    if (questionKey === "skills") {
      const skills = extractSkills(text, vocabulary);
      patch.requiredSkills = [...new Set([...(company?.requiredSkills || []), ...skills])].slice(0, 16);
      patch.openPositions = (company?.openPositions || []).map((item) => ({...item, skills: [...new Set([...(item.skills || []), ...skills])].slice(0, 16)}));
      skills.forEach((skill) => facts.push(`skill:${skill}`));
    }
    if (questionKey === "experienceLevel") {
      const level = extractExperienceLevel(text); if (level) {
        patch.preferredExperienceLevel = level;
        patch.openPositions = (company?.openPositions || []).map((item) => ({...item, level}));
        facts.push(`experience-level:${level}`);
      }
    }
    if (questionKey === "characteristics") {
      const values = extractPreferences(text); patch.preferredCharacteristics = [...new Set([...(company?.preferredCharacteristics || []), ...(values.length ? values : [text.slice(0, 160)])])].slice(0, 8); facts.push("candidate-characteristics:explicit");
    }
    return {patch, facts, skipped: false};
  }

  function summarize(patch) {
    const out = [];
    if (patch.name) out.push(`Company: ${patch.name}`);
    if (patch.focus) out.push(`Focus: ${patch.focus}`);
    if (patch.location) out.push(`Location: ${patch.location}`);
    if (patch.type) out.push(`Type: ${patch.type}`);
    if (patch.desiredRoles?.length) out.push(`Roles: ${patch.desiredRoles.join(", ")}`);
    if (patch.requiredSkills?.length) out.push(`Required skills: ${patch.requiredSkills.join(", ")}`);
    if (patch.preferredExperienceLevel) out.push(`Experience level: ${patch.preferredExperienceLevel}`);
    if (patch.preferredCharacteristics?.length) out.push(`Candidate characteristics: ${patch.preferredCharacteristics.join("; ")}`);
    return out;
  }

  window.VeyraCompanyAgent = Object.freeze({extract, nextQuestion, summarize});
})();
