import pathlib
t = pathlib.Path("index.html").read_text(encoding="utf-8")
i = t.find("authForm")
pathlib.Path("_out.txt").write_text(t[max(0,i-200):i+2500], encoding="utf-8")
