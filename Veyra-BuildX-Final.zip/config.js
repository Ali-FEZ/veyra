/**
 * Public browser configuration — TEMPORARY DEMO ONLY.
 *
 * This demo build calls the GapGPT OpenAI-compatible API directly from the
 * browser (plain fetch, no npm / no build step required):
 *   POST https://api.gapgpt.app/v1/chat/completions
 *   model: gapgpt-gemma-26b-a4b
 *
 * WARNING: the API key below is visible to anyone who opens DevTools.
 * This is accepted for a temporary local demo only. Remove / rotate the key
 * after testing and never ship it in a production site.
 *
 * The project is a static site (HTML + Vanilla JS, GitHub Pages compatible).
 * No `import OpenAI from 'openai'` is used in the browser; assets/ai.js
 * performs the equivalent OpenAI-compatible HTTP request with fetch.
 */
window.BUILDX_CONFIG = Object.freeze({
  // Legacy server-side proxy endpoint (unused in this GapGPT demo build).
  agentEndpoint: "",
  agentTimeoutMs: 45000,
  gapgpt: Object.freeze({
    baseURL: "https://api.gapgpt.app/v1",
    apiKey: "sk-vbmEQmRSFSV9HSAf0oCYW3vw3NS9xhokBTHggqbG1N9xAFqm",
    model: "gapgpt-gemma-26b-a4b",
    temperature: 0.3,
    maxTokens: 900,
  }),
});
