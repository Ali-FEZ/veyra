/**
 * Public browser configuration.
 * Never place API keys, tokens, passwords, or other secrets here.
 *
 * Veyra can run entirely as a static Demo. For live Gemini calls, point this
 * value at a separately deployed proxy that stores GEMINI_API_KEY server-side.
 */
window.BUILDX_CONFIG = Object.freeze({
  agentEndpoint: "",
  agentTimeoutMs: 45000,
});
