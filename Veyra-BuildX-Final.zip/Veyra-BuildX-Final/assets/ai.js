(() => {
  "use strict";

  const CONFIG = window.BUILDX_CONFIG || {};
  const ENDPOINT = String(CONFIG.agentEndpoint || "").trim().replace(/\/$/, "");
  const TIMEOUT_MS = Number(CONFIG.agentTimeoutMs || 45000);
  const ACTIONS = new Set([
    "none", "collect_profile_facts", "collect_company_facts", "find_jobs", "find_similar_jobs", "analyze_job",
    "find_candidates", "analyze_candidate", "analyze_profile", "analyze_company", "suggest_skills", "skill_gap", "career_direction",
    "update_preferences", "improve_profile",
  ]);

  function configured() { return Boolean(ENDPOINT); }

  function isPlainObject(value) {
    return Boolean(value) && typeof value === "object" && !Array.isArray(value);
  }

  function validatePayload(payload) {
    if (!isPlainObject(payload)) throw new Error("invalid_agent_response");
    if (typeof payload.reply !== "string") throw new Error("invalid_agent_response_reply");
    if (typeof payload.action !== "string" || !ACTIONS.has(payload.action)) throw new Error("invalid_agent_action");
    for (const key of ["profilePatch", "companyPatch", "preferencePatch"]) {
      if (payload[key] != null && !isPlainObject(payload[key])) throw new Error(`invalid_${key}`);
    }
    if (payload.targetId != null && typeof payload.targetId !== "string") throw new Error("invalid_target_id");
    if (payload.nextQuestion != null && (typeof payload.nextQuestion !== "string" || payload.nextQuestion.length > 600)) throw new Error("invalid_next_question");
    return payload;
  }

  async function run({message, context, history = [], operation = "chat"}) {
    if (!ENDPOINT) throw new Error("agent_endpoint_not_configured");
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), TIMEOUT_MS);
    try {
      const response = await fetch(ENDPOINT, {
        method: "POST",
        headers: {"Content-Type": "application/json", Accept: "application/json"},
        body: JSON.stringify({message, context, history: history.slice(-12), operation}),
        signal: controller.signal,
      });
      let payload = null;
      try { payload = await response.json(); } catch { payload = null; }
      if (!response.ok) {
        const detail = payload?.error || `HTTP ${response.status}`;
        throw new Error(detail);
      }
      validatePayload(payload);
      if (payload.error) throw new Error(String(payload.error));
      return {
        reply: String(payload.reply || "").trim(),
        action: typeof payload.action === "string" ? payload.action : "none",
        profilePatch: payload.profilePatch && typeof payload.profilePatch === "object" ? payload.profilePatch : null,
        companyPatch: payload.companyPatch && typeof payload.companyPatch === "object" ? payload.companyPatch : null,
        preferencePatch: payload.preferencePatch && typeof payload.preferencePatch === "object" ? payload.preferencePatch : null,
        targetId: payload.targetId ? String(payload.targetId) : null,
        nextQuestion: typeof payload.nextQuestion === "string" ? payload.nextQuestion : null,
        provider: String(payload.provider || "Google AI Studio / Gemini"),
      };
    } finally {
      clearTimeout(timer);
    }
  }

  window.VeyraAI = Object.freeze({configured, run});
})();
