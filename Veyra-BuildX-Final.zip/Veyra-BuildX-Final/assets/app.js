(() => {
  "use strict";

  const CONFIG = window.BUILDX_CONFIG || {};
  const DATA_URL = "data/network.json";
  const Store = window.VeyraStore;
  const ProfileAgent = window.VeyraProfileAgent;
  const CompanyAgent = window.VeyraCompanyAgent;
  const Matching = window.VeyraMatching;
  const AI = window.VeyraAI;

  const copy = {
    fa: {
      home: "خانه", people: "افراد", opportunities: "فرصت‌ها", organizations: "سازمان‌ها", profile: "پروفایل", aboutNav: "درباره",
      authEntry: "ورود / ثبت‌نام", authTitle: "ورود به Veyra", authHeadline: "هویت حرفه‌ای‌ات را بساز.", authJoin: "ساخت حساب", authSignIn: "ورود", authIdentifier: "ایمیل یا شماره موبایل", authIdentifierType: "نوع شناسه", authEmail: "ایمیل", authPhone: "موبایل", firstName: "نام", lastName: "نام خانوادگی", createAccount: "ساخت حساب و شروع", signInAction: "ورود به حساب", signOut: "خروج", openMyProfile: "پروفایل من",
      agentInputLabel: "سؤال از Agent", agentDialogInputLabel: "سؤال از Agent درباره context", authDesc: "برای ساخت و نگهداری پروفایل حرفه‌ای حساب لازم است؛ مرور افراد، فرصت‌ها و سؤال عمومی از Agent بدون حساب هم ممکن است.", authDemoNote: "این Stage از Browser/Demo persistence استفاده می‌کند: اطلاعات حساب فقط در همین مرورگر ذخیره می‌شود و Authentication سرور-واقعی نیست.", accountCreated: "حساب Demo ساخته شد. حالا Agent را برای ساخت پروفایل شروع کن.", accountSignedIn: "وارد حساب Demo شدی.", accountSignedOut: "از حساب Demo خارج شدی.", accountExists: "این شناسه قبلاً در این مرورگر ثبت شده است؛ از تب ورود استفاده کن.", accountNotFound: "حسابی با این شناسه در این مرورگر پیدا نشد.", authValidation: "شناسه، نام و نام خانوادگی را کامل کن.", authIdentifierValidation: "یک ایمیل یا شماره موبایل معتبر وارد کن.",
      heroKicker: "هویت حرفه‌ای + Agent", jobSeekerPathEyebrow: "FOR PROFESSIONALS", jobSeekerPathTitle: "پروفایلت را بساز، بعد با context فرصت انتخاب کن.", jobSeekerPathDesc: "Agent از اطلاعات واقعی تو شروع می‌کند و از Profile تا fit و skill gap همراهت می‌آید.", startAsProfessional: "شروع برای کارجو", companyPathEyebrow: "FOR TEAMS", companyPathTitle: "نیاز استخدامی را تعریف کن؛ Agent کاندیدای مرتبط را پیدا می‌کند.", companyPathDesc: "Company Agent روی role، skill، تجربه و gapهای استخدامی تمرکز دارد؛ نه تجربه‌ای شبیه job seeker.", startAsCompany: "تجربه شرکت", homeJobsEyebrow: "MATCHED OPPORTUNITIES", homeJobsTitle: "فرصت‌هایی که ارزش نگاه‌کردن دارند.", homeJobsDesc: "برای کارجوها این بخش با Profile و preference فعلی رتبه‌بندی می‌شود.", homeCompaniesTitle: "تیم‌هایی که فرصت می‌سازند.", homeCompaniesDesc: "تمرکز، location و رابطه آن‌ها با فرصت‌های موجود را در یک نگاه ببین.", viewCompanies: "مشاهده شرکت‌ها", howEyebrow: "HOW VEYRA WORKS", howTitle: "سه حرکت، یک جریان حرفه‌ای.", howDesc: "Veyra جست‌وجو را از identity جدا نمی‌کند.", howOneTitle: "Identity", howOneDesc: "اطلاعات واقعی تو یا نیاز واقعی شرکت به state ساختاریافته تبدیل می‌شود.", howTwoTitle: "Context", howTwoDesc: "Agent می‌فهمد الان درباره کدام Profile، Job یا hiring need حرف می‌زنیم.", howThreeTitle: "Decision", howThreeDesc: "Matching deterministic evidence می‌دهد؛ Agent آن را برای تصمیم بعدی توضیح می‌دهد.", homeCtaTitle: "یک سؤال حرفه‌ای را از همین‌جا شروع کن.", homeCtaDesc: "لازم نیست اول همه‌چیز را کامل بدانی؛ Agent از context موجود شروع می‌کند.", heroLead: "مسیر شغلی‌ات را", heroAccent: "با context بهتر بساز.", heroDesc: "Veyra هویت حرفه‌ای، آدم‌ها و فرصت‌ها را در یک جریان می‌آورد؛ Agent به تو کمک می‌کند اطلاعات خودت را ساختاریافته کنی و تصمیم حرفه‌ای بهتری بگیری.",
      exploreOpportunities: "دیدن فرصت‌ها", askAgent: "از Agent بپرس", proofOne: "context-aware", proofTwo: "state-connected", proofThree: "synthetic discovery data", agentVisualTitle: "Agent روی هویت حرفه‌ای تو می‌نشیند.", agentVisualDesc: "از ساخت Profile تا تحلیل یک فرصت، Agent با context مشخص کار می‌کند.", agentTitle: "Agent را بخشی از مسیر بدان.", agentDesc: "سؤال تو، context صفحه و پروفایل حرفه‌ای در یک جریان به هم می‌رسند.", agentOffline: "حالت Demo محلی فعال است؛ endpoint واقعی تنظیم نشده.", agentConnected: "Endpoint Agent تنظیم شده است.", agentChecking: "Endpoint Agent تنظیم شده است؛ پاسخ هنگام ارسال بررسی می‌شود.",
      peopleEyebrow: "PEOPLE", peoplePreviewTitle: "آدم‌ها پشت فرصت‌ها هستند.", peoplePreviewDesc: "پروفایل‌های حرفه‌ای را ببین و از Agent درباره relevance آن‌ها بپرس.", viewAll: "مشاهده همه", peopleTitle: "افراد و تخصص‌ها", peopleDesc: "پروفایل‌ها را با هویت حرفه‌ای، مهارت و حوزه علاقه پیدا کن.", peopleSearchPlaceholder: "نام، عنوان یا مهارت…", clear: "پاک‌کردن", demoDirectory: "DEMO directory",
      opportunityEyebrow: "OPPORTUNITIES", opportunitiesPreviewTitle: "فرصت‌ها را با context ببین.", opportunitiesPreviewDesc: "این داده‌ها مصنوعی‌اند و برای نمایش UX این Demo استفاده می‌شوند.", opportunitiesTitle: "فرصت‌های حرفه‌ای", opportunitiesDesc: "فرصت‌هایی را ببین که می‌توانند به پروفایل فعلی تو مرتبط باشند.", viewOpportunities: "همه فرصت‌ها", opportunityDemoNote: "فرصت‌ها synthetic demo data هستند؛ relevance با Matching Engine همین محصول محاسبه می‌شود.",
      orgEyebrow: "ORGANIZATIONS", orgTitle: "سازمان‌ها و تیم‌ها", orgDesc: "حوزه تمرکز، تیم و رابطه سازمان‌ها با فرصت‌های موجود را ببین.",
      profilePageTitle: "هویت حرفه‌ای", edit: "ویرایش", connect: "اتصال", connected: "متصل", askAboutProfile: "از Agent درباره این پروفایل بپرس", buildWithAgent: "ساخت پروفایل با Agent", continueWithAgent: "ادامه ساخت با Agent", improveProfile: "بهبود پروفایل", analyzeProfile: "تحلیل پروفایل", suggestSkills: "پیشنهاد مهارت", findMatching: "فرصت‌های مناسب", careerDirection: "تحلیل مسیر شغلی", profileCreated: "پروفایل ساخته شد", completeness: "کامل‌بودن پروفایل", accountRequired: "برای ساخت و ویرایش پروفایل وارد حساب شو.", createProfile: "ساخت پروفایل",
      about: "درباره", experience: "سابقه حرفه‌ای", education: "تحصیلات", projects: "پروژه‌ها", resume: "رزومه", skills: "مهارت‌ها", interests: "علایق حرفه‌ای", targetRoles: "نقش‌های هدف", professionalGoal: "هدف حرفه‌ای", openPositions: "موقعیت‌های باز", noOpenPositions: "هنوز موقعیت بازی ثبت نشده است.", preferences: "ترجیحات", aiRecommendations: "پیشنهادهای Agent", noExperience: "سابقه‌ای ثبت نشده است.", noEducation: "تحصیلاتی ثبت نشده است.", noProjects: "پروژه‌ای ثبت نشده است.", noResume: "رزومه‌ای ثبت نشده است.", profileSource: "اطلاعاتی که خودت وارد کرده‌ای", profileDemoSource: "DEMO / synthetic profile",
      context: "Agent Context", viewer: "پروفایل من", target: "پروفایل هدف", organization: "سازمان", opportunity: "فرصت", globalSearch: "GLOBAL SEARCH", searchTitle: "جستجوی سریع", searchPlaceholder: "نام فرد، مهارت، سازمان یا فرصت…", noResults: "نتیجه‌ای پیدا نشد.",
      editEyebrow: "PROFILE", editTitle: "ویرایش هویت حرفه‌ای", headline: "عنوان حرفه‌ای", location: "موقعیت", cancel: "انصراف", save: "ذخیره", educationHelp: "هر خط: رشته — مؤسسه — بازه (اختیاری)", projectsHelp: "هر خط: نام پروژه — توضیح — لینک اختیاری", resumeHelp: "فقط لینک یا عنوان رزومه را وارد کن.", addExperience: "افزودن سابقه", removeExperience: "حذف", role: "نقش", company: "شرکت / تیم", period: "بازه زمانی", duration: "مدت", summary: "شرح کوتاه",
      connectionSaved: "وضعیت اتصال در این مرورگر ذخیره شد.", profileSaved: "تغییرات پروفایل ذخیره شد.", saveFailed: "ذخیره تغییرات انجام نشد؛ داده‌ها دست‌نخورده باقی ماندند.", companyNeedsMoreContext: "برای ranking دقیق‌تر، نیاز استخدامی را کامل کن.", companyNeedsMoreContextDesc: "Agent می‌تواند role، skill و سطح تجربه موردنیاز را از تو بگیرد.", settings: "تنظیمات", language: "زبان", theme: "پوسته", settingsNote: "حساب‌ها، پروفایل‌ها، connection و Agent history در این Demo داخل localStorage ذخیره می‌شوند؛ Database مشترک وجود ندارد.", agentUnavailable: "Agent endpoint واقعی تنظیم نشده است؛ پاسخ این پیام از Demo Agent محلی ارائه می‌شود.", agentError: "پاسخ Agent در دسترس نبود. endpoint و وضعیت backend را بررسی کن.", knownContext: "context موجود", localData: "داده محلی", fullTime: "تمام‌وقت", research: "پژوهشی", memberCount: "عضو", focus: "تمرکز", type: "نوع", viewProfile: "مشاهده پروفایل", askAboutOpportunity: "درباره این فرصت بپرس", viewOrg: "مشاهده سازمان",
      aboutProblemEyebrow: "THE PROBLEM", aboutProblemTitle: "کشف حرفه‌ای معمولاً از context جداست.", aboutProblemDesc: "رزومه، آگهی و پروفایل هرکدام یک تکه از تصمیم‌اند. Veyra آن‌ها را کنار هم می‌گذارد تا relevance قابل توضیح داشته باشیم.", aboutAgentTitle: "چرا Agent مهم است؟", aboutAgentDesc: "Agent می‌تواند سؤال بپرسد، state را به action وصل کند و دلیل تناسب را بر اساس evidence موجود توضیح دهد.", creatorsEyebrow: "CREATED BY", creatorsTitle: "ساخته‌شده با دقت، برای یک تجربه Agent-native.", creatorRoleOne: "Product · AI · UX", creatorRoleTwo: "Engineering · Systems", creatorRoleThree: "Product · Design · Frontend", aboutCopyright: "این وب‌سایت توسط تیم فوق برای BuildX ساخته شده است.", similarOpportunities: "فرصت‌های مشابه", noSimilarOpportunities: "فرصت مشابهی در داده فعلی پیدا نشد.", aboutEyebrow: "ABOUT VEYRA", aboutTitle: "یک شبکه حرفه‌ای با Agent در مرکز.", aboutDesc: "Veyra یک BuildX Demo برای هویت حرفه‌ای و تعامل context-aware با Agent است.", aboutOneTitle: "Identity first", aboutOneDesc: "Profile از داده‌های واقعی و تأییدشده ساخته می‌شود؛ inference جای fact را نمی‌گیرد.", aboutTwoTitle: "Discovery with context", aboutTwoDesc: "Job، candidate و company هرکدام context خودشان را به Agent می‌دهند تا سؤال را لازم نباشد دوباره تعریف کنی.", aboutThreeTitle: "Lightweight by design", aboutThreeDesc: "هسته Demo بدون infrastructure سنگین کار می‌کند؛ state محلی و داده‌های synthetic برای نمایش جریان اصلی کافی هستند.", footerTag: "AI Career Network · BuildX Demo", openAgent: "بازکردن Agent",
      interviewTitle: "ساخت پروفایل با Agent", interviewDesc: "فقط اطلاعاتی را ثبت می‌کنم که خودت می‌گویی. هرجا داده‌ای مبهم یا ناقص باشد، سؤال می‌پرسم.", interviewProgress: "پیشرفت ساخت", interviewPlaceholder: "مثلاً: دو سال Frontend Developer بودم و با React و TypeScript کار کردم…", interviewSkip: "رد کردن", interviewDone: "پروفایل آماده است. حالا قابل ویرایش و تحلیل است.", localAgent: "Demo Agent · structured fallback", externalAgent: "LLM Agent · external endpoint", agentFactAdded: "به پروفایل اضافه شد", agentNoFact: "از این پیام fact ساختاریافته‌ای که بتوانم بدون حدس ثبت کنم پیدا نکردم.", authModeJoin: "ثبت‌نام", authModeSignIn: "ورود", sessionLabel: "حساب فعلی",
      skillSuggestionNote: "پیشنهادها فقط بر اساس skillهای صریح پروفایل و skillهای موردنیاز فرصت‌های Demo محاسبه شده‌اند؛ این LLM reasoning نیست.", matchingNote: "این فهرست بر اساس overlap مستقیم skillها با فرصت‌های synthetic همین Demo مرتب شده است.",
      retry: "تلاش دوباره", agentLoading: "Agent در حال تحلیل context است…", aiInterviewFailure: "سرویس AI در دسترس نبود؛ این مرحله با deterministic interviewer ادامه یافت و پاسخ LLM استفاده نشد.", companyDashboard: "داشبورد شرکت", accountType: "نوع حساب", jobSeeker: "کارجو", companyEmployer: "شرکت / کارفرما", companyOnboardingTitle: "تعریف نیازهای استخدامی با Agent", companyOnboardingDesc: "Agent درباره شرکت، نقش‌ها و معیارهای کاندیدا سؤال می‌پرسد و فقط اطلاعات تأییدشده را ذخیره می‌کند.", companyDone: "اطلاعات شرکت آماده است. حالا می‌توانی کاندیداهای مرتبط را پیدا و fit آن‌ها را بررسی کنی.", findCandidates: "کاندیداهای مناسب", analyzeCandidate: "تحلیل کاندیدا", analyzeJob: "تحلیل تناسب", skillGap: "شکاف مهارتی", preferencesUpdated: "ترجیحاتت به‌روزرسانی شد و رتبه‌بندی بعدی از آن استفاده می‌کند.", aiUnavailableHonest: "سرویس AI در دسترس نبود. نتیجه deterministic زیر با داده فعلی محاسبه شد و پاسخ LLM ساخته نشد.", noCandidates: "کاندیدای متناسبی با نیازهای فعلی پیدا نشد.", noJobs: "فرصت متناسبی با ترجیحات و پروفایل فعلی پیدا نشد.", highRelevance: "ارتباط بالا", mediumRelevance: "ارتباط متوسط", partialRelevance: "ارتباط نسبی", lowRelevance: "ارتباط پایین", strengths: "نقاط قوت", gaps: "فاصله‌ها", concerns: "نکات قابل بررسی", whyRelevant: "چرا مرتبط است؟", viewDetails: "مشاهده جزئیات", analyzeFit: "تحلیل fit", askAgentCandidate: "از Agent درباره این کاندیدا بپرس", companyName: "نام شرکت", hiringFocus: "حوزه / تمرکز", desiredRoles: "نقش‌های هدف", requiredSkills: "مهارت‌های ضروری", preferredCharacteristics: "ویژگی‌های مطلوب", experienceLevel: "سطح تجربه", companySaved: "اطلاعات شرکت ذخیره شد.", companyEdit: "ویرایش شرکت", companyAgent: "Agent شرکت", companyAgentPlaceholder: "مثلاً: برای یک Product Studio روی AI، یک Frontend Engineer با TypeScript می‌خواهیم…", feedbackPrompt: "مثلاً: remote نمی‌خواهم و بیشتر startup می‌پسندم.", matchingEngineNote: "relevance با داده ساختاریافته و deterministic محاسبه می‌شود؛ Agent روی evidence توضیح می‌دهد.", similarOpportunities: "فرصت‌های مشابه", noSimilarOpportunities: "فرصت مشابهی در داده فعلی پیدا نشد.", askAgentJob: "از Agent درباره این فرصت بپرس", askAgentCandidate: "از Agent درباره این کاندیدا بپرس",

    },
    en: {
      home: "Home", people: "People", opportunities: "Opportunities", organizations: "Organizations", profile: "Profile", aboutNav: "About",
      authEntry: "Sign in / Join", authTitle: "Enter Veyra", authHeadline: "Build your professional identity.", authJoin: "Create account", authSignIn: "Sign in", authIdentifier: "Email or phone", authIdentifierType: "Identifier type", authEmail: "Email", authPhone: "Phone", firstName: "First name", lastName: "Last name", createAccount: "Create account & start", signInAction: "Sign in", signOut: "Sign out", openMyProfile: "My profile",
      agentInputLabel: "Ask the Agent", agentDialogInputLabel: "Ask the Agent about this context", authDesc: "An account is required to build and maintain a professional profile; browsing people, opportunities, and general Agent questions work without an account.", authDemoNote: "This stage uses Browser/Demo persistence: account data stays in this browser and server-grade Authentication is not implemented.", accountCreated: "Demo account created. Start the Agent to build your profile.", accountSignedIn: "Signed into the Demo account.", accountSignedOut: "Signed out of the Demo account.", accountExists: "That identifier already exists in this browser; use Sign in.", accountNotFound: "No account with that identifier exists in this browser.", authValidation: "Complete identifier, first name, and last name.", authIdentifierValidation: "Enter a valid email or phone number.",
      heroKicker: "Professional identity + Agent", jobSeekerPathEyebrow: "FOR PROFESSIONALS", jobSeekerPathTitle: "Build your profile, then choose with context.", jobSeekerPathDesc: "The Agent starts from your real information and follows you from Profile to fit and skill gaps.", startAsProfessional: "Start as a professional", companyPathEyebrow: "FOR TEAMS", companyPathTitle: "Define the hiring need; the Agent finds relevant candidates.", companyPathDesc: "Company Agent focuses on role, skills, experience, and hiring gaps—not a copy of the job-seeker journey.", startAsCompany: "Explore the company flow", homeJobsEyebrow: "MATCHED OPPORTUNITIES", homeJobsTitle: "Opportunities worth a closer look.", homeJobsDesc: "For Job Seekers, this area uses the current Profile and preferences to rank results.", homeCompaniesTitle: "Teams that create opportunities.", homeCompaniesDesc: "See their focus, location, and relationship to available opportunities at a glance.", viewCompanies: "Explore companies", howEyebrow: "HOW VEYRA WORKS", howTitle: "Three moves, one professional flow.", howDesc: "Veyra keeps discovery connected to identity.", howOneTitle: "Identity", howOneDesc: "Your verified facts or the company’s real hiring need become structured state.", howTwoTitle: "Context", howTwoDesc: "The Agent knows which Profile, Job, Candidate, or hiring need you are talking about.", howThreeTitle: "Decision", howThreeDesc: "Deterministic matching supplies evidence; the Agent explains the next decision.", homeCtaTitle: "Start with one professional question.", homeCtaDesc: "You do not need a perfect brief first; the Agent starts from the context already on screen.", heroLead: "Build your career path", heroAccent: "with better context.", heroDesc: "Veyra brings professional identity, people, and opportunities into one flow; the Agent helps you structure your own information and make better career decisions.",
      exploreOpportunities: "Explore opportunities", askAgent: "Ask the Agent", proofOne: "context-aware", proofTwo: "state-connected", proofThree: "synthetic discovery data", agentVisualTitle: "The Agent sits on top of your professional identity.", agentVisualDesc: "From building a Profile to analyzing an opportunity, the Agent works from explicit context.", agentTitle: "Make the Agent part of the journey.", agentDesc: "Your question, page context, and professional profile meet in one flow.", agentOffline: "Local Demo mode is active; no real endpoint is configured.", agentConnected: "Agent endpoint is configured.", agentChecking: "Agent endpoint is configured; availability is checked on send.",
      peopleEyebrow: "PEOPLE", peoplePreviewTitle: "People sit behind every opportunity.", peoplePreviewDesc: "Explore professional profiles and ask the Agent about relevance.", viewAll: "View all", peopleTitle: "People & expertise", peopleDesc: "Find profiles by professional identity, skills, and interests.", peopleSearchPlaceholder: "Name, title, or skill…", clear: "Clear", demoDirectory: "DEMO directory",
      opportunityEyebrow: "OPPORTUNITIES", opportunitiesPreviewTitle: "See opportunities with context.", opportunitiesPreviewDesc: "These records are synthetic and only exist to demonstrate this Demo.", opportunitiesTitle: "Professional opportunities", opportunitiesDesc: "Explore opportunities that may be related to the current profile.", viewOpportunities: "All opportunities", opportunityDemoNote: "Opportunities are synthetic demo data; relevance is computed by this product’s Matching Engine.",
      orgEyebrow: "ORGANIZATIONS", orgTitle: "Organizations & teams", orgDesc: "See focus areas, teams, and their relationship to available opportunities.",
      profilePageTitle: "Professional identity", edit: "Edit", connect: "Connect", connected: "Connected", askAboutProfile: "Ask the Agent about this profile", buildWithAgent: "Build profile with Agent", continueWithAgent: "Continue with Agent", improveProfile: "Improve profile", analyzeProfile: "Analyze profile", suggestSkills: "Suggest skills", findMatching: "Matching opportunities", careerDirection: "Career direction", profileCreated: "Profile created", completeness: "Profile completeness", accountRequired: "Sign in to create and edit your profile.", createProfile: "Create profile",
      about: "About", experience: "Experience", education: "Education", projects: "Projects", resume: "Resume", skills: "Skills", interests: "Professional interests", preferences: "Preferences", aiRecommendations: "Agent recommendations", noExperience: "No experience added yet.", noEducation: "No education added yet.", noProjects: "No projects added yet.", noResume: "No resume added yet.", profileSource: "Information you explicitly entered", profileDemoSource: "DEMO / synthetic profile",
      context: "Agent Context", viewer: "My profile", target: "Target profile", organization: "Organization", opportunity: "Opportunity", globalSearch: "GLOBAL SEARCH", searchTitle: "Quick search", searchPlaceholder: "Person, skill, organization, or opportunity…", noResults: "No results found.",
      editEyebrow: "PROFILE", editTitle: "Edit professional identity", headline: "Professional headline", location: "Location", cancel: "Cancel", save: "Save", educationHelp: "One line: field — institution — period (optional)", projectsHelp: "One line: project name — summary — optional link", resumeHelp: "Add only a resume link or title.", addExperience: "Add experience", removeExperience: "Remove", role: "Role", company: "Company / team", period: "Timeframe", duration: "Duration", summary: "Short summary",
      connectionSaved: "Connection state saved in this browser.", profileSaved: "Profile changes saved.", saveFailed: "The changes could not be saved; your existing data was preserved.", companyNeedsMoreContext: "Complete the hiring need for more precise ranking.", companyNeedsMoreContextDesc: "The Agent can collect the role, skills, and experience level you need.", settings: "Settings", language: "Language", theme: "Theme", settingsNote: "Accounts, profiles, connections, and Agent history are stored in localStorage for this Demo; there is no shared Database.", agentUnavailable: "No real Agent endpoint is configured; this message is answered by the local Demo Agent.", agentError: "The Agent did not return a response. Check the endpoint and backend status.", knownContext: "available context", localData: "local data", fullTime: "Full-time", research: "Research", memberCount: "members", focus: "Focus", type: "Type", viewProfile: "View profile", askAboutOpportunity: "Ask about this opportunity", viewOrg: "View organization",
      aboutProblemEyebrow: "THE PROBLEM", aboutProblemTitle: "Professional discovery usually loses context.", aboutProblemDesc: "A resume, a job post, and a profile each show only part of the decision. Veyra brings them into one explainable relevance flow.", aboutAgentTitle: "Why does the Agent matter?", aboutAgentDesc: "It asks focused questions, connects context to application actions, and explains fit using evidence already in the product.", creatorsEyebrow: "CREATED BY", creatorsTitle: "Built with care for an Agent-native experience.", creatorRoleOne: "Product · AI · UX", creatorRoleTwo: "Engineering · Systems", creatorRoleThree: "Product · Design · Frontend", aboutCopyright: "Created by the team above for BuildX.", similarOpportunities: "Similar opportunities", noSimilarOpportunities: "No similar opportunity is visible in the current data.", aboutEyebrow: "ABOUT VEYRA", aboutTitle: "A professional network with the Agent at its center.", aboutDesc: "Veyra is a BuildX Demo for professional identity and context-aware Agent interaction.", aboutOneTitle: "Identity first", aboutOneDesc: "Profiles are built only from information the user explicitly enters or confirms.", aboutTwoTitle: "Discovery with context", aboutTwoDesc: "Job, candidate, and company context stay attached to the question, so the user does not have to repeat it.", aboutThreeTitle: "Lightweight by design", aboutThreeDesc: "The Demo stays lightweight: browser state and synthetic data are enough to show the core product flow.", footerTag: "AI Career Network · BuildX Demo", openAgent: "Open Agent",
      interviewTitle: "Build your profile with the Agent", interviewDesc: "I only record information you state. When something is missing or ambiguous, I ask instead of guessing.", interviewProgress: "Build progress", interviewPlaceholder: "For example: I worked as a frontend developer for two years and used React and TypeScript…", interviewSkip: "Skip", interviewDone: "Your profile is ready. It can now be edited and analyzed.", localAgent: "Demo Agent · structured fallback", externalAgent: "LLM Agent · external endpoint", agentFactAdded: "Added to your profile", agentNoFact: "I could not find a structured fact I can safely record from that message without guessing.", authModeJoin: "Join", authModeSignIn: "Sign in", sessionLabel: "Current account",
      skillSuggestionNote: "Suggestions are based only on explicit profile skills and skills required by synthetic opportunities in this Demo; this is not LLM reasoning.", matchingNote: "This list is ranked by direct skill overlap with the synthetic opportunities in this Demo.",
      retry: "Retry", agentLoading: "The Agent is analyzing the current context…", aiInterviewFailure: "The AI service was unavailable; this step continued with the deterministic interviewer and no LLM answer was used.", companyDashboard: "Company dashboard", accountType: "Account type", jobSeeker: "Job seeker", companyEmployer: "Company / employer", companyOnboardingTitle: "Define hiring needs with the Agent", companyOnboardingDesc: "The Agent asks about the company, roles, and candidate criteria and stores only confirmed facts.", companyDone: "Company information is ready. You can now find relevant candidates and inspect fit.", findCandidates: "Find relevant candidates", analyzeCandidate: "Analyze candidate", analyzeJob: "Analyze fit", skillGap: "Skill gap", preferencesUpdated: "Your preferences were updated and future ranking will use them.", aiUnavailableHonest: "The AI service was unavailable. The deterministic result below uses current structured data; no LLM answer was fabricated.", noCandidates: "No candidate matched the current hiring requirements.", noJobs: "No opportunity matched the current profile and preferences.", highRelevance: "High relevance", mediumRelevance: "Medium relevance", partialRelevance: "Partial relevance", lowRelevance: "Low relevance", strengths: "Strengths", gaps: "Gaps", concerns: "Points to clarify", whyRelevant: "Why relevant?", viewDetails: "View details", analyzeFit: "Analyze fit", askAgentCandidate: "Ask Agent about this candidate", companyName: "Company name", hiringFocus: "Focus", desiredRoles: "Target roles", requiredSkills: "Required skills", preferredCharacteristics: "Preferred characteristics", experienceLevel: "Experience level", companySaved: "Company information saved.", companyEdit: "Edit company", companyAgent: "Company Agent", companyAgentPlaceholder: "For example: We need a TypeScript frontend engineer for an AI product…", feedbackPrompt: "For example: I don't want remote jobs and I prefer startups.", matchingEngineNote: "Relevance is computed deterministically from structured data; the Agent provides interpretation/explanation.",

    }
  };

  const state = {
    lang: ["fa", "en"].includes(localStorage.getItem(Store.keys.lang)) ? localStorage.getItem(Store.keys.lang) : "fa",
    theme: ["light", "dark", "system"].includes(localStorage.getItem(Store.keys.theme)) ? localStorage.getItem(Store.keys.theme) : "system",
    data: null,
    account: Store.getCurrentAccount(),
    viewer: null,
    accountType: "job-seeker",
    company: null,
    peopleQuery: "",
    peopleSkill: "all",
    connections: Store.getConnections(),
    agentHistory: Store.getAgentHistory(),
    agentMode: "network",
    agentTargetId: null,
    agentOrgId: null,
    agentOpportunityId: null,
    agentOnline: false,
    authMode: "join",
        profileInterview: {started: false, questionKey: null, skipped: {}, messages: []},
    companyInterview: {started: false, questionKey: null, skipped: {}, messages: []},
    experienceDraft: [],
    agentBusy: false,
  };

  const qs = (selector, root = document) => root.querySelector(selector);
  const qsa = (selector, root = document) => [...root.querySelectorAll(selector)];
  const escapeHTML = (value) => String(value ?? "").replace(/[&<>'"]/g, (char) => ({"&":"&amp;","<":"&lt;",">":"&gt;","'":"&#39;",'"':"&quot;"}[char]));
  const tr = (key) => copy[state.lang]?.[key] ?? copy.en[key] ?? key;
  const text = (value) => typeof value === "object" && value ? (value[state.lang] ?? value.fa ?? value.en ?? "") : String(value ?? "");
  const initials = (value) => text(value).trim().split(/\s+/).slice(0, 2).map((part) => part[0] || "").join("").toUpperCase();
  const icon = (name) => `<svg class="icon" aria-hidden="true"><use href="#i-${name}"/></svg>`;
  const same = (a, b) => String(a ?? "").toLocaleLowerCase() === String(b ?? "").toLocaleLowerCase();
  const safeUrl = (value) => { const raw = String(value || "").trim(); try { const url = new URL(raw, location.href); return ["http:", "https:"].includes(url.protocol) ? url.href : ""; } catch { return ""; } };

  function applyTheme() {
    document.documentElement.dataset.theme = state.theme;
    const dark = state.theme === "dark" || (state.theme === "system" && matchMedia("(prefers-color-scheme: dark)").matches);
    qs("#quickTheme")?.classList.toggle("is-dark", dark);
    qsa("[data-theme]").forEach((button) => button.classList.toggle("active", button.dataset.theme === state.theme));
  }

  function applyLanguage() {
    document.documentElement.lang = state.lang;
    document.documentElement.dir = state.lang === "fa" ? "rtl" : "ltr";
    qs("#langToggle")?.replaceChildren(document.createTextNode(state.lang === "fa" ? "FA" : "EN"));
    qsa("[data-i18n]").forEach((el) => { el.textContent = tr(el.dataset.i18n); });
    qsa("[data-i18n-placeholder]").forEach((el) => { el.placeholder = tr(el.dataset.i18nPlaceholder); });
    syncAuthUI();
    renderCurrentRoute();
    renderAgentContext();
    renderAgentSuggestions(state.agentMode);
    renderProfileInterview();
  }

  function findDemoProfile(id) { return state.data?.profiles?.find((item) => String(item.id) === String(id)) || null; }
  function findOrg(id) { return state.data?.organizations?.find((item) => String(item.id) === String(id)) || null; }
  function findOpportunity(id) { return state.data?.opportunities?.find((item) => String(item.id) === String(id)) || null; }
  function findProfile(id) {
    if (state.viewer && String(state.viewer.id) === String(id)) return state.viewer;
    const own = Store.getCandidateAccounts().find((profile) => String(profile.id) === String(id));
    return own || findDemoProfile(id);
  }

  function isCompany() { return state.accountType === "company" && Boolean(state.company); }
  function candidatePool() {
    const synthetic = Array.isArray(state.data?.profiles) ? state.data.profiles : [];
    const local = Store.getCandidateAccounts();
    const byId = new Map(synthetic.map((profile) => [String(profile.id), profile]));
    local.forEach((profile) => byId.set(String(profile.id), profile));
    return [...byId.values()];
  }

  function refreshViewer() {
    state.account = Store.getCurrentAccount();
    state.accountType = state.account?.accountType === "company" ? "company" : "job-seeker";
    state.viewer = state.account?.profile ? Store.sanitizeProfile(state.account.profile) : null;
    state.company = state.account?.company ? Store.sanitizeCompany(state.account.company) : null;
  }

  function serializeProfile(profile) {
    if (!profile) return null;
    return {
      id: String(profile.id || ""), name: text(profile.name).slice(0, 80), headline: text(profile.headline).slice(0, 140), location: text(profile.location).slice(0, 80), about: text(profile.about).slice(0, 700),
      skills: Array.isArray(profile.skills) ? profile.skills.slice(0, 16).map(String) : [], interests: Array.isArray(profile.interests) ? profile.interests.slice(0, 12).map(String) : [], targetRoles: Array.isArray(profile.targetRoles) ? profile.targetRoles.slice(0, 8).map(String) : [], goals: text(profile.goals).slice(0, 500),
      experience: Array.isArray(profile.experience) ? profile.experience.slice(0, 8).map((item) => ({role: String(item.role || "").slice(0, 100), company: String(item.company || "").slice(0, 100), period: String(item.period || "").slice(0, 60), duration: String(item.duration || "").slice(0, 40), summary: String(item.summary || "").slice(0, 300)})) : [],
      education: Array.isArray(profile.education) ? profile.education.slice(0, 6) : [], projects: Array.isArray(profile.projects) ? profile.projects.slice(0, 8) : [], resume: String(profile.resume || "").slice(0, 300),
      preferences: profile.preferences || {}, source: profile.source || "user-entered",
    };
  }
  function serializeOrg(org) { return org ? {id: String(org.id || ""), name: text(org.name).slice(0, 100), type: text(org.type).slice(0, 80), focus: text(org.focus).slice(0, 120), location: text(org.location).slice(0, 80), description: text(org.description).slice(0, 400), memberCount: Array.isArray(org.memberIds) ? org.memberIds.length : 0} : null; }
  function serializeOpportunity(opp) { const org = findOrg(opp?.organizationId); return opp ? {id: String(opp.id || ""), title: text(opp.title).slice(0, 120), organization: org ? text(org.name).slice(0, 100) : "", location: text(opp.location).slice(0, 80), type: text(opp.type).slice(0, 60), workMode: text(opp.workMode).slice(0, 40), experienceLevel: String(opp.experienceLevel || ""), companyType: String(opp.companyType || ""), summary: text(opp.summary).slice(0, 420), skills: Array.isArray(opp.skills) ? opp.skills.slice(0, 12).map(String) : []} : null; }
  function serializeCompany(company) { return company ? {id: String(company.id || ""), name: String(company.name || "").slice(0, 100), focus: String(company.focus || "").slice(0, 160), location: String(company.location || "").slice(0, 100), desiredRoles: Array.isArray(company.desiredRoles) ? company.desiredRoles.slice(0, 8) : [], requiredSkills: Array.isArray(company.requiredSkills) ? company.requiredSkills.slice(0, 16) : [], preferredCharacteristics: Array.isArray(company.preferredCharacteristics) ? company.preferredCharacteristics.slice(0, 8) : [], preferredExperienceLevel: String(company.preferredExperienceLevel || "").slice(0, 30), openPositions: Array.isArray(company.openPositions) ? company.openPositions.slice(0, 8) : []} : null; }

  function routeParts() {
    const hash = String(location.hash || "");
    const cleaned = hash.replace(/^#\/?/, "").trim().split("?")[0];
    if (!cleaned) return {route: "home", id: null};
    const slash = cleaned.indexOf("/");
    if (slash < 0) return {route: decodeURIComponentSafe(cleaned).toLowerCase() || "home", id: null};
    const route = decodeURIComponentSafe(cleaned.slice(0, slash)).toLowerCase() || "home";
    const idRaw = cleaned.slice(slash + 1).trim();
    return {route, id: idRaw ? decodeURIComponentSafe(idRaw) : null};
  }

  function decodeURIComponentSafe(value) {
    try { return decodeURIComponent(value); }
    catch { return value; }
  }

  function showPage(route) {
    const allowed = ["home", "people", "opportunities", "organizations", "profile", "company", "about"];
    const page = allowed.includes(route) ? route : "home";
    qsa(".page").forEach((el) => el.classList.toggle("active", el.dataset.page === page));
    qsa("[data-route]").forEach((el) => el.classList.toggle("active", el.dataset.route === page));
    const reduceMotion = matchMedia("(prefers-reduced-motion: reduce)").matches;
    window.scrollTo({top: 0, behavior: reduceMotion ? "auto" : "smooth"});
  }

  function renderCurrentRoute() {
    if (!state.data) return;
    refreshViewer();
    const {route, id} = routeParts();
    if (route === "people") { showPage("people"); renderPeople(); return; }
    if (route === "opportunities") { showPage("opportunities"); renderOpportunities(id); return; }
    if (route === "organizations") { showPage("organizations"); renderOrganizations(id); return; }
    if (route === "profile") { if (!id && isCompany()) { showPage("company"); renderCompanyPage(); return; } showPage("profile"); renderProfile(id); return; }
    if (route === "company") { showPage("company"); renderCompanyPage(); return; }
    if (route === "about") { showPage("about"); return; }
    showPage("home"); renderHome();
  }

  function overlap(viewerSkills, targetSkills) {
    const source = new Set((viewerSkills || []).map((skill) => String(skill).toLocaleLowerCase()));
    return (targetSkills || []).filter((skill) => source.has(String(skill).toLocaleLowerCase()));
  }
  function opportunityMatch(opp) { return state.viewer && !isCompany() ? Matching.scoreJob(state.viewer, opp) : null; }

  function profileCompleteness(profile) {
    if (!profile) return 0;
    const checks = [Boolean(text(profile.name).trim()), Boolean(text(profile.headline).trim()), Boolean(text(profile.about).trim()), (profile.skills || []).length > 0, (profile.experience || []).length > 0, (profile.education || []).length > 0, (profile.projects || []).length > 0, (profile.interests || []).length > 0, (profile.targetRoles || []).length > 0, Boolean(text(profile.goals).trim())];
    return Math.round((checks.filter(Boolean).length / checks.length) * 100);
  }

  function renderHome() {
    const people = isCompany() && state.company
      ? ((state.company.requiredSkills?.length || state.company.desiredRoles?.length) ? Matching.rankCandidates(state.company, candidatePool()).slice(0, 3).map((item) => item.candidate) : candidatePool().slice(0, 3))
      : (state.viewer ? [state.viewer, ...state.data.profiles].filter((item, index, list) => list.findIndex((x) => String(x.id) === String(item.id)) === index).slice(0, 3) : state.data.profiles.slice(0, 3));
    qs("#recommendedGrid").innerHTML = people.map(profileCard).join("");
    if (qs("#homeRelevantOpportunities")) {
      const jobs = state.viewer && !isCompany() ? rankedOpportunities(state.viewer).slice(0, 3).map((item) => item.job) : state.data.opportunities.slice(0, 3);
      qs("#homeRelevantOpportunities").innerHTML = jobs.length ? jobs.map(opportunityCard).join("") : emptyNote();
    }
    if (qs("#homeCompanies")) qs("#homeCompanies").innerHTML = state.data.organizations.slice(0, 2).map((org) => orgCard(org, null, true)).join("");
    renderAgentSuggestions("network"); renderWorkspaceHistory();
  }

  function renderPeople() {
    const all = state.data.profiles;
    const skills = ["all", ...new Set(all.flatMap((profile) => profile.skills || []))].slice(0, 16);
    qs("#skillFilters").innerHTML = skills.map((skill) => `<button class="filter-btn ${state.peopleSkill === skill ? "active" : ""}" data-skill-filter="${escapeHTML(skill)}" type="button">${escapeHTML(skill === "all" ? (state.lang === "fa" ? "همه" : "All") : skill)}</button>`).join("");
    const q = state.peopleQuery.trim().toLocaleLowerCase();
    const list = all.filter((profile) => {
      const matchesSkill = state.peopleSkill === "all" || (profile.skills || []).includes(state.peopleSkill);
      const hay = [text(profile.name), text(profile.headline), text(profile.location), ...(profile.skills || []), ...(profile.interests || [])].join(" ").toLocaleLowerCase();
      return matchesSkill && (!q || hay.includes(q));
    });
    qs("#peopleResultsCount").textContent = `${list.length} / ${all.length}`;
    qs("#peopleSearch").value = state.peopleQuery;
    qs("#peopleGrid").innerHTML = list.length ? list.map(profileCard).join("") : emptyNote();
  }

  function renderOpportunities(selectedId = null) {
    qs("#opportunityGrid").innerHTML = state.data.opportunities.map(opportunityCard).join("");
    const detail = selectedId ? findOpportunity(selectedId) : null;
    qs("#opportunityDetail").innerHTML = detail ? opportunityDetail(detail) : "";
  }

  function renderOrganizations(selectedId = null) {
    qs("#orgGrid").innerHTML = state.data.organizations.map((org) => orgCard(org, selectedId)).join("");
    const detail = qs("#organizationDetail");
    if (detail) detail.innerHTML = selectedId && findOrg(selectedId) ? organizationDetail(findOrg(selectedId)) : "";
  }

  function renderCompanyPage() {
    const box = qs("#companyPage");
    if (!box) return;
    if (!state.viewer || !isCompany()) {
      box.innerHTML = `<div class="profile-empty"><div class="profile-empty-mark">V</div><span class="eyebrow">${escapeHTML(tr("companyDashboard"))}</span><h1>${escapeHTML(tr("companyEmployer"))}</h1><p>${escapeHTML(tr("authDesc"))}</p><div class="hero-actions"><button class="primary-btn" type="button" data-open-auth>${icon("login")}${escapeHTML(tr("authEntry"))}</button></div></div>`;
      return;
    }
    const company = state.company;
    const ranked = (company.requiredSkills?.length || company.desiredRoles?.length) ? Matching.rankCandidates(company, candidatePool()).filter((item) => item.fit.score >= 30).slice(0, 3) : [];
    const requirementTags = [...new Set([...(company.requiredSkills || []), ...(company.desiredRoles || [])])].slice(0, 10);
    box.innerHTML = `<div class="company-dashboard"><div class="company-hero"><div><span class="eyebrow">${escapeHTML(tr("companyDashboard"))}</span><h1>${escapeHTML(company.name || (state.lang === "fa" ? "شرکت جدید" : "New company"))}</h1><p>${escapeHTML(company.focus || tr("companyOnboardingDesc"))}</p></div><div class="company-hero-actions"><button class="ghost-btn" type="button" data-edit-company>${icon("edit")}${escapeHTML(tr("companyEdit"))}</button><button class="primary-btn" type="button" data-open-company-agent>${icon("bot")}${escapeHTML(company.name && (company.requiredSkills || []).length ? tr("findCandidates") : tr("companyAgent"))}</button></div></div><div class="company-grid"><section class="rail-card"><div class="section-inline-head"><div><span class="eyebrow">${escapeHTML(tr("hiringFocus"))}</span><h3>${escapeHTML(company.focus || "—")}</h3></div></div><div class="tag-row">${requirementTags.map((item) => `<span class="tag accent-tag">${escapeHTML(item)}</span>`).join("") || `<span class="muted">—</span>`}</div><div class="company-detail-list"><div><span>${escapeHTML(tr("location"))}</span><strong>${escapeHTML(company.location || "—")}</strong></div><div><span>${escapeHTML(tr("experienceLevel"))}</span><strong>${escapeHTML(company.preferredExperienceLevel || "—")}</strong></div><div><span>${escapeHTML(tr("preferredCharacteristics"))}</span><strong>${escapeHTML((company.preferredCharacteristics || []).join(" · ") || "—")}</strong></div></div></section><section class="rail-card"><div class="section-inline-head"><div><span class="eyebrow">${escapeHTML(tr("openPositions"))}</span><h3>${escapeHTML(String(company.openPositions?.length || 0))}</h3></div></div><div class="mini-opportunity-list">${(company.openPositions || []).map((item) => `<div class="mini-opportunity-row"><strong>${escapeHTML(item.title || "—")}</strong><span>${escapeHTML([item.location, item.workMode, item.level].filter(Boolean).join(" · ") || tr("noOpenPositions"))}</span></div>`).join("") || `<span class="muted">${escapeHTML(tr("noOpenPositions"))}</span>`}</div></section><section class="rail-card"><span class="eyebrow">${escapeHTML(tr("findCandidates"))}</span><h3>${escapeHTML(company.name ? tr("companyDone") : tr("companyOnboardingTitle"))}</h3><div class="action-stack"><button class="soft-btn wide" type="button" data-open-agent="company">${icon("bot")}${escapeHTML(tr("findCandidates"))}</button><button class="soft-btn wide" type="button" data-open-company-agent>${icon("spark")}${escapeHTML(tr("companyAgent"))}</button></div></section></div><section class="profile-section"><div class="section-head"><div><span class="eyebrow">${escapeHTML(tr("findCandidates"))}</span><h2>${escapeHTML(tr("whyRelevant"))}</h2></div>${ranked.length ? `<span class="inline-note">${escapeHTML(tr("matchingEngineNote"))}</span>` : ""}</div><div class="chat-card-stack">${ranked.length ? ranked.map(({candidate,fit}) => renderAgentCards([{type:"candidate",id:candidate.id,name:text(candidate.name),headline:text(candidate.headline),skills:candidate.skills||[],fit}])).join("") : `<div class="empty-note"><strong>${escapeHTML(tr("companyNeedsMoreContext"))}</strong><p class="muted">${escapeHTML(tr("companyNeedsMoreContextDesc"))}</p></div>`}</div></section></div>`;
  }

  function renderProfile(profileId) {
    const profile = profileId ? findProfile(profileId) : state.viewer;
    if (!profile && !profileId) { renderProfileLanding(); return; }
    if (!profile) { location.hash = "#profile"; return; }
    const isViewer = Boolean(state.viewer && String(profile.id) === String(state.viewer.id));
    const orgs = state.data.organizations.filter((org) => (org.memberIds || []).map(String).includes(String(profile.id)));
    const completeness = profileCompleteness(profile);
    const actions = isViewer
      ? `<button class="ghost-btn" type="button" data-edit-profile>${icon("edit")}${escapeHTML(tr("edit"))}</button><button class="primary-btn" type="button" data-open-profile-agent>${icon("bot")}${escapeHTML(completeness < 60 ? tr("continueWithAgent") : tr("improveProfile"))}</button>`
      : isCompany() ? `<button class="ghost-btn" type="button" data-connect="${escapeHTML(profile.id)}">${icon(state.connections.has(String(profile.id)) ? "check" : "plus")}${escapeHTML(state.connections.has(String(profile.id)) ? tr("connected") : tr("connect"))}</button><button class="primary-btn" type="button" data-open-agent="candidate" data-agent-target="${escapeHTML(profile.id)}">${icon("bot")}${escapeHTML(tr("analyzeCandidate"))}</button>`
      : `<button class="primary-btn" type="button" data-connect="${escapeHTML(profile.id)}">${icon(state.connections.has(String(profile.id)) ? "check" : "plus")}${escapeHTML(state.connections.has(String(profile.id)) ? tr("connected") : tr("connect"))}</button>`;
    const experience = (profile.experience || []).length ? profile.experience.map((item) => `<div class="experience-item"><span class="timeline-dot"></span><div><strong>${escapeHTML(item.role || tr("role"))}</strong>${item.company ? `<span class="company">${escapeHTML(item.company)}</span>` : `<span class="company muted">${escapeHTML(tr("company"))} —</span>`}<div class="period">${escapeHTML(item.period || item.duration || "")}</div>${item.summary ? `<p>${escapeHTML(item.summary)}</p>` : ""}</div></div>`).join("") : `<span class="muted">${escapeHTML(tr("noExperience"))}</span>`;
    const education = (profile.education || []).length ? profile.education.map((item) => `<div class="list-item"><strong>${escapeHTML(item.degree || "")}</strong><span>${escapeHTML(item.school || "")}</span><small>${escapeHTML(item.period || "")}</small></div>`).join("") : `<span class="muted">${escapeHTML(tr("noEducation"))}</span>`;
    const projects = (profile.projects || []).length ? profile.projects.map((item) => `<div class="list-item"><strong>${escapeHTML(item.name || "")}</strong><span>${escapeHTML(item.summary || "")}</span>${safeUrl(item.link) ? `<a href="${escapeHTML(safeUrl(item.link))}" target="_blank" rel="noreferrer">${escapeHTML(item.link)}</a>` : ""}</div>`).join("") : `<span class="muted">${escapeHTML(tr("noProjects"))}</span>`;
    const recommendations = (profile.aiRecommendations || []).length ? `<div class="tag-row">${profile.aiRecommendations.map((item) => `<span class="tag accent-tag">${escapeHTML(item)}</span>`).join("")}</div>` : `<p class="muted">${escapeHTML(state.lang === "fa" ? "هنوز recommendation ذخیره نشده؛ از Agent بخواه پروفایل را تحلیل کند." : "No stored recommendations yet; ask the Agent to analyze your profile.")}</p>`;
    qs("#profilePage").innerHTML = `<div class="profile-layout"><div class="profile-main"><section class="profile-hero"><div class="profile-cover"><span class="cover-label">VEYRA / PROFESSIONAL IDENTITY</span></div><div class="profile-hero-body"><div class="profile-head"><div class="avatar xl">${escapeHTML(initials(profile.name))}</div><div class="profile-head-copy"><span class="eyebrow">${escapeHTML(tr("profilePageTitle"))}</span><h2>${escapeHTML(text(profile.name) || "—")}</h2><p>${escapeHTML(text(profile.headline) || (isViewer ? (state.lang === "fa" ? "هنوز عنوان حرفه‌ای اضافه نشده" : "No professional headline yet") : "—"))}</p></div></div><div class="identity-meta">${text(profile.location) ? `<span class="meta-chip">${icon("pin")}${escapeHTML(text(profile.location))}</span>` : ""}${orgs.map((org) => `<span class="meta-chip">${icon("building")}${escapeHTML(text(org.name))}</span>`).join("")}<span class="meta-chip">${icon("check")}${escapeHTML(profile.source === "synthetic" ? tr("profileDemoSource") : tr("profileSource"))}</span></div><div class="profile-actions">${actions}<button class="ghost-btn" type="button" data-open-agent="profile" data-agent-target="${escapeHTML(profile.id)}">${icon("bot")}${escapeHTML(tr("askAboutProfile"))}</button></div></div></section><section class="profile-section"><div class="section-inline-head"><div><h3>${escapeHTML(tr("completeness"))}</h3><p class="muted">${completeness}%</p></div><div class="progress-track"><span style="width:${completeness}%"></span></div></div></section><section class="profile-section"><h3>${escapeHTML(tr("about"))}</h3><p class="about-text">${escapeHTML(text(profile.about) || "—")}</p></section><section class="profile-section"><h3>${escapeHTML(tr("experience"))}</h3><div class="experience-list">${experience}</div></section><section class="profile-section"><h3>${escapeHTML(tr("education"))}</h3><div class="list-stack">${education}</div></section><section class="profile-section"><h3>${escapeHTML(tr("projects"))}</h3><div class="list-stack">${projects}</div></section><section class="profile-section"><h3>${escapeHTML(tr("skills"))}</h3><div class="skills-cloud">${(profile.skills || []).map((skill) => `<span class="skill">${escapeHTML(skill)}</span>`).join("") || `<span class="muted">—</span>`}</div></section><section class="profile-section"><h3>${escapeHTML(tr("interests"))}</h3><div class="interest-list">${(profile.interests || []).map((interest) => `<span class="interest">${escapeHTML(interest)}</span>`).join("") || `<span class="muted">—</span>`}</div></section><section class="profile-section"><h3>${escapeHTML(tr("targetRoles"))}</h3><div class="tag-row">${(profile.targetRoles || []).map((role) => `<span class="tag accent-tag">${escapeHTML(role)}</span>`).join("") || `<span class="muted">—</span>`}</div></section><section class="profile-section"><h3>${escapeHTML(tr("professionalGoal"))}</h3><p class="about-text">${escapeHTML(text(profile.goals) || "—")}</p></section><section class="profile-section"><h3>${escapeHTML(tr("preferences"))}</h3><div class="tag-row">${[...(profile.preferences?.preferredWorkModes || []).map((v) => `work: ${v}`), ...(profile.preferences?.preferredCompanyTypes || []).map((v) => `company: ${v}`), ...(profile.preferences?.preferredSkills || []).map((v) => `focus: ${v}`)].map((item) => `<span class="tag accent-tag">${escapeHTML(item)}</span>`).join("") || `<span class="muted">—</span>`}</div>${(profile.preferences?.excludedWorkModes || []).length || (profile.preferences?.excludedRoles || []).length ? `<p class="muted small-copy">${escapeHTML([...(profile.preferences?.excludedWorkModes || []).map((v) => `excluded work mode: ${v}`), ...(profile.preferences?.excludedRoles || []).map((v) => `excluded role: ${v}`)].join(" · "))}</p>` : ""}</section><section class="profile-section"><h3>${escapeHTML(tr("resume"))}</h3>${safeUrl(profile.resume) ? `<a class="resume-link" href="${escapeHTML(safeUrl(profile.resume))}" target="_blank" rel="noreferrer">${icon("arrow")}${escapeHTML(profile.resume)}</a>` : `<span class="muted">${escapeHTML(tr("noResume"))}</span>`}</section><section class="profile-section"><h3>${escapeHTML(tr("aiRecommendations"))}</h3>${recommendations}</section></div><aside class="profile-rail"><section class="rail-card agent-launch-card"><span class="eyebrow">AI AGENT</span><h3>${escapeHTML(isViewer ? (completeness < 75 ? tr("continueWithAgent") : tr("improveProfile")) : tr("askAboutProfile"))}</h3><p>${escapeHTML(tr("interviewDesc"))}</p>${isViewer ? `<button class="primary-btn wide" type="button" data-open-profile-agent>${icon("bot")}${escapeHTML(completeness < 75 ? tr("continueWithAgent") : tr("improveProfile"))}</button>` : ""}</section>${isViewer ? `<section class="rail-card"><h3>${escapeHTML(tr("aiRecommendations"))}</h3><div class="action-stack"><button class="soft-btn wide" type="button" data-agent-action="analyze-profile">${icon("spark")}${escapeHTML(tr("analyzeProfile"))}</button><button class="soft-btn wide" type="button" data-agent-action="suggest-skills">${icon("spark")}${escapeHTML(tr("suggestSkills"))}</button><button class="soft-btn wide" type="button" data-agent-action="find-matching">${icon("briefcase")}${escapeHTML(tr("findMatching"))}</button><button class="soft-btn wide" type="button" data-agent-action="career-direction">${icon("arrow")}${escapeHTML(tr("careerDirection"))}</button></div></section>` : ""}<section class="rail-card"><h3>${escapeHTML(tr("context"))}</h3><div class="profile-context"><div class="context-row"><span>${escapeHTML(tr("viewer"))}</span><strong>${escapeHTML(state.viewer ? text(state.viewer.name) : "—")}</strong></div><div class="context-row"><span>${escapeHTML(tr("target"))}</span><strong>${escapeHTML(text(profile.name))}</strong></div>${orgs.map((org) => `<div class="context-row"><span>${escapeHTML(tr("organization"))}</span><strong>${escapeHTML(text(org.name))}</strong></div>`).join("")}</div></section></aside></div>`;
  }

  function renderProfileLanding() {
    const loggedIn = Boolean(state.viewer);
    qs("#profilePage").innerHTML = `<div class="profile-empty"><div class="profile-empty-mark">V</div><span class="eyebrow">${escapeHTML(tr("profilePageTitle"))}</span><h1>${escapeHTML(loggedIn ? tr("createProfile") : tr("accountRequired"))}</h1><p>${escapeHTML(loggedIn ? tr("interviewDesc") : tr("authDesc"))}</p><div class="hero-actions">${loggedIn ? `<button class="primary-btn" type="button" data-open-profile-agent>${icon("bot")}${escapeHTML(tr("buildWithAgent"))}</button>` : `<button class="primary-btn" type="button" data-open-auth>${icon("login")}${escapeHTML(tr("createAccount"))}</button>`}</div><span class="muted demo-disclaimer">${escapeHTML(tr("authDemoNote"))}</span></div>`;
  }

  function profileCard(profile) {
    const connected = state.connections.has(String(profile.id));
    const companyAction = isCompany() && state.viewer && String(profile.id) !== String(state.viewer.id)
      ? `<button class="primary-btn" type="button" data-open-agent="candidate" data-agent-target="${escapeHTML(profile.id)}">${icon("bot")}${escapeHTML(tr("analyzeCandidate"))}</button>`
      : `<button class="primary-btn" type="button" data-connect="${escapeHTML(profile.id)}">${icon(connected ? "check" : "plus")}${escapeHTML(connected ? tr("connected") : tr("connect"))}</button>`;
    return `<article class="profile-card"><div class="profile-card-top"><div class="avatar">${escapeHTML(initials(profile.name))}</div><div class="profile-card-title"><strong>${escapeHTML(text(profile.name))}</strong><span>${escapeHTML(text(profile.headline))}</span></div></div><div class="profile-card-meta">${profile.location ? `${icon("pin")}${escapeHTML(text(profile.location))}` : ""}</div><p class="profile-card-bio">${escapeHTML(text(profile.about))}</p><div class="tag-row">${(profile.skills || []).slice(0, 4).map((skill) => `<span class="tag">${escapeHTML(skill)}</span>`).join("")}</div><div class="card-actions"><a class="soft-btn" href="#profile/${encodeURIComponent(profile.id)}">${icon("user")}${escapeHTML(tr("viewProfile"))}</a>${companyAction}</div></article>`;
  }

  function opportunityCard(opp) {
    const org = findOrg(opp.organizationId); const match = opportunityMatch(opp); const summary = fitSummary(match || {});
    const matchBlock = match ? `<div class="match-hint"><span>${icon("spark")}${escapeHTML(summary.label)}</span><strong>${escapeHTML((summary.strengths.length ? summary.strengths : summary.gaps).slice(0, 2).join(" · ") || tr("matchingNote"))}</strong></div>` : "";
    return `<article class="opportunity-card"><div class="opp-top"><div class="opp-icon">${icon("briefcase")}</div><span class="opp-type">${escapeHTML(text(opp.type))}</span></div><h3>${escapeHTML(text(opp.title))}</h3><p class="opp-org">${escapeHTML(org ? text(org.name) : "")}</p><p class="opp-summary">${escapeHTML(text(opp.summary))}</p><div class="opp-meta"><span>${icon("pin")}${escapeHTML(text(opp.location))}</span>${opp.workMode ? `<span>${escapeHTML(text(opp.workMode))}</span>` : ""}${opp.experienceLevel ? `<span>${escapeHTML(opp.experienceLevel)}</span>` : ""}</div><div class="tag-row">${(opp.skills || []).map((skill) => `<span class="tag">${escapeHTML(skill)}</span>`).join("")}</div>${matchBlock}<div class="card-actions"><a class="soft-btn" href="#opportunities/${encodeURIComponent(opp.id)}">${icon("arrow")}${escapeHTML(tr("viewDetails"))}</a><button class="primary-btn" type="button" data-open-agent="opportunity" data-agent-opportunity="${escapeHTML(opp.id)}">${icon("bot")}${escapeHTML(tr("analyzeJob"))}</button></div></article>`;
  }

  function opportunityDetail(opp) {
    const org = findOrg(opp.organizationId); const match = opportunityMatch(opp); const summary = fitSummary(match || {});
    return `<section class="detail-card"><div class="detail-kicker">${escapeHTML(tr("opportunity"))}</div><h2>${escapeHTML(text(opp.title))}</h2><p class="detail-org">${escapeHTML(org ? text(org.name) : "")}</p><div class="detail-meta"><span>${icon("pin")}${escapeHTML(text(opp.location))}</span><span>${icon("briefcase")}${escapeHTML(text(opp.type))}</span>${opp.workMode ? `<span>${escapeHTML(text(opp.workMode))}</span>` : ""}</div><p>${escapeHTML(text(opp.summary))}</p><div class="detail-split"><div><h3>${escapeHTML(tr("skills"))}</h3><div class="skills-cloud">${(opp.skills || []).map((skill) => `<span class="skill">${escapeHTML(skill)}</span>`).join("")}</div></div><div><h3>${escapeHTML(tr("whyRelevant"))}</h3><div class="context-summary">${match ? `${icon("spark")} <strong>${escapeHTML(summary.label)}</strong><br>${escapeHTML(match.reasoning)}${match.missingSkills.length ? `<br><span class="muted">${escapeHTML(tr("gaps"))}: ${escapeHTML(match.missingSkills.join(", "))}</span>` : ""}` : `${icon("info")} ${escapeHTML(state.viewer ? tr("matchingNote") : (state.lang === "fa" ? "وارد حساب شو تا تطبیق این فرصت با پروفایل تو محاسبه شود." : "Sign in to calculate this opportunity against your profile."))}`}</div></div></div><div class="profile-actions"><button class="primary-btn" type="button" data-open-agent="opportunity" data-agent-opportunity="${escapeHTML(opp.id)}">${icon("bot")}${escapeHTML(tr("analyzeJob"))}</button><button class="ghost-btn" type="button" data-open-agent="opportunity" data-agent-opportunity="${escapeHTML(opp.id)}" data-agent-suggestion="${escapeHTML(tr("similarOpportunities"))}">${icon("spark")}${escapeHTML(tr("similarOpportunities"))}</button><a class="ghost-btn" href="#opportunities">${escapeHTML(tr("viewOpportunities"))}</a></div></section>`;
  }

  function orgCard(org, selectedId, compact = false) {
    const members = (org.memberIds || []).map(findDemoProfile).filter(Boolean);
    const selected = selectedId && String(selectedId) === String(org.id);
    const companyButton = isCompany() ? `<button class="primary-btn" type="button" data-open-agent="organization" data-agent-org="${escapeHTML(org.id)}">${icon("bot")}${escapeHTML(tr("findCandidates"))}</button>` : `<button class="soft-btn" type="button" data-open-agent="organization" data-agent-org="${escapeHTML(org.id)}">${icon("bot")}${escapeHTML(tr("askAgent"))}</button>`;
    const detailButton = `<a class="soft-btn" href="#organizations/${encodeURIComponent(org.id)}">${icon("building")}${escapeHTML(tr("viewOrg"))}</a>`;
    return `<article class="org-card ${selected ? "selected" : ""} ${compact ? "compact-org-card" : ""}"><div class="org-top"><div class="org-mark">${icon("building")}</div><div><span class="opp-type">${escapeHTML(text(org.type))}</span><h3>${escapeHTML(text(org.name))}</h3></div></div><div class="org-meta"><span>${escapeHTML(tr("focus"))}: ${escapeHTML(text(org.focus))}</span><span>${escapeHTML(tr("location"))}: ${escapeHTML(text(org.location))}</span></div><p>${escapeHTML(text(org.description))}</p><div class="org-members"><div class="member-stack">${members.map((profile) => `<span class="avatar" title="${escapeHTML(text(profile.name))}">${escapeHTML(initials(profile.name))}</span>`).join("")}</div><span class="muted">${members.length} ${escapeHTML(tr("memberCount"))}</span></div><div class="card-actions">${detailButton}${companyButton}</div></article>`;
  }

  function organizationDetail(org) {
    const members = (org.memberIds || []).map(findDemoProfile).filter(Boolean);
    const jobs = state.data.opportunities.filter((opp) => String(opp.organizationId) === String(org.id));
    return `<section class="detail-card organization-detail-card"><div class="detail-kicker">${escapeHTML(tr("organization"))}</div><div class="detail-heading-row"><div><h2>${escapeHTML(text(org.name))}</h2><p class="detail-org">${escapeHTML(text(org.type))} · ${escapeHTML(text(org.location))}</p></div><button class="primary-btn" type="button" data-open-agent="organization" data-agent-org="${escapeHTML(org.id)}">${icon("bot")}${escapeHTML(isCompany() ? tr("findCandidates") : tr("askAgent"))}</button></div><p>${escapeHTML(text(org.description))}</p><div class="detail-split"><div><h3>${escapeHTML(tr("focus"))}</h3><p class="muted">${escapeHTML(text(org.focus))}</p><h3>${escapeHTML(tr("people"))}</h3><div class="mini-profile-list">${members.map((person) => `<a href="#profile/${encodeURIComponent(person.id)}" class="mini-profile-row"><span class="avatar">${escapeHTML(initials(person.name))}</span><span><strong>${escapeHTML(text(person.name))}</strong><small>${escapeHTML(text(person.headline))}</small></span></a>`).join("") || `<span class="muted">${escapeHTML(tr("noResults"))}</span>`}</div></div><div><h3>${escapeHTML(tr("opportunities"))}</h3><div class="mini-opportunity-list">${jobs.map((job) => `<a href="#opportunities/${encodeURIComponent(job.id)}" class="mini-opportunity-row"><strong>${escapeHTML(text(job.title))}</strong><span>${escapeHTML(text(job.location))} · ${escapeHTML(text(job.workMode))}</span></a>`).join("") || `<span class="muted">${escapeHTML(tr("noResults"))}</span>`}</div></div></div></section>`;
  }

  function emptyNote() { return `<div class="empty-note"><div class="empty-icon">${icon("search")}</div><strong>${escapeHTML(tr("noResults"))}</strong></div>`; }

  function syncAgentStatus() {
    state.agentOnline = AI.configured();
    const status = qs("#agentStatus");
    const badge = qs("#agentStatusBadge");
    if (status) status.textContent = state.agentOnline ? tr("agentConnected") : tr("agentOffline");
    if (badge) {
      badge.textContent = state.agentOnline ? "GEMINI" : "LOCAL";
      badge.classList.toggle("is-online", state.agentOnline);
    }
  }

  function renderAgentSuggestions(mode) {
    const target = mode === "profile" && state.agentTargetId ? findProfile(state.agentTargetId) : null;
    const opportunity = mode === "opportunity" && state.agentOpportunityId ? findOpportunity(state.agentOpportunityId) : null;
    const candidate = mode === "candidate" && state.agentTargetId ? findProfile(state.agentTargetId) : null;
    const organization = mode === "organization" && state.agentOrgId ? findOrg(state.agentOrgId) : null;
    let list;
    if (candidate) list = [state.lang === "fa" ? `چرا ${text(candidate.name)} برای نیازهای ما مرتبط است؟` : `Why is ${text(candidate.name)} relevant to our hiring needs?`, tr("gaps")];
    else if (opportunity) list = [state.lang === "fa" ? "آیا برای این فرصت مناسبم؟" : "Am I a fit for this opportunity?", tr("skillGap"), tr("similarOpportunities")];
    else if (organization && isCompany()) list = [state.lang === "fa" ? "کاندیداهای مناسب این نیاز را پیدا کن." : "Find candidates relevant to this need.", state.lang === "fa" ? "این سازمان به چه مهارت‌هایی نیاز دارد؟" : "What skills appear in this organization's opportunities?"];
    else if (target) list = [state.lang === "fa" ? `خلاصه حرفه‌ای ${text(target.name)} چیست؟` : `What is ${text(target.name)}'s professional profile?`, tr("askAboutProfile")];
    else if (isCompany()) list = [state.lang === "fa" ? "کاندیداهای مناسب را پیدا کن." : "Find relevant candidates.", state.lang === "fa" ? "نیازهای استخدامی شرکت را تحلیل کن." : "Analyze the company's hiring needs."];
    else list = [state.lang === "fa" ? "فرصت‌های مناسب پروفایل من را پیدا کن." : "Find relevant opportunities for me.", state.lang === "fa" ? "چه چیزی را باید اول بهبود بدهم؟" : "What should I improve first?"];
    const html = list.map((question) => `<button class="suggestion-btn" type="button" data-agent-suggestion="${escapeHTML(question)}">${escapeHTML(question)}</button>`).join("");
    qs("#agentSuggestions").innerHTML = html; qs("#agentDialogSuggestions").innerHTML = html;
  }

  function agentContext() {
    const target = state.agentTargetId ? findProfile(state.agentTargetId) : null;
    const opportunity = state.agentOpportunityId ? findOpportunity(state.agentOpportunityId) : null;
    const context = { viewer: serializeProfile(state.viewer), authenticated: Boolean(state.viewer), accountType: state.accountType, company: serializeCompany(state.company), target: serializeProfile(target), organization: state.agentOrgId ? serializeOrg(findOrg(state.agentOrgId)) : null, opportunity: serializeOpportunity(opportunity), mode: state.agentMode, page: location.hash || "#home" };
    if (opportunity && state.viewer && !isCompany()) context.computedFit = Matching.scoreJob(state.viewer, opportunity);
    if (target && isCompany()) context.computedFit = Matching.scoreCandidate(target, state.company);
    return context;
  }

  function renderAgentContext() {
    const ctx = agentContext();
    const rows = [`<div class="context-row"><span>${escapeHTML(tr("viewer"))}</span><strong>${escapeHTML(state.viewer ? text(state.viewer.name) : (state.lang === "fa" ? "بدون حساب" : "No account"))}</strong></div>`, `<div class="context-row"><span>${escapeHTML(tr("accountType"))}</span><strong>${escapeHTML(isCompany() ? tr("companyEmployer") : tr("jobSeeker"))}</strong></div>`];
    if (ctx.target) rows.push(`<div class="context-row"><span>${escapeHTML(tr("target"))}</span><strong>${escapeHTML(ctx.target.name)}</strong></div>`);
    if (ctx.organization) rows.push(`<div class="context-row"><span>${escapeHTML(tr("organization"))}</span><strong>${escapeHTML(ctx.organization.name)}</strong></div>`);
    if (ctx.opportunity) rows.push(`<div class="context-row"><span>${escapeHTML(tr("opportunity"))}</span><strong>${escapeHTML(ctx.opportunity.title)}</strong></div>`);
    qs("#agentContextChip")?.replaceChildren(document.createTextNode(`${state.agentMode.toUpperCase()} CONTEXT`));
    qs("#agentDialogContext")?.replaceChildren(document.createTextNode(`${state.agentMode} · ${state.agentOnline ? "LLM" : "demo"}`));
    if (qs("#agentContextPanel")) qs("#agentContextPanel").innerHTML = rows.join("");
  }

  function relevanceLabelText(label) {
    const map = {high: tr("highRelevance"), medium: tr("mediumRelevance"), partial: tr("partialRelevance"), low: tr("lowRelevance")};
    return map[label] || label || "—";
  }

  function fitSummary(fit) {
    return {relevance: fit?.relevance || "low", label: relevanceLabelText(fit?.relevance), strengths: (fit?.strongMatches || []).slice(0, 4), gaps: (fit?.missingSkills || []).slice(0, 4), concerns: (fit?.concerns || []).slice(0, 3)};
  }

  function renderAgentCards(cards = []) {
    return (cards || []).map((card) => {
      if (!card || !card.type) return "";
      if (card.type === "job") {
        const fit = card.fit || {};
        const summary = fitSummary(fit);
        return `<article class="chat-card chat-job-card"><div class="chat-card-top"><span class="chat-card-icon">${icon("briefcase")}</span><span class="relevance-pill ${escapeHTML(summary.relevance)}">${escapeHTML(summary.label)}</span></div><div><strong>${escapeHTML(card.title || "—")}</strong><span>${escapeHTML(card.organization || "")}</span></div><p>${escapeHTML(card.location || "")}${card.workMode ? ` · ${escapeHTML(card.workMode)}` : ""}</p><div class="chat-card-subgrid"><div><small>${escapeHTML(tr("strengths"))}</small>${summary.strengths.length ? `<span>${escapeHTML(summary.strengths.join(" · "))}</span>` : `<span class="muted">—</span>`}</div><div><small>${escapeHTML(tr("gaps"))}</small>${summary.gaps.length ? `<span>${escapeHTML(summary.gaps.join(" · "))}</span>` : `<span class="muted">—</span>`}</div></div><div class="chat-card-actions"><a class="soft-btn" href="#opportunities/${encodeURIComponent(card.id)}">${icon("arrow")}${escapeHTML(tr("viewDetails"))}</a><button class="primary-btn" type="button" data-open-agent="opportunity" data-agent-opportunity="${escapeHTML(card.id)}">${icon("bot")}${escapeHTML(tr("analyzeFit"))}</button></div></article>`;
      }
      if (card.type === "candidate") {
        const fit = card.fit || {};
        const summary = fitSummary(fit);
        return `<article class="chat-card chat-candidate-card"><div class="chat-card-top"><span class="avatar">${escapeHTML(initials(card.name || ""))}</span><span class="relevance-pill ${escapeHTML(summary.relevance)}">${escapeHTML(summary.label)}</span></div><div><strong>${escapeHTML(card.name || "—")}</strong><span>${escapeHTML(card.headline || "")}</span></div><div class="tag-row">${(card.skills || []).slice(0, 5).map((skill) => `<span class="tag">${escapeHTML(skill)}</span>`).join("")}</div><div class="chat-card-subgrid"><div><small>${escapeHTML(tr("strengths"))}</small>${summary.strengths.length ? `<span>${escapeHTML(summary.strengths.join(" · "))}</span>` : `<span class="muted">—</span>`}</div><div><small>${escapeHTML(tr("gaps"))}</small>${summary.gaps.length ? `<span>${escapeHTML(summary.gaps.join(" · "))}</span>` : `<span class="muted">—</span>`}</div></div><div class="chat-card-actions"><a class="soft-btn" href="#profile/${encodeURIComponent(card.id)}">${icon("user")}${escapeHTML(tr("viewProfile"))}</a><button class="primary-btn" type="button" data-open-agent="candidate" data-agent-target="${escapeHTML(card.id)}">${icon("bot")}${escapeHTML(tr("analyzeCandidate"))}</button></div></article>`;
      }
      if (card.type === "profile") {
        return `<article class="chat-card chat-profile-card"><div class="chat-card-top"><span class="avatar">${escapeHTML(initials(card.name || ""))}</span></div><div><strong>${escapeHTML(card.name || "—")}</strong><span>${escapeHTML(card.headline || "")}</span></div><p>${escapeHTML(card.about || "")}</p><div class="tag-row">${(card.skills || []).slice(0, 6).map((skill) => `<span class="tag">${escapeHTML(skill)}</span>`).join("")}</div><div class="chat-card-actions"><a class="soft-btn" href="#profile/${encodeURIComponent(card.id)}">${icon("user")}${escapeHTML(tr("viewProfile"))}</a><button class="primary-btn" type="button" data-open-agent="profile" data-agent-target="${escapeHTML(card.id)}">${icon("bot")}${escapeHTML(tr("askAboutProfile"))}</button></div></article>`;
      }
      return "";
    }).join("");
  }

  function renderAgentMessage(item) {
    const retry = item.retryMessage ? `<button class="text-btn agent-retry" type="button" data-agent-retry="${escapeHTML(item.retryMessage)}">${escapeHTML(tr("retry"))}</button>` : "";
    return `<div class="agent-msg ${item.role}"><div>${escapeHTML(item.content || "")}</div>${item.cards?.length ? `<div class="chat-card-stack">${renderAgentCards(item.cards)}</div>` : ""}${item.provider ? `<small>${escapeHTML(item.provider)}</small>` : ""}${retry}</div>`;
  }

  function loadingMessage() { return `<div class="agent-msg loading" role="status" aria-live="polite"><span class="agent-loading-dots" aria-hidden="true"><i></i><i></i><i></i></span><span>${escapeHTML(tr("agentLoading"))}</span></div>`; }
  function renderWorkspaceHistory() { const box = qs("#agentWorkspaceHistory"); if (!box) return; box.innerHTML = state.agentHistory.slice(-5).map(renderAgentMessage).join("") + (state.agentBusy ? loadingMessage() : ""); box.scrollTop = box.scrollHeight; }
  function renderDialogHistory() { const box = qs("#agentDialogMessages"); if (!box) return; box.innerHTML = state.agentHistory.slice(-20).map(renderAgentMessage).join("") + (state.agentBusy ? loadingMessage() : ""); box.scrollTop = box.scrollHeight; }
  function syncAgentBusyUI() {
    qsa("#agentForm .agent-send, #agentDialogForm .agent-send, #profileAgentForm .agent-send").forEach((button) => button.toggleAttribute("disabled", state.agentBusy));
    qsa("#agentForm, #agentDialogForm, #profileAgentForm").forEach((form) => form.toggleAttribute("aria-busy", state.agentBusy));
  }
  function setAgentBusy(value) { state.agentBusy = Boolean(value); document.body.classList.toggle("is-busy", state.agentBusy); qs("#agentDialog")?.classList.toggle("is-busy", state.agentBusy); syncAgentBusyUI(); renderWorkspaceHistory(); renderDialogHistory(); renderProfileInterview(); }

  function localIntent(message) {
    const query = String(message || "").toLocaleLowerCase();
    if (state.agentMode === "opportunity" && state.agentOpportunityId) {
      if (query.includes("similar") || query.includes("شبیه") || query.includes("مشابه")) return "find_similar_jobs";
      if (query.includes("fit") || query.includes("suitable") || query.includes("تناسب") || query.includes("مناسب") || query.includes("missing") || query.includes("چی کم")) return "analyze_job";
      if (query.includes("skill gap") || query.includes("شکاف مهارتی") || query.includes("improve") || query.includes("بهبود")) return "skill_gap";
    }
    if (state.agentMode === "candidate" && state.agentTargetId && isCompany()) return "analyze_candidate";
    if (isCompany() && (query.includes("hiring requirement") || query.includes("needs") || query.includes("نیازهای استخدامی") || query.includes("چه چیزی کم") || query.includes("what is missing") || query.includes("analyze our") || query.includes("improve our") || query.includes("بهبود نیاز") || query.includes("تحلیل کن"))) return "analyze_company";
    if (query.includes("candidate") || query.includes("کاندید") || query.includes("متقاضی")) return isCompany() ? "find_candidates" : "none";
    if ((query.includes("find") && (query.includes("job") || query.includes("opportun"))) || query.includes("فرصت مناسب") || query.includes("فرصت‌های مناسب") || query.includes("کاریابی")) return "find_jobs";
    if (query.includes("fit") || query.includes("suitable") || query.includes("تناسب") || query.includes("مناسبم") || query.includes("missing") || query.includes("چی کم")) return state.agentTargetId && isCompany() ? "analyze_candidate" : "skill_gap";
    if (query.includes("skill gap") || query.includes("شکاف مهارتی")) return state.agentMode === "opportunity" ? "skill_gap" : "improve_profile";
    if (query.includes("what should i improve") || query.includes("چه چیزی را بهتر") || query.includes("what am i missing") || query.includes("چی کم دارم")) return state.agentMode === "opportunity" ? "skill_gap" : "improve_profile";
    if (query.includes("career direction") || query.includes("مسیر شغلی") || query.includes("مسیر حرفه‌ای") || query.includes("career path")) return "career_direction";
    if (query.includes("suggest skill") || query.includes("پیشنهاد مهارت")) return "suggest_skills";
    if (query.includes("improve profile") || query.includes("بهبود پروفایل")) return "improve_profile";
    if (query.includes("don't want") || query.includes("prefer ") || query.includes("focus on") || query.includes("تمرکزم روی") || query.includes("ترجیح") || query.includes("نمی‌خواهم") || query.includes("نمیخوام")) return "update_preferences";
    return "none";
  }

  function parsePreferenceFeedback(message) {
    const text = String(message || "").trim();
    const lowerText = text.toLocaleLowerCase();
    const patch = {};
    const notes = [];
    const add = (field, value) => { patch[field] = [...new Set([...(patch[field] || []), value])].slice(0, 10); };
    if (/don't want remote|do not want remote|no remote|remote نمی‌خواهم|remote نمیخوام|ریموت نمی‌خواهم|ریموت نمیخوام/i.test(text)) { add("excludedWorkModes", "remote"); notes.push("excluded remote work"); }
    if (/prefer hybrid|hybrid ترجیح|هیبرید/i.test(text)) { add("preferredWorkModes", "hybrid"); notes.push("prefers hybrid"); }
    if (/prefer remote|remote را ترجیح|ریموت/i.test(text)) { add("preferredWorkModes", "remote"); notes.push("prefers remote"); }
    if (/prefer startup|startups|استارتاپ/i.test(text)) { add("preferredCompanyTypes", "startup"); notes.push("prefers startup companies"); }
    if (/don't want frontend|do not want frontend|frontend نمی‌خواهم|فرانت.?اند نمی‌خواهم/i.test(lowerText)) { add("excludedRoles", "frontend"); notes.push("excluded frontend roles"); }
    const skill = text.match(/(?:focus on|focus|تمرکزم روی|تمرکز روی)\s+([A-Za-z][A-Za-z0-9+.#-]{1,30})/i);
    if (skill?.[1]) { add("preferredSkills", skill[1]); notes.push(`focus skill ${skill[1]}`); }
    if (/prefer junior|junior می‌خواهم|جونیور/i.test(text)) { patch.preferredExperienceLevel = "junior"; notes.push("prefers junior level"); }
    if (/prefer mid|mid-level|میانی/i.test(text)) { patch.preferredExperienceLevel = "mid"; notes.push("prefers mid level"); }
    if (/prefer senior|senior می‌خواهم|ارشد/i.test(text)) { patch.preferredExperienceLevel = "senior"; notes.push("prefers senior level"); }
    return {patch, notes};
  }

  function mergePreferences(current, patch, message) {
    const existing = current?.preferences && typeof current.preferences === "object" ? current.preferences : {};
    const next = {...existing};
    for (const key of ["preferredWorkModes","excludedWorkModes","preferredCompanyTypes","excludedRoles","preferredSkills"]) next[key] = [...new Set([...(existing[key] || []), ...(patch[key] || [])])].slice(0, 12);
    if (patch.preferredExperienceLevel) next.preferredExperienceLevel = patch.preferredExperienceLevel;
    const note = String(message || "").trim(); if (note) next.feedbackNotes = [...new Set([...(existing.feedbackNotes || []), note.slice(0, 180)])].slice(-12);
    return next;
  }

  function resolveAgentTargetId(result, kind) {
    if (kind === "opportunity" && state.agentOpportunityId) return String(state.agentOpportunityId);
    if ((kind === "candidate" || kind === "profile") && state.agentTargetId) return String(state.agentTargetId);
    const candidate = String(result?.targetId || "").trim();
    if (!candidate) return null;
    if (kind === "opportunity") return findOpportunity(candidate) ? candidate : null;
    return findProfile(candidate) ? candidate : null;
  }

  function applyCompanyPatch(patch) {
    if (!isCompany() || !patch || typeof patch !== "object") return false;
    const allowed = ["name","focus","location","description","type","hiringInterests","desiredRoles","requiredSkills","preferredCharacteristics","preferredExperienceLevel","openPositions"];
    const filtered = {};
    for (const field of allowed) if (Object.prototype.hasOwnProperty.call(patch, field)) filtered[field] = patch[field];
    try {
      state.account = Store.updateCurrentCompany(filtered); state.company = state.account.company; syncAuthUI(); renderCurrentRoute(); return true;
    } catch (error) { console.error(error); return false; }
  }

  function executeControlledAction(action, result, clean) {
    const allowed = new Set(["none","collect_profile_facts","collect_company_facts","find_jobs","find_similar_jobs","analyze_job","find_candidates","analyze_candidate","analyze_profile","analyze_company","suggest_skills","skill_gap","career_direction","update_preferences","improve_profile"]);
    if (!allowed.has(action)) return {reply: tr("agentError"), cards: []};
    if (action === "update_preferences") {
      if (!state.viewer || isCompany()) return {reply: state.lang === "fa" ? "ترجیحات matching برای حساب کارجو فعال است." : "Matching preferences are available for Job Seeker accounts.", cards: []};
      const feedback = parsePreferenceFeedback(clean);
      const patch = feedback.patch;
      if (!Object.keys(patch).length) return {reply: state.lang === "fa" ? "ترجیح مشخصی که بتوانم ساختاریافته ذخیره کنم پیدا نکردم." : "I did not find a specific preference I can safely store.", cards: []};
      const preferences = mergePreferences(state.viewer, patch, clean);
      state.account = Store.updateCurrentProfile({preferences}); state.viewer = state.account.profile; Store.saveFeedback([...Store.getFeedback(), {at: new Date().toISOString(), message: clean, patch}]);
      renderCurrentRoute();
      return {reply: `${tr("preferencesUpdated")}\n${feedback.notes.length ? feedback.notes.join(" · ") : Object.entries(patch).flatMap(([key, values]) => Array.isArray(values) ? values : [values]).join(" · ")}`, cards: []};
    }
    if (action === "collect_profile_facts" && state.viewer && !isCompany()) {
      const parsed = ProfileAgent.extract(clean, state.profileInterview.questionKey || "experience", state.viewer, [...state.data.profiles.flatMap((item) => item.skills || []), ...state.data.opportunities.flatMap((item) => item.skills || [])]);
      if (!Object.keys(parsed.patch).length) return {reply: tr("agentNoFact"), cards: []};
      const saved = applyProfilePatch(parsed.patch);
      if (!saved) return {reply: tr("saveFailed"), cards: []};
      return {reply: `${tr("agentFactAdded")}\n${ProfileAgent.summarizePatch(parsed.patch).join("\n")}`, cards: []};
    }
    if (action === "collect_company_facts" && isCompany()) {
      const parsed = CompanyAgent.extract(clean, state.companyInterview.questionKey || "name", state.company, [...state.data.profiles.flatMap((item) => item.skills || []), ...state.data.opportunities.flatMap((item) => item.skills || [])]);
      if (!Object.keys(parsed.patch).length) return {reply: state.lang === "fa" ? "fact مشخصی برای ذخیره از این پیام پیدا نکردم." : "I did not find a structured company fact I can safely store.", cards: []};
      const saved = applyCompanyPatch(parsed.patch);
      if (!saved) return {reply: tr("saveFailed"), cards: []};
      return {reply: `${tr("agentFactAdded")}\n${CompanyAgent.summarize(parsed.patch).join("\n")}`, cards: []};
    }
    if (action === "find_jobs") {
      if (!state.viewer || isCompany()) return {reply: state.lang === "fa" ? "برای matching فرصت‌ها یک حساب کارجو و Profile نیاز است." : "Job matching requires a Job Seeker account and profile.", cards: []};
      const ranked = Matching.rankJobs(state.viewer, state.data.opportunities).filter((item) => item.fit.score >= 30).slice(0, 4);
      return {reply: ranked.length ? `${state.lang === "fa" ? "فرصت‌ها بر اساس داده ساختاریافته رتبه‌بندی شدند." : "Opportunities are ranked from structured profile and job data."}\n${tr("matchingEngineNote")}` : tr("noJobs"), cards: ranked.map(({job, fit}) => ({type: "job", id: job.id, title: text(job.title), organization: text(findOrg(job.organizationId)?.name), location: text(job.location), workMode: text(job.workMode), fit}))};
    }
    if (action === "find_similar_jobs") {
      const job = findOpportunity(resolveAgentTargetId(result, "opportunity"));
      if (!job) return {reply: tr("noSimilarOpportunities"), cards: []};
      const targetSkills = new Set((job.skills || []).map((s) => String(s).toLocaleLowerCase()));
      const ranked = state.data.opportunities.filter((item) => String(item.id) !== String(job.id)).map((item) => {
        const overlapCount = (item.skills || []).filter((s) => targetSkills.has(String(s).toLocaleLowerCase())).length;
        const skillRatio = targetSkills.size ? overlapCount / targetSkills.size : 0;
        const titleSimilarity = Matching.tokenSimilarity(text(item.title), text(job.title));
        const modeBonus = item.workMode && job.workMode && item.workMode === job.workMode ? 0.08 : 0;
        return {job: item, score: skillRatio * 0.72 + titleSimilarity * 0.20 + modeBonus};
      }).sort((a,b) => b.score - a.score).slice(0,3);
      return {reply: ranked.length ? tr("similarOpportunities") : tr("noSimilarOpportunities"), cards: ranked.map(({job: item}) => ({type:"job", id:item.id, title:text(item.title), organization:text(findOrg(item.organizationId)?.name), location:text(item.location), workMode:text(item.workMode), fit: state.viewer && !isCompany() ? Matching.scoreJob(state.viewer, item) : {relevance:"partial", strongMatches:[], missingSkills:[], reasoning:"Similar by structured job attributes."}}))};
    }
    if (action === "analyze_job") {
      const job = findOpportunity(resolveAgentTargetId(result, "opportunity")); if (!job) return {reply: state.lang === "fa" ? "فرصت مشخصی برای تحلیل پیدا نکردم." : "I could not find the opportunity to analyze.", cards: []};
      if (!state.viewer || isCompany()) return {reply: state.lang === "fa" ? "برای fit شخصی، یک Profile کارجو لازم است." : "A Job Seeker profile is required for a personal fit analysis.", cards: []};
      const fit = Matching.scoreJob(state.viewer, job);
      return {reply: `${relevanceLabelText(fit.relevance)} — ${fit.reasoning}\n${fit.missingSkills.length ? `${tr("gaps")}: ${fit.missingSkills.join(", ")}` : `${tr("strengths")}: ${fit.strongMatches.join(", ") || "—"}`}`, cards: [{type: "job", id: job.id, title: text(job.title), organization: text(findOrg(job.organizationId)?.name), location: text(job.location), workMode: text(job.workMode), fit}]};
    }
    if (action === "find_candidates") {
      if (!isCompany()) return {reply: state.lang === "fa" ? "این action برای حساب شرکت است." : "This action is for Company accounts.", cards: []};
      const ranked = Matching.rankCandidates(state.company, candidatePool()).filter((item) => item.fit.score >= 30).slice(0, 5);
      return {reply: ranked.length ? `${state.lang === "fa" ? "کاندیداها بر اساس نیازهای ساختاریافته شرکت رتبه‌بندی شدند." : "Candidates are ranked from the company's structured hiring requirements."}\n${tr("matchingEngineNote")}` : tr("noCandidates"), cards: ranked.map(({candidate, fit}) => ({type: "candidate", id: candidate.id, name: text(candidate.name), headline: text(candidate.headline), skills: candidate.skills || [], fit}))};
    }
    if (action === "analyze_candidate") {
      if (!isCompany()) return {reply: state.lang === "fa" ? "برای تحلیل candidate باید با حساب شرکت وارد باشی." : "Sign in as a Company account to analyze candidates.", cards: []};
      const candidate = findProfile(resolveAgentTargetId(result, "candidate")); if (!candidate) return {reply: tr("noCandidates"), cards: []};
      const fit = Matching.scoreCandidate(candidate, state.company);
      return {reply: `${relevanceLabelText(fit.relevance)} — ${fit.reasoning}\n${fit.missingSkills.length ? `${tr("gaps")}: ${fit.missingSkills.join(", ")}` : `${tr("strengths")}: ${fit.strongMatches.join(", ") || "—"}`}`, cards: [{type: "candidate", id: candidate.id, name: text(candidate.name), headline: text(candidate.headline), skills: candidate.skills || [], fit}]};
    }
    if (action === "skill_gap") {
      const job = findOpportunity(state.agentOpportunityId); if (!job || !state.viewer || isCompany()) return {reply: state.lang === "fa" ? "یک فرصت را باز کن تا شکاف مهارتی آن را با Profile مقایسه کنم." : "Open a specific opportunity so I can compare it with your Profile.", cards: []};
      const fit = Matching.scoreJob(state.viewer, job);
      return {reply: `${tr("strengths")}: ${fit.strongMatches.join(", ") || "—"}\n${tr("gaps")}: ${fit.missingSkills.join(", ") || "—"}\n${tr("concerns")}: ${fit.concerns.join("; ") || "none visible"}`, cards: [{type: "job", id: job.id, title: text(job.title), organization: text(findOrg(job.organizationId)?.name), location: text(job.location), workMode: text(job.workMode), fit}]};
    }
    if (action === "analyze_company") {
      if (!isCompany()) return {reply: state.lang === "fa" ? "این تحلیل برای حساب شرکت است." : "This analysis is for Company accounts.", cards: []};
      const missing = [];
      if (!String(state.company?.name || "").trim()) missing.push(tr("companyName"));
      if (!String(state.company?.focus || "").trim()) missing.push(tr("hiringFocus"));
      if (!(state.company?.desiredRoles || []).length) missing.push(tr("desiredRoles"));
      if (!(state.company?.requiredSkills || []).length) missing.push(tr("requiredSkills"));
      if (!String(state.company?.preferredExperienceLevel || "").trim()) missing.push(tr("experienceLevel"));
      const roleCount = (state.company?.desiredRoles || []).length;
      const skillCount = (state.company?.requiredSkills || []).length;
      const candidatePoolItems = candidatePool();
      const talentGaps = (state.company?.requiredSkills || []).filter((skill) => !candidatePoolItems.some((candidate) => (candidate.skills || []).some((candidateSkill) => Matching.tokenSimilarity(candidateSkill, skill) >= 0.82)));
      const roleGaps = (state.company?.desiredRoles || []).filter((role) => !candidatePoolItems.some((candidate) => Matching.tokenSimilarity(candidate.headline, role) >= 0.45));
      const gapText = [...talentGaps.slice(0, 4).map((skill) => `${tr("skills")}: ${skill}`), ...roleGaps.slice(0, 3).map((role) => `${tr("desiredRoles")}: ${role}`)];
      const evidence = gapText.length ? ` ${tr("gaps")}: ${gapText.join(" · ")}.` : (state.lang === "fa" ? " talent gap واضحی در synthetic candidate pool دیده نشد." : " No obvious talent gap is visible in the synthetic candidate pool.");
      return {reply: missing.length ? `${tr("gaps")}: ${missing.join(", ")}.` : `${state.lang === "fa" ? "نیاز استخدامی ساختاریافته است." : "The hiring requirement is sufficiently structured."} ${roleCount} ${tr("desiredRoles").toLocaleLowerCase()} · ${skillCount} ${tr("requiredSkills").toLocaleLowerCase()}.${evidence}`, cards: []};
    }
    if (action === "suggest_skills") {
      if (!state.viewer || isCompany()) return {reply: state.lang === "fa" ? "پیشنهاد skill در این نسخه برای کارجو است." : "Skill suggestions are available for Job Seeker accounts.", cards: []};
      const ranked = Matching.rankJobs(state.viewer, state.data.opportunities).slice(0, 3);
      const missing = [...new Set(ranked.flatMap((item) => item.fit.missingSkills))].slice(0, 6);
      let saved = false;
      if (missing.length) {
        try {
          const mergedRecommendations = [...new Set([...(state.viewer.aiRecommendations || []), ...missing])].slice(0, 8);
          const account = Store.updateCurrentProfile({aiRecommendations: mergedRecommendations});
          state.account = account; state.viewer = account.profile; saved = true;
        } catch (error) { console.error(error); }
      }
      return {reply: missing.length ? `${state.lang === "fa" ? "مهارت‌های اولویت‌دار از روی فرصت‌های موجود:" : "Priority skills visible from the available opportunities:"} ${missing.join(", ")}.${saved ? "" : ` ${state.lang === "fa" ? "پیشنهادها نمایش داده شدند اما ذخیره نشدند." : "The suggestions are shown but could not be saved."}`}` : (state.lang === "fa" ? "با داده فعلی شکاف skill واضحی برای پیشنهاد پیدا نکردم." : "The current data does not reveal a clear additional skill gap."), cards: []};
    }
    if (action === "analyze_profile" || action === "improve_profile") {
      if (!state.viewer || isCompany()) return {reply: state.lang === "fa" ? "این action برای Profile کارجو است." : "This action is for a Job Seeker Profile.", cards: []};
      const missing = []; if (!text(state.viewer.headline)) missing.push(tr("headline")); if (!text(state.viewer.about)) missing.push(tr("about")); if (!(state.viewer.experience || []).length) missing.push(tr("experience")); if (!(state.viewer.skills || []).length) missing.push(tr("skills")); if (!(state.viewer.targetRoles || []).length) missing.push(tr("targetRoles")); if (!text(state.viewer.goals)) missing.push(tr("professionalGoal"));
      const card = {type: "profile", id: state.viewer.id, name: text(state.viewer.name), headline: text(state.viewer.headline), about: text(state.viewer.about), skills: state.viewer.skills || []};
      return {reply: `${tr("completeness")}: ${profileCompleteness(state.viewer)}%.\n${missing.length ? `${tr("gaps")}: ${missing.join(", ")}` : (state.lang === "fa" ? "فیلدهای اصلی پر شده‌اند؛ حالا می‌توانی روی شفافیت تجربه و هدف شغلی کار کنی." : "The main fields are present; now focus on clarity of experience and career intent.")}`, cards: [card]};
    }
    if (action === "career_direction") {
      if (!state.viewer || isCompany()) return {reply: state.lang === "fa" ? "این action برای مسیر حرفه‌ای کارجو است." : "Career direction analysis is for Job Seeker accounts.", cards: []};
      const ranked = Matching.rankJobs(state.viewer, state.data.opportunities).slice(0, 4);
      const directions = [...new Set(ranked.map(({job}) => text(job.title).replace(/\s*[-—].*$/, "").trim()).filter(Boolean))].slice(0, 3);
      const targetRoles = state.viewer.targetRoles || [];
      return {reply: directions.length ? `${state.lang === "fa" ? "با تکیه بر پروفایل فعلی و فرصت‌های synthetic موجود، این جهت‌ها قابل بررسی‌اند:" : "Based on the current profile and available synthetic opportunities, these directions are worth exploring:"} ${directions.join(" · ")}. ${targetRoles.length ? `${tr("targetRoles")}: ${targetRoles.join(", ")}.` : ""}` : (state.lang === "fa" ? "برای تحلیل مسیر حرفه‌ای، داده ساختاریافته بیشتری لازم است." : "More structured profile data is needed for a useful career-direction analysis."), cards: []};
    }
    return {reply: result.reply || localAgentReply(clean).reply || tr("agentError"), cards: []};
  }


  function localAgentReply(message) {
    const action = localIntent(message);
    const query = String(message || "").toLocaleLowerCase();
    if (state.agentMode === "opportunity" && state.agentOpportunityId && action === "none") return {reply: state.lang === "fa" ? "این فرصت را می‌توانم با Profile فعلی‌ات مقایسه کنم؛ «آیا برای این مناسبم؟» را بپرس." : "I can compare this opportunity with your current Profile; ask “Am I a fit for this job?”", action: "analyze_job", provider: "deterministic-agent"};
    if (state.agentMode === "candidate" && state.agentTargetId && action === "none") return {reply: state.lang === "fa" ? "برای این فرد، درباره skillهای مشترک یا gapها بپرس." : "Ask about this candidate's matched skills or gaps.", action: "analyze_candidate", provider: "deterministic-agent"};
    if (state.agentMode === "organization" && isCompany() && action === "none") return {reply: state.lang === "fa" ? "می‌توانم کاندیداهای مرتبط با نیازهای استخدامی شرکت را پیدا کنم." : "I can find candidates relevant to the company's hiring requirements.", action: "find_candidates", provider: "deterministic-agent"};
    if (action !== "none") return {reply: "", action, provider: "deterministic-agent"};
    if (state.agentMode === "profile" && state.viewer) return {reply: state.lang === "fa" ? `این Profile متعلق به ${text(state.viewer.name)} است و شامل ${state.viewer.skills?.length || 0} مهارت، ${state.viewer.experience?.length || 0} سابقه و ${state.viewer.interests?.length || 0} علاقه حرفه‌ای است.` : `This Profile belongs to ${text(state.viewer.name)} and currently contains ${state.viewer.skills?.length || 0} skills, ${state.viewer.experience?.length || 0} experiences, and ${state.viewer.interests?.length || 0} professional interests.`, action: "none", provider: "deterministic-agent"};
    return {reply: state.lang === "fa" ? "من context همین صفحه را دارم. درباره فرصت، profile یا candidate سؤال کن تا action مناسب را اجرا کنم." : "I have this page's context. Ask about the opportunity, profile, or candidate and I will run the relevant action.", action: "none", provider: "deterministic-agent"};
  }

  function rankedOpportunities(profile) {
    return Matching.rankJobs(profile, state.data.opportunities);
  }

  async function callAgentEndpoint(message, mode = state.agentMode, extraContext = {}) {
    if (!AI.configured()) return null;
    return AI.run({message, operation: mode, history: state.agentHistory, context: {...agentContext(), mode, ...extraContext}});
  }

  async function askAgent(message) {
    if (!AI.configured()) return localAgentReply(message);
    try {
      return await callAgentEndpoint(message);
    } catch (error) {
      return {error, reply: "", action: localIntent(message), provider: "AI error"};
    }
  }

  async function submitAgent(message) {
    const clean = String(message || "").trim(); if (!clean || state.agentBusy) return;
    state.agentHistory.push({role: "user", content: clean}); Store.saveAgentHistory(state.agentHistory); setAgentBusy(true);
    try {
      const feedback = (!isCompany() && state.viewer) ? parsePreferenceFeedback(clean) : {patch: {}, notes: []};
      if (Object.keys(feedback.patch).length && (localIntent(clean) === "update_preferences" || /prefer|don't want|نمی‌خواهم|ترجیح/i.test(clean))) {
        const result = await Promise.resolve({reply: "", action: "update_preferences", preferencePatch: feedback.patch, provider: "deterministic-preference-tool"});
        const executed = executeControlledAction(result.action, result, clean);
        state.agentHistory.push({role: "assistant", content: executed.reply, cards: executed.cards || [], provider: result.provider});
      } else {
        const result = await askAgent(clean);
        if (result.error) {
          const fallbackAction = localIntent(clean);
          const executed = fallbackAction !== "none" ? executeControlledAction(fallbackAction, result, clean) : {reply: tr("agentError"), cards: []};
          const honesty = `${tr("aiUnavailableHonest")}
${executed.reply || ""}`.trim();
          state.agentHistory.push({role: "assistant", content: honesty, cards: executed.cards || [], provider: "AI error + deterministic tool", retryMessage: clean});
        } else {
          const action = result.action || localIntent(clean);
          const executed = executeControlledAction(action, result, clean);
          const combined = [result.reply, executed.reply].filter(Boolean).join("\n\n");
          state.agentHistory.push({role: "assistant", content: combined || tr("agentError"), cards: executed.cards || [], provider: result.provider || "Agent"});
        }
      }
    } catch (error) {
      console.error(error);
      state.agentHistory.push({role: "assistant", content: tr("agentError"), provider: "error", retryMessage: clean});
    } finally {
      setAgentBusy(false); Store.saveAgentHistory(state.agentHistory); renderCurrentRoute(); renderAgentContext();
    }
  }

  function saveConnections() { Store.setConnections(state.connections); }
  function toggleConnection(id) {
    if (!state.viewer) { openAuth(); return; }
    const key = String(id); state.connections.has(key) ? state.connections.delete(key) : state.connections.add(key); saveConnections(); renderCurrentRoute(); toast(tr("connectionSaved"));
  }

  function saveProfilePatch(patch) {
    if (!state.viewer || !patch || typeof patch !== "object") return false;
    try {
      const account = Store.updateCurrentProfile(patch);
      state.account = account; state.viewer = account.profile;
      syncAuthUI(); renderCurrentRoute(); return true;
    } catch (error) { console.error(error); return false; }
  }

  function applyProfilePatch(patch) {
    const allowed = ["name", "headline", "location", "about", "skills", "interests", "targetRoles", "goals", "experience", "education", "projects", "resume", "preferences", "aiRecommendations"];
    const filtered = {};
    for (const field of allowed) if (Object.prototype.hasOwnProperty.call(patch, field)) filtered[field] = patch[field];
    return saveProfilePatch(filtered);
  }

  function syncAuthUI() {
    const label = qs("#authTriggerLabel");
    if (label) label.textContent = state.viewer ? (isCompany() ? (text(state.company?.name) || tr("companyDashboard")) : (text(state.viewer.name) || tr("openMyProfile"))) : tr("authEntry");
    qs(".auth-trigger")?.classList.toggle("is-account", Boolean(state.viewer));
    qsa(".company-nav-link").forEach((el) => el.classList.toggle("hidden", !isCompany()));
    renderAuthState();
  }

  function renderAuthState() {
    const join = qs("#joinAuthFields"); const sign = qs("#signInAuthFields"); const submit = qs("#authSubmit"); const logged = qs("#authLoggedIn"); const form = qs("#authForm");
    qsa("[data-auth-mode]").forEach((tab) => tab.classList.toggle("active", tab.dataset.authMode === state.authMode));
    if (state.viewer) {
      form?.classList.add("hidden"); if (join) join.classList.add("hidden"); if (sign) sign.classList.add("hidden"); if (submit) submit.classList.add("hidden"); if (logged) { logged.classList.remove("hidden"); logged.innerHTML = `<div class="account-state"><span class="avatar">${escapeHTML(initials(isCompany() ? (state.company?.name || state.viewer.name) : state.viewer.name))}</span><div><strong>${escapeHTML(isCompany() ? (state.company?.name || state.viewer.name) : text(state.viewer.name))}</strong><span>${escapeHTML(state.account?.identifier || "")} · ${escapeHTML(isCompany() ? tr("companyEmployer") : tr("jobSeeker"))}</span></div></div><div class="profile-actions"><a class="primary-btn" href="#${isCompany() ? "company" : "profile"}" data-close-auth>${icon(isCompany() ? "building" : "user")}${escapeHTML(isCompany() ? tr("companyDashboard") : tr("openMyProfile"))}</a><button class="ghost-btn" type="button" data-sign-out>${icon("login")}${escapeHTML(tr("signOut"))}</button></div>`; }
      return;
    }
    logged?.classList.add("hidden"); form?.classList.remove("hidden");
    if (join) join.classList.toggle("hidden", state.authMode !== "join"); if (sign) sign.classList.toggle("hidden", state.authMode !== "signin"); if (submit) { submit.classList.remove("hidden"); submit.textContent = state.authMode === "join" ? tr("createAccount") : tr("signInAction"); }
    qs("#authMessage")?.replaceChildren();
  }

  function validateIdentifier(type, value) {
    const clean = String(value || "").trim();
    if (type === "email") return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(clean);
    return /^\+?[\d\s()\-]{7,20}$/.test(clean);
  }

  function openAuth() { renderAuthState(); qs("#authDialog")?.showModal(); }
  function setAuthMode(mode) { state.authMode = mode === "signin" ? "signin" : "join"; renderAuthState(); qs("#authMessage")?.replaceChildren(); }

  function handleAuthSubmit(form) {
    const identifierType = form.elements.identifierType.value; const identifier = form.elements.identifier.value.trim(); const firstName = form.elements.firstName?.value.trim() || ""; const lastName = form.elements.lastName?.value.trim() || "";
    const message = qs("#authMessage");
    if (!validateIdentifier(identifierType, identifier)) { message.textContent = tr("authIdentifierValidation"); return; }
    if (state.authMode === "join") {
      if (!firstName || !lastName) { message.textContent = tr("authValidation"); return; }
      try { const accountType = form.elements.accountType?.value === "company" ? "company" : "job-seeker"; const account = Store.createAccount({identifier, identifierType, firstName, lastName, accountType}); state.account = account; state.viewer = account.profile; state.accountType = account.accountType; state.company = account.company; state.connections = Store.getConnections(); state.agentHistory = Store.getAgentHistory(); state.profileInterview = {started: false, questionKey: null, skipped: {}, messages: []}; state.companyInterview = {started: false, questionKey: null, skipped: {}, messages: []}; qs("#authDialog")?.close(); syncAuthUI(); toast(tr("accountCreated")); location.hash = accountType === "company" ? "#company" : "#profile"; setTimeout(() => accountType === "company" ? openCompanyAgent(true) : openProfileAgent(true), 80); }
      catch (error) { message.textContent = error.message === "account_exists" ? tr("accountExists") : tr("authValidation"); }
    } else {
      try { const account = Store.signIn(identifier); state.account = account; state.viewer = account.profile; state.accountType = account.accountType === "company" ? "company" : "job-seeker"; state.company = account.company; state.connections = Store.getConnections(); state.agentHistory = Store.getAgentHistory(); qs("#authDialog")?.close(); syncAuthUI(); toast(tr("accountSignedIn")); renderCurrentRoute(); }
      catch { message.textContent = tr("accountNotFound"); }
    }
  }

  function signOut() { Store.signOut(); state.account = null; state.viewer = null; state.company = null; state.accountType = "job-seeker"; state.connections = Store.getConnections(); state.agentHistory = Store.getAgentHistory(); state.profileInterview = {started: false, questionKey: null, skipped: {}, messages: []}; state.companyInterview = {started: false, questionKey: null, skipped: {}, messages: []}; syncAuthUI(); qs("#authDialog")?.close(); renderCurrentRoute(); toast(tr("accountSignedOut")); }

  function openAgent(mode = "network", targetId = null, orgId = null, opportunityId = null) {
    state.agentMode = mode; state.agentTargetId = targetId ? String(targetId) : null; state.agentOrgId = orgId ? String(orgId) : null; state.agentOpportunityId = opportunityId ? String(opportunityId) : null;
    renderAgentContext(); renderAgentSuggestions(mode); renderDialogHistory(); qs("#agentDialog")?.showModal();
  }

  function openProfileAgent(reset = false) {
    if (!state.viewer) { openAuth(); return; }
    state.agentMode = "profile-create";
    if (reset || !state.profileInterview.messages.length) {
      state.profileInterview = {started: true, questionKey: "experience", skipped: {}, messages: []};
      const first = ProfileAgent.nextQuestion(state.viewer, state.profileInterview.skipped); state.profileInterview.questionKey = first.key; pushInterviewMessage("assistant", state.lang === "fa" ? first.textFa : first.textEn, AI.configured() ? tr("externalAgent") : tr("localAgent"));
    } else state.profileInterview.started = true;
    renderProfileInterview(); qs("#profileAgentDialog")?.showModal();
  }

  function pushInterviewMessage(role, content, provider = "") { state.profileInterview.messages.push({role, content, provider}); }

  function interviewProgress() {
    const p = state.viewer; if (!p) return 0;
    return Math.min(100, Math.round((profileCompleteness(p) * 0.82) + (state.profileInterview.messages.length > 1 ? 18 : 0)));
  }

  function renderProfileInterview() {
    const box = qs("#profileAgentMessages"); if (!box) return;
    const interview = state.agentMode === "company-create" ? state.companyInterview : state.profileInterview;
    if (!interview.started) return;
    const progress = state.agentMode === "company-create" ? companyInterviewProgress() : interviewProgress();
    qs("#profileAgentProgress")?.style.setProperty("width", `${progress}%`);
    qs("#profileAgentProgressText")?.replaceChildren(document.createTextNode(`${progress}%`));
    box.innerHTML = interview.messages.map((item) => `<div class="agent-msg ${item.role}"><div>${escapeHTML(item.content)}</div>${item.provider ? `<small>${escapeHTML(item.provider)}</small>` : ""}</div>`).join("") + (state.agentBusy ? loadingMessage() : ""); box.scrollTop = box.scrollHeight;
    const done = interview.questionKey === "done";
    const input = qs("#profileAgentInput"); if (input) { input.disabled = done || state.agentBusy; input.placeholder = state.agentMode === "company-create" ? tr("companyAgentPlaceholder") : tr("interviewPlaceholder"); }
    qs("#profileAgentForm .agent-send")?.toggleAttribute("disabled", done || state.agentBusy);
    const title = qs("#profileAgentDialog [data-i18n='interviewTitle']"); if (title) title.textContent = state.agentMode === "company-create" ? tr("companyOnboardingTitle") : tr("interviewTitle");
    const modeLabel = qs("#profileAgentMode"); if (modeLabel) modeLabel.textContent = `${state.agentMode === "company-create" ? tr("companyAgent") : (AI.configured() ? tr("externalAgent") : tr("localAgent"))}`;
    const desc = qs("#profileAgentDialog [data-i18n='interviewDesc']"); if (desc) desc.textContent = state.agentMode === "company-create" ? tr("companyOnboardingDesc") : tr("interviewDesc");
  }

  function companyInterviewProgress() {
    const c = state.company; if (!c) return 0;
    const checks = [Boolean(c.name), Boolean(c.focus), Boolean(c.location), Boolean(c.type), (c.desiredRoles || []).length > 0, (c.requiredSkills || []).length > 0, Boolean(c.preferredExperienceLevel), (c.preferredCharacteristics || []).length > 0];
    return Math.min(100, Math.round((checks.filter(Boolean).length / checks.length) * 100));
  }

  function openCompanyAgent(reset = false) {
    if (!isCompany()) { openAuth(); return; }
    state.agentMode = "company-create";
    if (reset || !state.companyInterview.messages.length) {
      state.companyInterview = {started: true, questionKey: "name", skipped: {}, messages: []};
      const first = CompanyAgent.nextQuestion(state.company, state.companyInterview.skipped); state.companyInterview.questionKey = first.key; pushCompanyInterviewMessage("assistant", state.lang === "fa" ? first.fa : first.en, AI.configured() ? tr("externalAgent") : tr("localAgent"));
    } else state.companyInterview.started = true;
    renderProfileInterview(); qs("#profileAgentDialog")?.showModal();
  }

  function pushCompanyInterviewMessage(role, content, provider = "") { state.companyInterview.messages.push({role, content, provider}); }

  async function submitCompanyInterview(message) {
    const clean = String(message || "").trim(); if (!clean || !isCompany() || state.agentBusy) return;
    pushCompanyInterviewMessage("user", clean); setAgentBusy(true);
    try {
      const questionKey = state.companyInterview.questionKey || "name";
      let remote = null; let remoteError = null;
      if (AI.configured()) { try { remote = await callAgentEndpoint(clean, "company-create", {interview: {questionKey, company: serializeCompany(state.company)}}); } catch (error) { remoteError = error; console.warn("Company Agent unavailable", error); } }
      if (remoteError) pushCompanyInterviewMessage("assistant", tr("aiInterviewFailure"), "AI unavailable → deterministic interviewer");
      const parsed = CompanyAgent.extract(clean, questionKey, state.company, [...state.data.profiles.flatMap((item) => item.skills || []), ...state.data.opportunities.flatMap((item) => item.skills || [])]);
      if (parsed.skipped) state.companyInterview.skipped[questionKey] = true;
      const patch = parsed.patch;
      if (Object.keys(patch).length) { const saved = applyCompanyPatch(patch); pushCompanyInterviewMessage("assistant", saved ? `${tr("agentFactAdded")}:\n${CompanyAgent.summarize(patch).join("\n")}` : tr("saveFailed"), remote?.provider || tr("localAgent")); }
      else if (!parsed.skipped) pushCompanyInterviewMessage("assistant", state.lang === "fa" ? "از این پیام fact شرکتی امنی برای ذخیره پیدا نکردم." : "I could not find a company fact I can safely store from that message.", remote?.provider || tr("localAgent"));
      const next = CompanyAgent.nextQuestion(state.company, state.companyInterview.skipped); state.companyInterview.questionKey = next.key;
      const nextText = remote?.nextQuestion && next.key !== "done" ? remote.nextQuestion : (next.key === "done" ? tr("companyDone") : (state.lang === "fa" ? next.fa : next.en));
      pushCompanyInterviewMessage("assistant", nextText, remote?.provider || tr("localAgent"));
    } finally {
      setAgentBusy(false); syncAgentStatus(); renderCurrentRoute();
    }
  }

  async function submitProfileInterview(message) {
    if (state.agentMode === "company-create") return submitCompanyInterview(message);
    const clean = String(message || "").trim(); if (!clean || !state.viewer || state.agentBusy) return;
    pushInterviewMessage("user", clean); setAgentBusy(true);
    try {
      const questionKey = state.profileInterview.questionKey || "experience";
      let remote = null; let remoteError = null;
      if (AI.configured()) { try { remote = await callAgentEndpoint(clean, "profile-create", {interview: {questionKey, profile: serializeProfile(state.viewer)}}); } catch (error) { remoteError = error; console.warn("Profile Agent unavailable", error); } }
      if (remoteError) pushInterviewMessage("assistant", tr("aiInterviewFailure"), "AI unavailable → deterministic interviewer");
      const parsed = ProfileAgent.extract(clean, questionKey, state.viewer, [...state.data.profiles.flatMap((item) => item.skills || []), ...state.data.opportunities.flatMap((item) => item.skills || [])]);
      if (parsed.skipped) state.profileInterview.skipped[questionKey] = true;
      const patch = parsed.patch;
      if (Object.keys(patch).length) { const saved = applyProfilePatch(patch); pushInterviewMessage("assistant", saved ? `${tr("agentFactAdded")}:\n${ProfileAgent.summarizePatch(patch).join("\n")}` : tr("saveFailed"), remote?.provider || tr("localAgent")); }
      else if (!parsed.skipped) pushInterviewMessage("assistant", tr("agentNoFact"), remote?.provider || tr("localAgent"));
      const next = ProfileAgent.nextQuestion(state.viewer, state.profileInterview.skipped); state.profileInterview.questionKey = next.key;
      const nextText = remote?.nextQuestion && next.key !== "done" ? remote.nextQuestion : (next.key === "done" ? tr("interviewDone") : (state.lang === "fa" ? next.textFa : next.textEn));
      pushInterviewMessage("assistant", nextText, remote?.provider || tr("localAgent"));
    } finally {
      setAgentBusy(false); syncAgentStatus(); renderCurrentRoute();
    }
  }

  function toast(message) { const stack = qs("#toastStack"); const item = document.createElement("div"); item.className = "toast"; item.textContent = message; stack?.append(item); setTimeout(() => item.remove(), 2800); }

  function populateEditForm() {
    if (!state.viewer) return;
    const form = qs("#editProfileForm"); if (!form) return;
    const [firstName, ...lastParts] = text(state.viewer.name).trim().split(/\s+/); const lastName = lastParts.join(" ");
    form.elements.firstName.value = firstName || ""; form.elements.lastName.value = lastName || ""; form.elements.headline.value = text(state.viewer.headline); form.elements.location.value = text(state.viewer.location); form.elements.about.value = text(state.viewer.about); form.elements.skills.value = (state.viewer.skills || []).join(", "); form.elements.interests.value = (state.viewer.interests || []).join(", "); form.elements.targetRoles.value = (state.viewer.targetRoles || []).join(", "); form.elements.goals.value = text(state.viewer.goals); form.elements.resume.value = state.viewer.resume || "";
    form.elements.education.value = (state.viewer.education || []).map((item) => [item.degree, item.school, item.period].filter(Boolean).join(" — ")).join("\n"); form.elements.projects.value = (state.viewer.projects || []).map((item) => [item.name, item.summary, item.link].filter(Boolean).join(" — ")).join("\n");
    state.experienceDraft = (state.viewer.experience || []).map((item) => ({...item})); renderExperienceEditor();
  }

  function renderExperienceEditor() {
    const box = qs("#experienceEditor"); if (!box) return;
    box.innerHTML = state.experienceDraft.map((item, index) => `<div class="experience-editor" data-experience-index="${index}"><div class="editor-grid"><label class="field"><span>${escapeHTML(tr("role"))}</span><input data-exp-field="role" value="${escapeHTML(item.role || "")}" maxlength="100"></label><label class="field"><span>${escapeHTML(tr("company"))}</span><input data-exp-field="company" value="${escapeHTML(item.company || "")}" maxlength="100"></label><label class="field"><span>${escapeHTML(tr("period"))}</span><input data-exp-field="period" value="${escapeHTML(item.period || "")}" maxlength="60"></label><label class="field"><span>${escapeHTML(tr("duration"))}</span><input data-exp-field="duration" value="${escapeHTML(item.duration || "")}" maxlength="40"></label><label class="field full"><span>${escapeHTML(tr("summary"))}</span><textarea data-exp-field="summary" rows="2" maxlength="300">${escapeHTML(item.summary || "")}</textarea></label></div><button class="text-btn danger" type="button" data-exp-remove="${index}">${escapeHTML(tr("removeExperience"))}</button></div>`).join("") || `<div class="empty-note compact-note">${escapeHTML(tr("noExperience"))}</div>`;
  }

  function readExperienceDraftFromDom() {
    qsa("[data-experience-index]").forEach((row) => { const index = Number(row.dataset.experienceIndex); if (!state.experienceDraft[index]) state.experienceDraft[index] = {}; qsa("[data-exp-field]", row).forEach((field) => { state.experienceDraft[index][field.dataset.expField] = field.value.trim(); }); });
    state.experienceDraft = state.experienceDraft.filter((item) => item && Object.values(item).some(Boolean));
  }

  function parseEducationLines(value) { return String(value || "").split(/\n+/).map((line) => line.trim()).filter(Boolean).slice(0, 6).map((line) => { const [degree = "", school = "", period = ""] = line.split(" — ").map((item) => item.trim()); return {degree, school, period}; }); }
  function parseProjectLines(value) { return String(value || "").split(/\n+/).map((line) => line.trim()).filter(Boolean).slice(0, 8).map((line) => { const [name = "", summary = "", link = ""] = line.split(" — ").map((item) => item.trim()); return {name, summary, link}; }); }

  function saveProfileFromForm(form) {
    if (!state.viewer) return;
    readExperienceDraftFromDom();
    const firstName = form.elements.firstName.value.trim(); const lastName = form.elements.lastName.value.trim(); if (!firstName || !lastName) { toast(tr("authValidation")); return; }
    try {
      const patch = {headline: form.elements.headline.value.trim(), location: form.elements.location.value.trim(), about: form.elements.about.value.trim(), skills: form.elements.skills.value.split(",").map((item) => item.trim()).filter(Boolean), interests: form.elements.interests.value.split(",").map((item) => item.trim()).filter(Boolean), targetRoles: form.elements.targetRoles.value.split(",").map((item) => item.trim()).filter(Boolean), goals: form.elements.goals.value.trim(), education: parseEducationLines(form.elements.education.value), projects: parseProjectLines(form.elements.projects.value), resume: form.elements.resume.value.trim(), experience: state.experienceDraft};
      state.account = Store.updateCurrentProfileAndIdentity({firstName, lastName, profilePatch: patch});
      state.viewer = state.account.profile; syncAuthUI(); renderCurrentRoute();
      qs("#editProfileDialog")?.close(); toast(tr("profileSaved"));
    } catch (error) { console.error(error); toast(tr("saveFailed")); }
  }

  function populateCompanyEditForm() {
    if (!isCompany()) return;
    const form = qs("#editCompanyForm"); if (!form) return;
    form.elements.name.value = state.company.name || ""; form.elements.focus.value = state.company.focus || ""; form.elements.location.value = state.company.location || ""; form.elements.type.value = state.company.type || ""; form.elements.roles.value = (state.company.desiredRoles || []).join(", "); form.elements.skills.value = (state.company.requiredSkills || []).join(", "); form.elements.characteristics.value = (state.company.preferredCharacteristics || []).join(", "); form.elements.experienceLevel.value = state.company.preferredExperienceLevel || ""; form.elements.description.value = state.company.description || "";
  }

  function saveCompanyFromForm(form) {
    if (!isCompany()) return;
    const patch = {name: form.elements.name.value.trim(), focus: form.elements.focus.value.trim(), location: form.elements.location.value.trim(), type: form.elements.type.value.trim(), desiredRoles: form.elements.roles.value.split(",").map((v) => v.trim()).filter(Boolean), requiredSkills: form.elements.skills.value.split(",").map((v) => v.trim()).filter(Boolean), preferredCharacteristics: form.elements.characteristics.value.split(",").map((v) => v.trim()).filter(Boolean), preferredExperienceLevel: form.elements.experienceLevel.value.trim(), description: form.elements.description.value.trim()};
    if (!patch.name) { toast(tr("authValidation")); return; }
    if (applyCompanyPatch(patch)) { qs("#editCompanyDialog")?.close(); toast(tr("companySaved")); } else { toast(tr("saveFailed")); }
  }

  function globalSearch(query) {
    const box = qs("#globalSearchResults"); const q = String(query || "").trim().toLocaleLowerCase(); if (!q) { box.innerHTML = `<div class="empty-note"><strong>${escapeHTML(tr("searchPlaceholder"))}</strong></div>`; return; }
    const people = state.data.profiles.filter((profile) => [text(profile.name), text(profile.headline), text(profile.location), ...(profile.skills || []), ...(profile.interests || [])].join(" ").toLocaleLowerCase().includes(q));
    const orgs = state.data.organizations.filter((org) => [text(org.name), text(org.type), text(org.focus), text(org.location)].join(" ").toLocaleLowerCase().includes(q));
    const opps = state.data.opportunities.filter((opp) => [text(opp.title), text(opp.summary), text(opp.location), ...(opp.skills || [])].join(" ").toLocaleLowerCase().includes(q));
    const items = [...people.map((profile) => `<button class="global-item" type="button" data-search-route="profile/${encodeURIComponent(profile.id)}"><span class="avatar">${escapeHTML(initials(profile.name))}</span><span><strong>${escapeHTML(text(profile.name))}</strong><span>${escapeHTML(text(profile.headline))}</span></span></button>`), ...orgs.map((org) => `<button class="global-item" type="button" data-search-route="organizations/${encodeURIComponent(org.id)}"><span class="avatar">${icon("building")}</span><span><strong>${escapeHTML(text(org.name))}</strong><span>${escapeHTML(text(org.type))}</span></span></button>`), ...opps.map((opp) => `<button class="global-item" type="button" data-search-route="opportunities/${encodeURIComponent(opp.id)}"><span class="avatar">${icon("briefcase")}</span><span><strong>${escapeHTML(text(opp.title))}</strong><span>${escapeHTML(text(opp.location))}</span></span></button>`)].join("");
    box.innerHTML = items || emptyNote();
  }

  function handleAgentAction(action) {
    if (!state.viewer) { openAuth(); return; }
    if (isCompany()) {
      const prompts = {"find-matching": state.lang === "fa" ? "کاندیداهای مناسب نیازهای شرکت را پیدا و دلیل relevance هرکدام را توضیح بده." : "Find candidates for our hiring needs and explain each match.", "analyze-profile": state.lang === "fa" ? "نیازهای استخدامی شرکت را تحلیل کن." : "Analyze our hiring requirements.", "improve-profile": state.lang === "fa" ? "نیازهای استخدامی شرکت چه چیزی کم دارد؟" : "What is missing from our hiring requirements?"};
      openAgent("company", null, null, null); const input = qs("#agentDialogInput"); if (input) { input.value = prompts[action] || prompts["find-matching"]; submitAgent(input.value); input.value = ""; }
      return;
    }
    const prompts = {"improve-profile": state.lang === "fa" ? "پروفایل من را تحلیل کن و مشخص کن چه اطلاعاتی کم است و چه چیزی را باید بهتر کنم." : "Analyze my profile and tell me what is missing and what I should improve.", "analyze-profile": state.lang === "fa" ? "یک تحلیل حرفه‌ای از پروفایل من بر اساس اطلاعات فعلی بده." : "Give me a professional analysis of my current profile.", "suggest-skills": state.lang === "fa" ? "بر اساس فرصت‌های موجود چه مهارت‌هایی را باید بررسی کنم؟" : "Which skills should I consider based on the available opportunities?", "find-matching": state.lang === "fa" ? "فرصت‌های مناسب پروفایل من را پیدا و توضیح بده." : "Find and explain the opportunities that fit my profile.", "career-direction": state.lang === "fa" ? "با توجه به پروفایل فعلی من، چه مسیرهای حرفه‌ای قابل بررسی است؟" : "Based on my current profile, which career directions are worth exploring?"};
    openAgent("profile", state.viewer.id, null, null); const input = qs("#agentDialogInput"); if (input) { input.value = prompts[action] || prompts["analyze-profile"]; submitAgent(input.value); input.value = ""; }
  }

  function bind() {
    addEventListener("hashchange", renderCurrentRoute);
    addEventListener("scroll", () => qs("#siteHeader")?.classList.toggle("scrolled", scrollY > 24), {passive: true});
    matchMedia("(prefers-color-scheme: dark)").addEventListener?.("change", () => { if (state.theme === "system") applyTheme(); });
    qs("#menuOpen")?.addEventListener("click", () => { qs("#mobileDrawer")?.classList.add("open"); qs("#mobileDrawer")?.setAttribute("aria-hidden", "false"); });
    qsa("[data-close-drawer]").forEach((el) => el.addEventListener("click", () => { qs("#mobileDrawer")?.classList.remove("open"); qs("#mobileDrawer")?.setAttribute("aria-hidden", "true"); }));
    qsa("[data-open-auth]").forEach((el) => el.addEventListener("click", (event) => { event.preventDefault(); openAuth(); }));
    qsa("[data-open-search]").forEach((el) => el.addEventListener("click", () => { qs("#searchDialog")?.showModal(); setTimeout(() => qs("#globalSearchInput")?.focus(), 50); }));
    qs("#quickTheme")?.addEventListener("click", () => { state.theme = state.theme === "dark" ? "light" : "dark"; localStorage.setItem(Store.keys.theme, state.theme); applyTheme(); });
    qs("#langToggle")?.addEventListener("click", () => { state.lang = state.lang === "fa" ? "en" : "fa"; localStorage.setItem(Store.keys.lang, state.lang); applyLanguage(); });
    qsa("[data-theme]").forEach((button) => button.addEventListener("click", () => { state.theme = button.dataset.theme; localStorage.setItem(Store.keys.theme, state.theme); applyTheme(); }));
    qsa("[data-close-dialog]").forEach((button) => button.addEventListener("click", () => button.closest("dialog")?.close()));
    qsa("[data-auth-mode]").forEach((tab) => tab.addEventListener("click", () => setAuthMode(tab.dataset.authMode)));

    document.addEventListener("click", (event) => {
      const connect = event.target.closest("[data-connect]"); if (connect) { event.preventDefault(); toggleConnection(connect.dataset.connect); return; }
      const suggestion = event.target.closest("[data-agent-suggestion]"); if (suggestion) { event.preventDefault(); const explicitMode = suggestion.dataset.openAgent || state.agentMode; const explicitTarget = suggestion.dataset.agentTarget || state.agentTargetId; const explicitOrg = suggestion.dataset.agentOrg || state.agentOrgId; const explicitOpportunity = suggestion.dataset.agentOpportunity || state.agentOpportunityId; openAgent(explicitMode, explicitTarget, explicitOrg, explicitOpportunity); const input = qs("#agentDialogInput"); if (input) { input.value = suggestion.dataset.agentSuggestion; submitAgent(input.value); input.value = ""; } return; }
      const agent = event.target.closest("[data-open-agent]"); if (agent) { event.preventDefault(); openAgent(agent.dataset.openAgent, agent.dataset.agentTarget || null, agent.dataset.agentOrg || null, agent.dataset.agentOpportunity || null); return; }
      const retry = event.target.closest("[data-agent-retry]"); if (retry) { submitAgent(retry.dataset.agentRetry || ""); return; }
      const skill = event.target.closest("[data-skill-filter]"); if (skill) { state.peopleSkill = skill.dataset.skillFilter; renderPeople(); return; }
      const route = event.target.closest("[data-search-route]"); if (route) { qs("#searchDialog")?.close(); location.hash = `#${route.dataset.searchRoute}`; return; }
      if (event.target.closest("[data-edit-profile]")) { if (!state.viewer) { openAuth(); return; } populateEditForm(); qs("#editProfileDialog")?.showModal(); return; }
      if (event.target.closest("[data-open-profile-agent]")) { openProfileAgent(false); return; }
      if (event.target.closest("[data-open-company-agent]")) { openCompanyAgent(false); return; }
      if (event.target.closest("[data-edit-company]")) { populateCompanyEditForm(); qs("#editCompanyDialog")?.showModal(); return; }
      if (event.target.closest("[data-interview-skip]")) { submitProfileInterview("skip"); return; }
      if (event.target.closest("[data-sign-out]")) { signOut(); return; }
      const agentAction = event.target.closest("[data-agent-action]"); if (agentAction) { handleAgentAction(agentAction.dataset.agentAction); return; }
      const remove = event.target.closest("[data-exp-remove]"); if (remove) { readExperienceDraftFromDom(); state.experienceDraft.splice(Number(remove.dataset.expRemove), 1); renderExperienceEditor(); return; }
      if (event.target.closest("#addExperience")) { readExperienceDraftFromDom(); state.experienceDraft.push({}); renderExperienceEditor(); return; }
      if (event.target.closest("[data-close-auth]")) { qs("#authDialog")?.close(); return; }
    });

    qs("#authForm")?.addEventListener("submit", (event) => { event.preventDefault(); handleAuthSubmit(event.target); });
    qs("#agentForm")?.addEventListener("submit", (event) => { event.preventDefault(); const input = qs("#agentInput"); const value = input.value; input.value = ""; submitAgent(value); });
    qs("#agentDialogForm")?.addEventListener("submit", (event) => { event.preventDefault(); const input = qs("#agentDialogInput"); const value = input.value; input.value = ""; submitAgent(value); });
    qs("#profileAgentForm")?.addEventListener("submit", (event) => { event.preventDefault(); const input = qs("#profileAgentInput"); const value = input.value; input.value = ""; submitProfileInterview(value); });
    qs("#editCompanyForm")?.addEventListener("submit", (event) => { event.preventDefault(); saveCompanyFromForm(event.target); });
    ["#agentInput", "#agentDialogInput", "#profileAgentInput"].forEach((selector) => qs(selector)?.addEventListener("input", (event) => { event.target.style.height = "auto"; event.target.style.height = `${Math.min(event.target.scrollHeight, 140)}px`; }));
    qs("#peopleSearch")?.addEventListener("input", (event) => { state.peopleQuery = event.target.value; renderPeople(); });
    qs("#peopleClear")?.addEventListener("click", () => { state.peopleQuery = ""; state.peopleSkill = "all"; renderPeople(); });
    qs("#globalSearchInput")?.addEventListener("input", (event) => globalSearch(event.target.value));
    qs("#editProfileForm")?.addEventListener("submit", (event) => { event.preventDefault(); saveProfileFromForm(event.target); });
    qsa("dialog").forEach((dialog) => dialog.addEventListener("click", (event) => { if (event.target === dialog) dialog.close(); }));
    addEventListener("keydown", (event) => { if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === "k") { event.preventDefault(); qs("#searchDialog")?.showModal(); setTimeout(() => qs("#globalSearchInput")?.focus(), 50); } if (event.key === "Escape") qs("#mobileDrawer")?.classList.remove("open"); });
  }

  async function init() {
    refreshViewer(); applyTheme(); bind(); syncAuthUI();
    try {
      const response = await fetch(DATA_URL, {headers: {Accept: "application/json"}}); if (!response.ok) throw new Error(`HTTP ${response.status}`);
      state.data = await response.json();
      if (!Array.isArray(state.data.profiles) || !Array.isArray(state.data.organizations) || !Array.isArray(state.data.opportunities)) throw new Error("invalid_data");
      applyLanguage(); syncAgentStatus(); renderCurrentRoute();
    } catch (error) {
      console.error(error); qs("#mainContent").innerHTML = `<div class="container"><div class="error-state"><strong>Veyra</strong><p>Data could not be loaded. Run the site through an HTTP server so the JSON file can be fetched.</p></div></div>`;
    }
  }

  init();
})();
