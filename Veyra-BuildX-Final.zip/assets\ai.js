(() => {
  "use strict";

  // Veyra Agent provider — TEMPORARY GapGPT DEMO BUILD.
  //
  // The site is a static frontend (plain browser JS, no build system), so we
  // deliberately do NOT use `import OpenAI from 'openai'` here. The `openai`
  // npm package is a Node.js dependency and cannot run from a plain <script>
  // tag. Instead we call the GapGPT OpenAI-COMPATIBLE HTTP endpoint directly
  // with fetch, which is exactly what the SDK does under the hood:
  //   POST {baseURL}/chat/completions  { model, messages, ... }
  //
  // Contract with assets/app.js is unchanged: run() resolves to
  // { reply, action, profilePatch, companyPatch, preferencePatch, targetId,
  //   nextQuestion, provider }. The app then executes the suggested action
  // deterministically on local state (controlled agent path) — the LLM never
  // mutates state directly.

  const CONFIG = window.BUILDX_CONFIG || {};
  const GAP = CONFIG.gapgpt || {};
  const BASE_URL = String(GAP.baseURL || "https://api.gapgpt.app/v1").trim().replace(/\/$/, "");
  const API_KEY = String(GAP.apiKey || "").trim();
  const MODEL = String(GAP.model || "gapgpt-gemma-26b-a4b").trim();
  const TEMPERATURE = Number.isFinite(Number(GAP.temperature)) ? Number(GAP.temperature) : 0.3;
  const MAX_TOKENS = Number.isFinite(Number(GAP.maxTokens)) ? Number(GAP.maxTokens) : 900;
  const TIMEOUT_MS = Number(CONFIG.agentTimeoutMs || 45000);

  // Legacy proxy fallback (pre-demo architecture). Kept for compatibility;
  // unused when the GapGPT key is present.
  const LEGACY_ENDPOINT = String(CONFIG.agentEndpoint || "").trim().replace(/\/$/, "");

  const PROVIDER_LABEL = "GapGPT · " + MODEL;

  const ACTIONS = new Set([
    "none", "collect_profile_facts", "collect_company_facts", "find_jobs", "find_similar_jobs", "analyze_job",
    "find_candidates", "analyze_candidate", "analyze_profile", "analyze_company", "suggest_skills", "skill_gap", "career_direction",
    "update_preferences", "improve_profile",
  ]);

  function configured() {
    if (API_KEY && BASE_URL && MODEL) return true;
    return Boolean(LEGACY_ENDPOINT);
  }

  function useGapGPT() {
    return Boolean(API_KEY && BASE_URL && MODEL);
  }

  function isPlainObject(value) {
    return Boolean(value) && typeof value === "object" && !Array.isArray(value);
  }

  function validatePayload(payload) {
    if (!isPlainObject(payload)) throw new Error("invalid_agent_response");
    if (typeof payload.reply !== "string") throw new Error("invalid_agent_response_reply");
    if (typeof payload.action !== "string" || !ACTIONS.has(payload.action)) throw new Error("invalid_agent_action");
    for (const key of ["profilePatch", "companyPatch", "preferencePatch"]) {
      if (payload[key] != null && !isPlainObject(payload[key])) throw new Error(`invalid_${key}`);
    }
    if (payload.targetId != null && typeof payload.targetId !== "string") throw new Error("invalid_target_id");
    if (payload.nextQuestion != null && (typeof payload.nextQuestion !== "string" || payload.nextQuestion.length > 600)) throw new Error("invalid_next_question");
    return payload;
  }

  function clip(value, max) {
    const text = String(value ?? "");
    return text.length > max ? text.slice(0, max) : text;
  }

  function detectLang() {
    const htmlLang = String(document.documentElement?.lang || "").toLowerCase();
    if (htmlLang.startsWith("fa")) return "fa";
    if (htmlLang.startsWith("en")) return "en";
    try {
      const stored = String(localStorage.getItem("veyra:lang") || "").toLowerCase();
      if (stored === "fa" || stored === "en") return stored;
    } catch { /* ignore */ }
    return "fa";
  }

  function buildSystemPrompt({ operation, context, lang }) {
    const isInterview = operation === "profile-create" || operation === "company-create";
    const contextJson = clip(JSON.stringify(context || {}), 4500);
    return [
      "You are Veyra Agent, a bilingual (Persian/English) career assistant inside the Veyra AI Career Network demo.",
      "You see the current page context as JSON and the recent conversation. The app executes actions deterministically on local data; you only interpret and suggest.",
      "",
      "Allowed `action` values (exactly one, must be in this list):",
      "none, collect_profile_facts, collect_company_facts, find_jobs, find_similar_jobs, analyze_job,",
      "find_candidates, analyze_candidate, analyze_profile, analyze_company, suggest_skills, skill_gap, career_direction,",
      "update_preferences, improve_profile.",
      "",
      "Action guide:",
      "- find_jobs: user asks for matching opportunities for their profile.",
      "- find_similar_jobs: user is viewing an opportunity and asks for similar ones (needs context.opportunity.id as targetId).",
      "- analyze_job: user asks if they fit a specific opportunity (needs opportunity id as targetId).",
      "- find_candidates: company account asks for candidates matching hiring needs.",
      "- analyze_candidate: company account asks about a specific candidate (needs profile id as targetId).",
      "- analyze_profile / improve_profile / suggest_skills / skill_gap / career_direction: profile analysis requests.",
      "- update_preferences: user states a preference (remote, startup, role focus, level).",
      "- collect_profile_facts / collect_company_facts: ONLY for profile-create / company-create interview turns where the user states a fact to store.",
      "- none: greeting, small talk, or anything not matching above.",
      "",
      isInterview
        ? "This turn is a STRUCTURED INTERVIEW step (" + operation + "). The app already extracts facts deterministically; set action to collect_profile_facts (profile-create) or collect_company_facts (company-create) when the user states a storable fact, else none. Always provide `nextQuestion` (max 600 chars) continuing the interview in the user language, unless the profile/company looks complete — then set nextQuestion to null."
        : "This is a normal chat turn. Set `nextQuestion` to null. Only set profilePatch/companyPatch/preferencePatch when the user EXPLICITLY states a fact or preference; otherwise null. Never invent skills, experience, or company data.",
      "",
      "Rules:",
      "- Reply ONLY with a single JSON object. No markdown, no code fences, no text outside the JSON.",
      "- Schema: {\"reply\": string, \"action\": string, \"profilePatch\": object|null, \"companyPatch\": object|null, \"preferencePatch\": object|null, \"targetId\": string|null, \"nextQuestion\": string|null}.",
      "- `reply`: 1-4 sentences in the USER LANGUAGE (" + lang + "), grounded in the provided context. Never fabricate market data.",
      "- `targetId`: id of the opportunity/candidate/profile being discussed, or null.",
      "- Current operation: " + operation + ".",
      "- Current page context JSON: " + contextJson,
    ].join("\n");
  }

  function toChatMessages({ message, context, history, operation }) {
    const lang = detectLang();
    const system = buildSystemPrompt({ operation, context, lang });
    const messages = [{ role: "system", content: system }];
    const trimmed = Array.isArray(history) ? history.slice(-12) : [];
    for (const item of trimmed) {
      if (!item || typeof item.content !== "string") continue;
      const role = item.role === "assistant" ? "assistant" : "user";
      const content = clip(item.content, 800);
      if (content.trim()) messages.push({ role, content });
    }
    messages.push({ role: "user", content: clip(message, 3000) });
    return messages;
  }

  function extractJson(text) {
    const raw = String(text || "").trim();
    if (!raw) throw new Error("empty_agent_response");
    const fenced = raw.match(/```(?:json)?\s*([\s\S]*?)```/i);
    const candidate = (fenced ? fenced[1] : raw).trim();
    const start = candidate.indexOf("{");
    const end = candidate.lastIndexOf("}");
    if (start < 0 || end <= start) throw new Error("invalid_agent_response");
    return JSON.parse(candidate.slice(start, end + 1));
  }

  async function runViaGapGPT({ message, context, history, operation }) {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), TIMEOUT_MS);
    try {
      const response = await fetch(`${BASE_URL}/chat/completions`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Accept: "application/json",
          Authorization: `Bearer ${API_KEY}`,
        },
        body: JSON.stringify({
          model: MODEL,
          messages: toChatMessages({ message, context, history, operation }),
          temperature: TEMPERATURE,
          max_tokens: MAX_TOKENS,
        }),
        signal: controller.signal,
      });
      let envelope = null;
      try { envelope = await response.json(); } catch { envelope = null; }
      if (!response.ok) {
        const detail = envelope?.error?.message || envelope?.error?.code || `HTTP ${response.status}`;
        throw new Error(String(detail).slice(0, 300));
      }
      const content = envelope?.choices?.[0]?.message?.content;
      if (typeof content !== "string" || !content.trim()) throw new Error("empty_agent_response");
      const payload = validatePayload(extractJson(content));
      const isInterview = operation === "profile-create" || operation === "company-create";
      return {
        reply: String(payload.reply || "").trim(),
        action: payload.action,
        profilePatch: payload.profilePatch && typeof payload.profilePatch === "object" ? payload.profilePatch : null,
        companyPatch: payload.companyPatch && typeof payload.companyPatch === "object" ? payload.companyPatch : null,
        preferencePatch: payload.preferencePatch && typeof payload.preferencePatch === "object" ? payload.preferencePatch : null,
        targetId: payload.targetId ? String(payload.targetId) : null,
        // Normal chat turns ignore nextQuestion downstream; coerce to null so
        // a chatty model cannot leak an interview-style follow-up into state.
        nextQuestion: isInterview && typeof payload.nextQuestion === "string" && payload.nextQuestion ? payload.nextQuestion : null,
        provider: PROVIDER_LABEL,
      };
    } finally {
      clearTimeout(timer);
    }
  }

  async function runViaLegacy({ message, context, history, operation }) {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), TIMEOUT_MS);
    try {
      const response = await fetch(LEGACY_ENDPOINT, {
        method: "POST",
        headers: { "Content-Type": "application/json", Accept: "application/json" },
        body: JSON.stringify({ message, context, history: (history || []).slice(-12), operation }),
        signal: controller.signal,
      });
      let payload = null;
      try { payload = await response.json(); } catch { payload = null; }
      if (!response.ok) {
        const detail = payload?.error || `HTTP ${response.status}`;
        throw new Error(detail);
      }
      validatePayload(payload);
      if (payload.error) throw new Error(String(payload.error));
      return {
        reply: String(payload.reply || "").trim(),
        action: typeof payload.action === "string" ? payload.action : "none",
        profilePatch: payload.profilePatch && typeof payload.profilePatch === "object" ? payload.profilePatch : null,
        companyPatch: payload.companyPatch && typeof payload.companyPatch === "object" ? payload.companyPatch : null,
        preferencePatch: payload.preferencePatch && typeof payload.preferencePatch === "object" ? payload.preferencePatch : null,
        targetId: payload.targetId ? String(payload.targetId) : null,
        nextQuestion: typeof payload.nextQuestion === "string" ? payload.nextQuestion : null,
        provider: String(payload.provider || "Google AI Studio / Gemini"),
      };
    } finally {
      clearTimeout(timer);
    }
  }

  async function run({ message, context, history = [], operation = "chat" }) {
    if (useGapGPT()) return runViaGapGPT({ message, context, history, operation });
    if (LEGACY_ENDPOINT) return runViaLegacy({ message, context, history, operation });
    throw new Error("agent_endpoint_not_configured");
  }

  window.VeyraAI = Object.freeze({ configured, run });
})();
